<?php global $post;
$images = rwmb_meta( 'gallery', array( 'size' => 'full' ) );
$crop       = true;
$upscale    = true;
    echo '<div class="row justify-content-center" id="parent-container-'.$id.'">';
      if($images){      
            foreach ( $images as $image ) {
              $gambar = get_post($image['ID']);
              $image_caption = $gambar->post_excerpt;
              $urlkecil = aq_resize( $image['full_url'], 400, 400, $crop, true, $upscale );
              $urlbesar = $image['full_url'];
              echo '<div class="col-6 col-sm-4 col-md-3 mb-4">';
              echo '<a href="'.$image['full_url'].'" title="'.$image_caption.'">';
              echo '<img class="lazy" src="'.$urlkecil.'" data-src="'.$urlbesar.'">';
              if(!empty($image_caption)){
                echo '<small class="py-2 text-muted">'.$image_caption.'</small>';
              }
              echo '</a></div>';
            }
      } elseif(has_post_thumbnail($post->ID)){
          $urlt = get_the_post_thumbnail_url($post->ID,'full');
          $image_caption = get_the_post_thumbnail_caption($post->ID);
              echo '<div class="col-12">';
              echo '<a href="'.$urlt.'" title="">';
              echo '<img class="w-100 lazy" src="'.$urlt.'" data-src="'.$urlt.'">';
              if(!empty($image_caption)){
                echo '<small class="py-2 text-muted">'.$image_caption.'</small>';
              }
              echo '</a></div>';
      }
    echo '</div>';