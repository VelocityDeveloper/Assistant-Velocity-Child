    jQuery(function ($) {
		$('#parent-container-<?php echo $id;?>').magnificPopup({
		  delegate: 'a', // child items selector, by clicking on it popup will open
		  type: 'image',
          gallery:{
            enabled:true
          },
          image: {
              titleSrc: 'title' 
              // this tells the script which attribute has your caption
          }
		  // other options
		});
    });