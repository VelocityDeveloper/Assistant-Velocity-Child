<?php
/**
 * Child theme functions
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development
 * and http://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions would be used.
 *
 * Text Domain: justg
 * @link http://codex.wordpress.org/Plugin_API
 *
 */

/**
 * Load other required files
 *
 */

 $inc = get_stylesheet_directory() . '/inc';
 $includes = [
	'enqueue.php',
	'function-child.php',
	'shortcodes.php'
 ];

 foreach( $includes as $include ) {
	 require_once( $inc . '/' . $include );
 }


function vsstem_modul() {
	if ( class_exists( 'FLBuilder' ) ) {
	    get_template_part('modul/vel-gallery/vel-gallery');
	    get_template_part('modul/vel-post-gallery/vel-post-gallery');
	    get_template_part('modul/gallery-carousel/gallery-carousel');
	}
}
add_action( 'init', 'vsstem_modul' );


// [cari]
function cariform() {
$html = '<div class="vel-cari">
   <span class="tombols"></span>
   <form action="'.get_home_url().'" method="get" id="formsearchvel" style="display: none;">
	<input class="search-input" name="s" placeholder="Search.." type="text">
	<button class="search-button" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
   </form>
</div>';
return $html;
}
add_shortcode ('cari', 'cariform');



add_action('init', 'velocity_admin_init');
function velocity_admin_init() {
    register_post_type('portofolio', array(
        'labels' => array(
            'name' => 'Portofolio',
            'singular_name' => 'portofolio',
        ),
        'menu_icon' => 'dashicons-screenoptions',
        'public' => true,
        'has_archive' => true,
        'taxonomies' => array('portofolio-category'),
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
        ),
    ));
	register_taxonomy(
	'portofolio-category',
	'portofolio',
	array(
		'label' => __( 'Portofolio Categories' ),
		'rewrite' => array( 'slug' => 'portofolio-category' ),
		'hierarchical' => true,
		'show_admin_column' => true,
	));
}

function pippin_add_taxonomy_filters() {
	global $typenow; 
	// an array of all the taxonomyies you want to display. Use the taxonomy name or slug
	$taxonomies = array('portofolio-category'); 
	// must set this to the post type you want the filter(s) displayed on
	if( $typenow == 'portofolio' ){ 
		foreach ($taxonomies as $tax_slug) {
			$tax_obj = get_taxonomy($tax_slug);
			$tax_name = $tax_obj->labels->name;
			$terms = get_terms($tax_slug);
			if(count($terms) > 0) {
				echo "<select name='$tax_slug' id='$tax_slug' class='postform'>";
				echo "<option value=''>All $tax_name</option>";
				foreach ($terms as $term) { 
					echo '<option value='. $term->slug, $_GET[$tax_slug] == $term->slug ? ' selected="selected"' : '','>' . $term->name .' (' . $term->count .')</option>'; 
				}
				echo "</select>";
			}
		}
	}
}
add_action( 'restrict_manage_posts', 'pippin_add_taxonomy_filters' );


add_filter( 'rwmb_meta_boxes', 'vel_metabox' );
function vel_metabox( $meta_boxes ){
	$textdomain = 'justg';
	$meta_boxes[] = array(
		'id'         => 'standard',
		'title'      => __( 'Velocity Fields', $textdomain ),
		'post_types' => array( 'portofolio' ),
		'context'    => 'normal',
		'priority'   => 'high',
		'autosave'   => true,
		'fields'     => array(
			array(
				'name'             => __( 'Photo Gallery', $textdomain ),
				'id'               => "gallery",
				'type'             => 'image_advanced',
			),
		)
	);

	return $meta_boxes;
}


