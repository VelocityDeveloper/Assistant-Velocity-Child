jQuery(function($) {    
$(".tombols").click(function() {
    $("#formsearchvel").toggle();
    $(".tombols").toggleClass( "collapsed" );
});
$(".tombolsbaru").click(function() {
    $("#formsearchvelbaru").toggle();
    $(".tombolsbaru").toggleClass( "collapsed" );
});
});