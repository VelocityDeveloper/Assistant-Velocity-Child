<?php $images = $settings->gallery;
echo '<div id="image-carousel" class="images-'.$id.'">';
if ($images) {
foreach($images as $image){
	$caption = wp_get_attachment_caption($image);
    echo '<div class="p-3"><div class="image-list"><a href="'.wp_get_attachment_url($image).'" target="_blank" title="'.$caption.'">';
	echo '<div class="image-carousel-thumbnail" style="background-image:url('.wp_get_attachment_url($image).');"></div>';
	if($caption){
		echo '<div class="mt-2">'.$caption.'</div>';
	}
    echo '</a></div></div>';
}
}
echo '</div>';?>
