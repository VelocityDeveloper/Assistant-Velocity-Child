<?php
/**
 * Fuction yang digunakan di theme ini.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

add_action('after_setup_theme', 'velocitychild_theme_setup', 9);
function velocitychild_theme_setup() {

    if (class_exists('Kirki')) :

        Kirki::add_panel('panel_iklan', [
            'priority'    => 10,
            'title'       => esc_html__('Iklan Kanan & Kiri', 'justg'),
            'description' => esc_html__('', 'justg'),
        ]);

        // Section Iklan Float
        Kirki::add_section('iklan_float', [
            'panel'    => 'panel_iklan',
            'title'    => __('Iklan Float', 'justg'),
            'priority' => 10,
        ]);
        Kirki::add_field('justg_config', [
            'type'        => 'toggle',
            'settings'    => 'iklan_float_setting',
            'label'       => esc_html__('Aktifkan Iklan Float', 'kirki'),
            'section'     => 'iklan_float',
            'default'     => '1',
            'priority'    => 10,
        ]);
        Kirki::add_field('justg_config', [
            'type'        => 'number',
            'settings'    => 'iklan_float_width',
            'label'       => esc_html__('Lebar Gambar', 'kirki'),
            'section'     => 'iklan_float',
            'default'     => 190,
        ]);
        Kirki::add_field('justg_config', [
            'type'        => 'image',
            'settings'    => 'img_iklan_float_left',
            'label'       => esc_html__('Image Iklan Kiri', 'kirki'),
            'description' => esc_html__('', 'kirki'),
            'section'     => 'iklan_float',
            'default'     => '',
        ]);
        Kirki::add_field('justg_config', [
            'type'        => 'image',
            'settings'    => 'img_iklan_float_right',
            'label'       => esc_html__('Image Iklan Kanan', 'kirki'),
            'description' => esc_html__('', 'kirki'),
            'section'     => 'iklan_float',
            'default'     => '',
        ]);

	endif;
}

add_action('wp_footer', 'footer_vd_additional');
function footer_vd_additional() {
    $widthcon    = '968px';
	$class = '';
    $imgwidth    = velocitytheme_option('iklan_float_width');
    $lebar = $imgwidth ? 'style="width:'.$imgwidth.'px"' : '';
    foreach (['left', 'right'] as $keye) {
        if (true == velocitytheme_option('iklan_float_setting', true)) {
            $imgiklan    = velocitytheme_option('img_iklan_float_' . $keye);
            if ($imgiklan) {
				if ($keye == 'left') {
					$class = 'start-0';
				} elseif ($keye == 'right') {
					$class = 'end-0';
				}
				$kelas = 'vd-iklan-'.$keye;
                echo '<div class="iklanfloating top-0 '.$class.' '.$kelas.'" data-container="' . $widthcon . '">';
					echo '<div class="position-relative">';
						echo '<div class="close-button position-absolute" data-element="'.$kelas.'" aria-label="Close">Tutup</div>';
						echo '<span><img src="' . $imgiklan . '" loading="lazy" '.$lebar.'></span>';
					echo '</div>';
                echo '</div>';
			}
        }
    }
}


add_filter( 'rwmb_meta_boxes', 'vel_metabox' );
function vel_metabox( $meta_boxes ){
	$textdomain = 'justg';
	$meta_boxes[] = array(
		'id'         => 'standard',
		'title'      => __('Velocity Fields',$textdomain),
		'post_types' => array('post'),
		'context'    => 'normal',
		'priority'   => 'high',
		'autosave'   => true,
		'fields'     => array(
			array(
				'name'             => __('Video Youtube',$textdomain),
				'id'               => "video",
				'type'             => 'oembed',
			),
			array(
				'name'             => __('Gallery Foto',$textdomain),
				'id'               => "gallery",
				'type'             => 'image_advanced',
			),
		)
	);
	return $meta_boxes;
}
