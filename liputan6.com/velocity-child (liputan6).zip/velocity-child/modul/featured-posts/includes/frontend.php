<?php 
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;
if($posts){ ?>
<div class="border p-3 rounded bg-white velocity-featured-posts">
<?php foreach(array_slice($posts,0,1) as $post) { ?>
<div class="vfp-list pb-2">
  <div class="vfp-image rounded">
    <?php echo do_shortcode('[resize-thumbnail width="640" height="350" linked="true" class="w-100 rounded" post_id="'.$post->ID.'"]');?>
  </div>
    <div class="vfp-content pt-3">
      <?php echo '<small class="d-block text-muted mb-1">';
        echo do_shortcode('[tanggal-pos post_id="'.$post->ID.'"]');
      echo '</small>'; ?>
    	<div class="vfp-title mb-2"><a class="fw-bold text-dark fs-5 lh-sm" href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post->ID);?></a></div>
      <?php 
        $content = $post->post_content;
        $trimmed_content = wp_trim_words( $content, 20 );
        echo '<div class="text-muted">'.$trimmed_content.'</div>';
      ?>
    </div>
</div>
<?php } ?>
<div class="fs-6 vfp-judul border-top mt-3 pt-3 fw-bold">Berita Lainnya</div>
<div class="vfp-carousel">
<div class="vfp-carousel-<?php echo $id; ?>">
<?php foreach(array_slice($posts,1,4) as $post) { ?>
  <div class="p-2">
    <?php echo do_shortcode('[resize-thumbnail width="300" height="200" linked="true" class="w-100 rounded mb-2" post_id="'.$post->ID.'"]');?>
      <?php echo '<small class="d-block text-muted mb-1">';
        echo do_shortcode('[tanggal-pos post_id="'.$post->ID.'"]');
      echo '</small>'; ?>
    <a class="text-dark fw-bold lh-sm" href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post->ID);?></a>
  </div>
<?php } ?>
</div>
</div>
</div>
<?php } ?>