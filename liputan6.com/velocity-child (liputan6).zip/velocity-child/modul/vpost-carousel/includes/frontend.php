<?php 
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="vd-post-carousel">
    <div class="vd-carousel-<?php echo $id; ?>">
        <?php foreach($posts as $post) { ?>
            <div class="post-list-module m-1">
                <div class="p-1 pb-2">
                    <?php echo do_shortcode('[resize-thumbnail width="300" height="200" linked="true" class="w-100 rounded" post_id="'.$post->ID.'"]');?>
                </div>
                <div class="second-post-title px-1">
                    <a class="text-dark fw-bold" href="<?php echo get_the_permalink($post->ID);?>">
                        <?php echo get_the_title($post);?>
                    </a>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
