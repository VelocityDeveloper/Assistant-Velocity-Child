<?php

/**
 * @class FLvMobileMenu
 */
class FLvMobileMenu extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __('Mobile Menu', 'fl-builder'),
			'description'   	=> __('Mobile Menu by Velocity Developer', 'fl-builder'),
			'category'      	=> __('Actions', 'fl-builder'),
			'editor_export' 	=> false,
			'partial_refresh'	=> true
		));
	}
	

	public static function _get_menus() {
		$get_menus = get_terms( 'nav_menu', array(
			'hide_empty' => true,
		) );
		$fields = array(
			'type'          => 'select',
			'label'         => __( 'Primary Menu', 'fl-builder' ),
			'helper'		=> __( 'Select a WordPress menu that you created in the admin under Appearance > Menus.', 'fl-builder' ),
		);

		if ( $get_menus ) {
            $menus[] = 'Tidak Ada Menu';
			foreach ( $get_menus as $key => $menu ) {

				if ( 0 == $key ) {
					$fields['default'] = $menu->name;
				}

				$menus[ $menu->slug ] = $menu->name;
			}

			$fields['options'] = $menus;

		} else {
			$fields['options'] = array(
				'' => __( 'No Menus Found', 'fl-builder' ),
			);
		}

		return $fields;

	}
	public static function _left_menus() {
		$get_menus = get_terms( 'nav_menu', array(
			'hide_empty' => true,
		) );
		$fields = array(
			'type'          => 'select',
			'label'         => __( 'Left Menu', 'fl-builder' ),
			'helper'		=> __( 'Select a WordPress menu that you created in the admin under Appearance > Menus.', 'fl-builder' ),
		);

		if ( $get_menus ) {

			foreach ( $get_menus as $key => $menu ) {

				if ( 0 == $key ) {
					$fields['default'] = $menu->name;
				}

				$menus[ $menu->slug ] = $menu->name;
			}

			$fields['options'] = $menus;

		} else {
			$fields['options'] = array(
				'' => __( 'No Menus Found', 'fl-builder' ),
			);
		}

		return $fields;

	}
	
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvMobileMenu', array(
	'slider'      => array(
		'title'         => __('Basic Module', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
				'menu' => FLvMobileMenu::_get_menus(),
				'menu_left' => FLvMobileMenu::_left_menus(),
					'photo'         => array(
						'type'          => 'photo',
						'label'         => __( 'Logo Menu', 'fl-builder' ),
						'show_remove'   => true,
					),
				)
			),

		)
	),
));



