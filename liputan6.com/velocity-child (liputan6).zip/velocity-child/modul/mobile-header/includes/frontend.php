<?php $photo = $settings->photo; ?>

<div id="mySidenav-<?php echo $id; ?>" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	<?php if ($photo){ ?>
		<div class="menu-logo text-center pb-2 mb-2 border-bottom"><a href="<?php echo home_url(); ?>"><img src="<?php echo wp_get_attachment_url($photo); ?>" /></a></div>
	<?php }
    $defaults = array(
        'menu'			=> $settings->menu_left,
        'container'		=> false,
        'menu_class'	=> 'left-menu-'.$id,
    );
    wp_nav_menu( $defaults ); ?>
</div>



<div class="vel-mobile-menu" id="mobile-nav">

<div class="vel-menu-<?php echo $id; ?>">
<div class="row align-items-center py-2">
<div class="col-2">
	<span class="slide-icon-<?php echo $id; ?>" onclick="openNav()"><i class="dashicons dashicons-menu"></i></span>
</div>
<div class="col-7">
	<?php if ($photo){ ?>
		<div class="menu-logo text-center"><a href="<?php echo home_url(); ?>"><img src="<?php echo wp_get_attachment_url($photo); ?>" /></a></div>
	<?php } ?>
</div>
<div class="col-3 text-end">
<div class="vel-cari">
   <span class="tombols"></span>
   <form action="<?php echo get_home_url();?>" method="get" id="formsearchvel">
	<input class="search-input" name="s" placeholder="Cari berita.." type="text" required>
	<button class="search-button" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
   </form>
</div>
</div>
</div>

</div>


<?php if($settings->menu){ ?>
    <div class="menu-frame">
        <?php $defaults = array(
            'menu'			=> $settings->menu,
            'container'		=> false,
            'menu_id'	=> 'top-menu',
            'menu_class'	=> 'top-menu same-menu',
        );
        wp_nav_menu( $defaults ); ?>
    </div>
<?php } ?>

</div>



<div class="vel-tinggi-menu"></div>