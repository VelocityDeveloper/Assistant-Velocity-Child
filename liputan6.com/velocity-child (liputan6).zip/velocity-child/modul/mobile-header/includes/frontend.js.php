
function openNav() {
    document.getElementById("mySidenav-<?php echo $id; ?>").style.width = "100%";
}

function closeNav() {
    document.getElementById("mySidenav-<?php echo $id; ?>").style.width = "0";
}

jQuery(function($) {
$( ".tombols" ).click(function() {
      $("#formsearchvel").toggle();
      $(".tombols").toggleClass( "collapsed" );
    });
$( ".tombolsbaru" ).click(function() {
      $("#formsearchvelbaru").toggle();
      $(".tombolsbaru").toggleClass( "collapsed" );
    });
$('.vel-tinggi-menu').css({height: $('.vel-mobile-menu').outerHeight(true),});
});

jQuery(document).ready(function() {
    jQuery(".left-menu-<?php echo $id; ?>").find("li.menu-item-has-children").append('<i class="fa fa-angle-down" aria-hidden="true"></i>');
    jQuery(".left-menu-<?php echo $id; ?> li.menu-item-has-children i").on("click", function() {
        jQuery(this).hasClass("fa-angle-down") ? jQuery(this).addClass("fa-angle-up").removeClass("fa-angle-down").parent("li.menu-item-has-children").find("> ul").slideToggle() : jQuery(this).addClass("fa-angle-down").parent("li.menu-item-has-children").find("> ul").slideToggle()
    });

});
