<?php 

$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="row align-items-center m-0">
    <div class="col-sm-2 d-sm-block d-none bg-white text-theme-primary text-center py-12 px-0 rounded lh-lg fw-bold">Konten Spesial</div>
    <div class="col-sm-10 py-1">
        <marquee behavior="scroll" scrollamount="5" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
            <?php foreach($posts as $post) { ?>
                <a class="lh-sm" href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post);?></a>
                <span class="px-3">|</span>
            <?php } ?>
        </marquee>
    </div>
</div>