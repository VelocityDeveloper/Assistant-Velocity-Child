<?php 
$acv = get_queried_object();
//echo '<pre>'.print_r($acv,1).'</pre>';
$args = array(
	'posts_per_page' => 3,
	'showposts' => 3,
);
if($acv->taxonomy == 'category' || $acv->taxonomy == 'post_tag'){
  $args['tax_query'] = array(
        array(
            'taxonomy' => $acv->taxonomy,
            'field'    => 'term_id',
            'terms'    => $acv->term_id,
        ),
    );
}
$wp_query = new WP_Query($args); 
if(!empty($wp_query->posts)) { 
    echo '<div class="row">';
        echo '<div class="col-md-7 pe-md-0">';
            foreach(array_slice($wp_query->posts, 0,1) as $post) { 
                $post_id = $post->ID;
                $post_categories = wp_get_post_categories( $post_id, array( 'fields' => 'all' ) );
                echo '<div class="velocity-first-post position-relative" style="background-image: url('.get_the_post_thumbnail_url($post_id,'full').');">';
                echo '<div class="velocity-post-text">';
                    if( $post_categories ){
                        echo '<div class="fl-post-category mb-2">';
                        foreach($post_categories as $c){
                            echo '<a href="'.esc_url(get_category_link( $c->term_id )).'">'.$c->name.'</a>';
                        }
                        echo '</div>';
                    }
                    echo '<div class="velocity-post-title"><a href="'.get_the_permalink($post_id).'">'.$post->post_title.'</a></div>';
                    echo '<div class="velocity-post-date"><i class="fa fa-clock-o"> </i> '.get_the_date( 'F j, Y',$post_id ).'</div>';
                echo '</div>';
                echo '</div>';
            }
        echo '</div>';
        echo '<div class="col-md-5 ps-md-1">';
            foreach(array_slice($wp_query->posts, 1,3) as $post) { 
                $post_id = $post->ID;
                $post_categories = wp_get_post_categories( $post_id, array( 'fields' => 'all' ) );
                echo '<div class="velocity-second-post position-relative" style="background-image: url('.get_the_post_thumbnail_url($post_id,'full').');">';
                echo '<div class="velocity-post-text">';
                    if( $post_categories ){
                        echo '<div class="fl-post-category mb-2">';
                        foreach($post_categories as $c){
                            echo '<a href="'.esc_url(get_category_link( $c->term_id )).'">'.$c->name.'</a>';
                        }
                        echo '</div>';
                    }
                    echo '<div class="velocity-post-title"><a href="'.get_the_permalink($post_id).'">'.$post->post_title.'</a></div>';
                    echo '<div class="velocity-post-date"><i class="fa fa-clock-o"> </i> '.get_the_date( 'F j, Y',$post_id ).'</div>';
                echo '</div>';
                echo '</div>';
            }
        echo '</div>';
    echo '</div>';
}