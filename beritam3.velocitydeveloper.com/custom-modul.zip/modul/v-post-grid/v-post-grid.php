<?php

class FLvPostGridModule extends FLBuilderModule {
	public function __construct() {
		parent::__construct(array(
			'name'            => __( 'Velocity Posts', 'fl-builder' ),
			'description'     => __( 'Display a grid of your WordPress posts.', 'fl-builder' ),
			'category'        => __( 'Posts', 'fl-builder' ),
			'editor_export'   => false,
			'partial_refresh' => true,
			'icon'            => 'schedule.svg',
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvPostGridModule', array(
	'slider'      => array(
		'title'         => __('No Setting', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
				)
			),

		)
	),
));