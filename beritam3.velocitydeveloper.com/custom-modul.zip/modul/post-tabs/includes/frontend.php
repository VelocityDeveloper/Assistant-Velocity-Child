<?php $jumlah = $settings->jumlah; ?>

<div class="border p-3 bg-white">
<ul class="nav nav-tabs fw-bold" id="myTab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active rounded-0" id="kategori1-tab" data-bs-toggle="tab" href="#kategori1" role="tab" aria-controls="kategori1" aria-selected="true">
	Popular</a>
  </li>
  <li class="nav-item">
    <a class="nav-link rounded-0" id="kategori2-tab" data-bs-toggle="tab" href="#kategori2" role="tab" aria-controls="kategori2" aria-selected="false">
	Recent</a>
  </li>
  <li class="nav-item">
    <a class="nav-link rounded-0" id="kategori3-tab" data-bs-toggle="tab" href="#kategori3" role="tab" aria-controls="kategori3" aria-selected="false">
	Comment</a>
  </li>
</ul>
<div class="tab-content py-2 border-left border-right border-bottom" id="myTabContent">
<div class="tab-pane fade show active" id="kategori1" role="tabpanel" aria-labelledby="kategori1-tab">
<?php $args = array(
	'posts_per_page' => $jumlah,
	'showposts' => $jumlah,
	'meta_key' => 'hit',
	'orderby' => 'meta_value_num',
	'order' => 'DESC',
);

$wp_query = new WP_Query($args); 
if($wp_query->have_posts ()): ?>
<div class="frame-kategori">
<?php while($wp_query->have_posts()): $wp_query->the_post();
        echo '<div class="row m-0 py-2 px-1">';
        echo '<div class="col-3 p-0">';
        if ( has_post_thumbnail() ){
          echo '<a href="'.get_the_permalink().'">';
            echo do_shortcode('[resize-thumbnail width="300" height="300" linked="true" class="w-100"]');
          echo '</a>';
        }
		echo '</div>';
		echo '<div class="col-9">';
		$vtitle= get_the_title();
		echo '<div class="vtitle"><a class="text-dark" href="'.get_the_permalink().'">'.substr($vtitle, 0, 60) . ' ...'.'</a></div>';
		echo '<div class="text-muted"><small><i class="fa fa-calendar" aria-hidden="true"></i> '.get_the_date('j F Y',get_the_ID()).'</small></div>';
		echo '</div>';
		echo '</div>';
?>
<?php endwhile; ?>
</div>
<?php else :
_e( '<p>Belum ada post.</p>' );
endif;
wp_reset_query (); ?>
</div>
<div class="tab-pane fade" id="kategori2" role="tabpanel" aria-labelledby="kategori2-tab">
<?php $args2 = array(
	'posts_per_page' => $jumlah,
	'showposts' => $jumlah, 
);

$wp_query2 = new WP_Query($args2); 
if($wp_query2->have_posts ()): ?>
<div class="frame-kategori">
<?php while($wp_query2->have_posts()): $wp_query2->the_post();
        echo '<div class="row m-0 py-2 px-1">';
        echo '<div class="col-3 p-0">';
        if ( has_post_thumbnail() ){
          echo '<a href="'.get_the_permalink().'">';
            echo do_shortcode('[resize-thumbnail width="300" height="300" linked="true" class="w-100"]');
          echo '</a>';
        }
		echo '</div>';
		echo '<div class="col-9">';
		$vtitle= get_the_title();
		echo '<div class="vtitle"><a class="text-dark" href="'.get_the_permalink().'">'.substr($vtitle, 0, 60) . ' ...'.'</a></div>';
		echo '<div class="text-muted"><small><i class="fa fa-calendar" aria-hidden="true"></i> '.get_the_date('j F Y',get_the_ID()).'</small></div>';
		echo '</div>';
		echo '</div>';
?>
<?php endwhile; ?>
</div>
<?php else :
_e( '<p>Belum ada post.</p>' );
endif;
wp_reset_query (); ?>
</div>
  
<div class="tab-pane fade" id="kategori3" role="tabpanel" aria-labelledby="kategori3-tab">
<?php $args3 = array(
	'posts_per_page' => $jumlah,
	'showposts' => $jumlah,
	'orderby' => 'comment_count',
	'order' => 'DESC',
);

$wp_query3 = new WP_Query($args3); 
if($wp_query3->have_posts ()): ?>
<div class="frame-kategori">
<?php while($wp_query3->have_posts()): $wp_query3->the_post();
        echo '<div class="row m-0 py-2 px-1">';
        echo '<div class="col-3 p-0">';
        if ( has_post_thumbnail() ){
          echo '<a href="'.get_the_permalink().'">';
		  	echo do_shortcode('[resize-thumbnail width="300" height="300" linked="true" class="w-100"]');
          echo '</a>';
        }
		echo '</div>';
		echo '<div class="col-9">';
		$vtitle= get_the_title();
		echo '<div class="vtitle"><a class="text-dark" href="'.get_the_permalink().'">'.substr($vtitle, 0, 60) . ' ...'.'</a></div>';
		echo '<div class="text-muted"><small><i class="fa fa-calendar" aria-hidden="true"></i> '.get_the_date('j F Y',get_the_ID()).'</small></div>';
		echo '</div>';
		echo '</div>';
?>
<?php endwhile; ?>
</div>
<?php else :
_e( '<p>Belum ada post.</p>' );
endif;
wp_reset_query (); ?>
</div>
</div>


</div>