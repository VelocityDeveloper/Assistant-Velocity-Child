<?php

/**
 * @class FLvposttabs
 */
class FLvposttabs extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct()
	{
		parent::__construct(array(
			'name'          	=> __('Post Tabs', 'fl-builder'),
			'description'   	=> __('Post Tabs by Velocity Developer.', 'fl-builder'),
			'category'      	=> __('Posts', 'fl-builder'),
			'editor_export' 	=> false,
			'partial_refresh'	=> true
		));

		$this->add_css('jquery-bxslider');
		$this->add_js('jquery-bxslider');
	}

}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvposttabs', array(
	'slider'      => array(
		'title'         => __('Tab Posts', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
					'jumlah' => array(
						'type'          => 'text',
						'label'         => __('Posts Total', 'fl-builder'),
						'default'       => '5',
					),
				)
			),

		)
	),
));