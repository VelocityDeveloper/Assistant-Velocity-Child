<?php 
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="velocity-running-text">
<marquee behavior="scroll" scrollamount="5" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
<?php foreach($posts as $post) { ?>
  <a href="<?php echo get_the_permalink($post->ID);?>"><span class="btn btn-sm btn-dark me-2"><?php echo get_the_date('j F Y',$post->ID);?></span><?php echo get_the_title($post);?></a>
  <span class="px-3">|</span>
<?php } ?>
</marquee>
</div>