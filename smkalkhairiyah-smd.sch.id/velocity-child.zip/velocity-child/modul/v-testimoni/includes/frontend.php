<?php $testimonials = $settings->t_columns;
echo '<div id="testimoni-modul" class="testimoni-'.$id.' px-4">';
foreach($testimonials as $testimoni){
    echo '<div class="testimoni-list p-2">';
    echo '<div class="row align-items-center">';
    echo '<div class="col-4 col-sm-2"><div class="foto-testimoni" style="background-image:url('.wp_get_attachment_url($testimoni->image).')" ></div></div>';
    echo '<div class="col-8 col-sm-10 pl-2">';
    echo '<div class="nama-testimoni text-dark fw-bold">'.$testimoni->title.'</div>';
    echo '<div class="prof-testimoni text-secondary">'.$testimoni->profession.'</div>';
    echo '</div>';
    echo '</div>';
    echo '<div class="testimoni-description">'.$testimoni->description.'</div>';
    echo '</div>';
}
echo '</div>';?>
