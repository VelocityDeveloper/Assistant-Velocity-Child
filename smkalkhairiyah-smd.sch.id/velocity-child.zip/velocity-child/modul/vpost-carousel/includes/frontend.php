<?php 

$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="mb-0 second-post slider-bottom-<?php echo $id; ?>">
<?php foreach($posts as $post) { ?>  
<div class="vpostslider-list">
<div class="vpostslider-thumbnail" style="background-image: url(
<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?>
);">
<div class="vpostslider-content">
<div class="vpostslider-title"><a href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post->ID);?></a></div>
<div class="vpostslider-time text-white"><small><?php echo get_the_date( 'j F Y', $post->ID );?></small></div>
<div class="vpostslider-excerpt text-white">
<?php
    $content = $post->post_content;
    $trimmed_content = wp_trim_words( $content, 10 );
    echo $trimmed_content;
?></div>
</div>
</div>
</div>
<?php } ?>
</div>
