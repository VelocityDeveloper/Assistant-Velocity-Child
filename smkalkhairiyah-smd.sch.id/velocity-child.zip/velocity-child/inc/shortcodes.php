<?php
/**
 * Kumpulan shortcode yang digunakan di theme ini.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
//[resize-thumbnail width="300" height="150" linked="true" class="w-100"]
add_shortcode('resize-thumbnail', 'resize_thumbnail');
function resize_thumbnail($atts) {
    ob_start();
	global $post;
    $atribut = shortcode_atts( array(
        'output'	=> 'image', /// image or url
        'width'    	=> '300', ///width image
        'height'    => '150', ///height image
        'crop'      => 'false',
        'upscale'   	=> 'true',
        'linked'   	=> 'true', ///return link to post	
        'class'   	=> 'w-100', ///return class name to img	
        'attachment' 	=> 'true'
    ), $atts );

    $output			= $atribut['output'];
    $attach         = $atribut['attachment'];
    $width          = $atribut['width'];
    $height         = $atribut['height'];
    $crop           = $atribut['crop'];
    $upscale        = $atribut['upscale'];
    $linked        	= $atribut['linked'];
    $class        	= $atribut['class']?'class="'.$atribut['class'].'"':'';
	$urlimg			= get_the_post_thumbnail_url($post->ID,'full');
	
	if(empty($urlimg) && $attach == 'true'){
          $attachments = get_posts( array(
            'post_type' 		=> 'attachment',
            'posts_per_page' 	=> 1,
            'post_parent' 		=> $post->ID,
        	'orderby'          => 'date',
        	'order'            => 'DESC',
          ) );
          if ( $attachments ) {
				$urlimg = wp_get_attachment_url( $attachments[0]->ID, 'full' );
          }
    }

	if($urlimg):
		$urlresize      = aq_resize( $urlimg, $width, $height, $crop, true, $upscale );
		if($output=='image'):
			if($linked=='true'):
				echo '<a href="'.get_the_permalink($post->ID).'" title="'.get_the_title($post->ID).'">';
			endif;
			echo '<img src="'.$urlresize.'" width="'.$width.'" height="'.$height.'" loading="lazy" '.$class.'>';
			if($linked=='true'):
				echo '</a>';
			endif;
		else:
			echo $urlresize;
		endif;

	else:
		if($linked=='true'):
			echo '<a href="'.get_the_permalink($post->ID).'" title="'.get_the_title($post->ID).'">';
		endif;
		echo '<svg style="background-color: #ececec;width: 100%;height: auto;" width="'.$width.'" height="'.$height.'"></svg>';
		if($linked=='true'):
			echo '</a>';
		endif;
	endif;

	return ob_get_clean();
}

//[excerpt count="150"]
add_shortcode('excerpt', 'vd_getexcerpt');
function vd_getexcerpt($atts){
    ob_start();
	global $post;
    $atribut = shortcode_atts( array(
        'count'	=> '150', /// count character
    ), $atts );

    $count		= $atribut['count'];
    $excerpt	= get_the_content();
    $excerpt 	= strip_tags($excerpt);
    $excerpt 	= substr($excerpt, 0, $count);
    $excerpt 	= substr($excerpt, 0, strripos($excerpt, " "));
    $excerpt 	= ''.$excerpt.'...';

    echo $excerpt;

	return ob_get_clean();
}

// [vel-breadcrumbs]
add_shortcode('vd-breadcrumbs','vd_breadcrumbs');
function vd_breadcrumbs() {
    ob_start();
    echo justg_breadcrumb();
    return ob_get_clean();
}

//[ratio-thumbnail size="medium" ratio="16:9"]
add_shortcode('ratio-thumbnail', 'ratio_thumbnail');
function ratio_thumbnail($atts) {
    ob_start();
	global $post;

    $atribut = shortcode_atts( array(
        'size'      => 'medium', // thumbnail, medium, large, full
        'ratio'     => '16:9', // 16:9, 8:5, 4:3, 3:2, 1:1
    ), $atts );

    $size       = $atribut['size'];
    $ratio      = $atribut['ratio'];
    $ratio      = $ratio?str_replace(":","-",$ratio):'';
	$urlimg     = get_the_post_thumbnail_url($post->ID,$size);

    echo '<div class="ratio-thumbnail">';
        echo '<a class="ratio-thumbnail-link" href="'.get_the_permalink($post->ID).'" title="'.get_the_title($post->ID).'">';
            echo '<div class="ratio-thumbnail-box ratio-thumbnail-'.$ratio.'" style="background-image: url('.$urlimg.');">';
                echo '<img src="'.$urlimg.'" loading="lazy" class="ratio-thumbnail-image"/>';
            echo '</div>';
        echo '</a>';
    echo '</div>';

	return ob_get_clean();
}



// [velocity-form-data form="1" show="nama,no-telepon,alamat"]
function velocity_form_data($atts){
    global $wpdb;
    $atribut = shortcode_atts( array(
        'form'   => '',
        'show'   => '',
    ), $atts );
	$form_id        = $atribut['form'];
	$show        = $atribut['show'];
        $cfdb          = apply_filters( 'cfdb7_database', $wpdb );
        $table_name    = $cfdb->prefix.'db7_forms';
        $results       = $cfdb->get_results( "
            SELECT * FROM $table_name 
            WHERE form_post_id = $form_id ORDER BY form_id DESC", OBJECT 
        );
  
    $html = '';
    if(empty($form_id)){
        $html .= '<div class="alert alert-warning">Isikan ID tabel Contact Form 7 yang ingin ditampilkan, contoh: [velocity-form-data form="1" show="nama,no-telepon,alamat"]</div>';
    } elseif(empty($show)){
        $html .= '<div class="alert alert-warning">Isikan kolom yang ingin ditampilkan, contoh: [velocity-form-data form="1" show="nama,no-telepon,alamat"]</div>';
    } elseif( !empty($results) ){
        foreach ($results as $data) {
            $values = unserialize($data->form_value);
            // $html .= '<pre>'.print_r($values,1).'</pre>';
        }
        $ditampilkan = explode(',',$show);
        $html .= '<div class="velocity-cfdb7 table-responsive">';
        $html .= '<table class="table table-bordered">';
        $html .= '<thead class="bg-dark text-white">';
        foreach($ditampilkan as $tampil){
            $key_val = str_replace( array('your-', 'cfdb7_file'), '', esc_html( $tampil ));
            $kolom = str_replace( array('_', '-'), ' ', $key_val);
            $html .= '<th scope="col" class="text-capitalize">'.$kolom.'</th>';
        }
        $html .= '</thead>';
        $html .= '<tbody>';
        foreach ($results as $data) {
            $values = unserialize($data->form_value);
            $html .= '<tr>';
            foreach ($values as $key => $value) {
                if ($key == 'cfdb7_status') {
                    $cfdb7_status = $value;
                } 
                if($key != 'recaptcha' && in_array($key, $ditampilkan) && $cfdb7_status == 'read') {
                    $key = esc_html( $key );
                    $key_val = str_replace( array('your-', 'cfdb7_file'), '', $key);
                    $key_val = str_replace( array('_', '-'), ' ', $key_val);
                    if(is_array($value)){
                        $hasil = $value[0];
                    } else {
                        $hasil = $value;
                    }
                    $html .= '<td class="mb-3">'.$hasil.'</td>';
                }
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';
        $html .= '</div>';
    }
    return $html;
}
add_shortcode('velocity-form-data', 'velocity_form_data');
