
.frame-slide{
    position: relative;
}
.image-post img{
    height: 370px !important;
    width: 100%;
    object-fit: cover;
}
.judul{
    width: 95%;
}
.judul a{
    color: #fff;
    text-shadow: 0 1px 0 rgba(0,0,0,.1);
    font-size: 30px;
    font-weight: 700;
    text-transform: capitalize;
    line-height: 32px;
}
.frame-isi a:hover{
    color: #fff;
}
.frame-luar {
	margin: 0 5px;
	position: relative;
}
.frame-isi{
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 20px;
    background:linear-gradient(180deg,transparent 0,rgba(0,0,0,.65) 70%);
}
.slider-frame-navi img{
    height: 120px !important;
    width: 100%;
    object-fit: cover;
    padding: 0 5px;
    cursor: pointer;
}
.slider-frame-navi .slick-current img,
.slider-frame-navi img:hover{
    opacity: 0.6;
}
.slider-frame-navi .fa-chevron-left {
	position: absolute;
	right: 8px;
	top: -103px;
	padding: 15px;
	background: var(--primary);
	cursor: pointer;
	color: #fff;
}
.slider-frame-navi .fa-chevron-right {
	position: absolute;
	right: 8px;
	top: -55px;
	padding: 15px;
	background: #fff;
	cursor: pointer;
	color: #000;
}