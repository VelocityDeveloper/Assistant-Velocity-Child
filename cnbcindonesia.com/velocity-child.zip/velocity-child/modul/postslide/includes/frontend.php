<?php 
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;
 ?>
<div class="frame-luar">
    <div class="slider-panah"></div>
    <div class="slider-frame-img">
        <?php foreach($posts as $post) { ?>
        		    <div class="frame-slide">
        		        <div class="image-post">
						<img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?>" />
						</div>
        		        <div class="frame-isi text-white">
                            <?php $cats = wp_get_object_terms($post->ID,'category',$args);
                            if ( ! empty( $cats ) ) {
                                if ( ! is_wp_error( $cats ) ) {
                                    echo '<div class="vel-post-slide-categories mb-1">';
                                        foreach( $cats as $term ) {
                                            echo '<small><a class="btn btn-sm btn-primary px-2 py-0 me-2 mb-2 rounded-0" href="' . esc_url( get_term_link( $term->slug, 'category' ) ) . '">' . esc_html( $term->name ) . '</a></small>'; 
                                        }
                                    echo '</div>';
                                }
                            } ?>
                            <div class="judul mb-1">
                                <a href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post);?></a>
                            </div>
                            <small>By <?php the_author_meta( 'display_name', $post->post_author ); ?> - 
                            <?php echo do_shortcode('[tanggal-pos post_id="'.$post->ID.'"]') ?></small>
                        </div>
        		    </div>
        <?php } ?>
    </div>
</div>
<div class="frame-kecil">
<div class="slider-frame-navi">
    <?php foreach($posts as $post) { ?>
        <div><img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?>" /></div>
    <?php } ?>
</div>
</div>