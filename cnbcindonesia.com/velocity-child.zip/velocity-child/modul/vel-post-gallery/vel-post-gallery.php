<?php

/**
 * @class FLvpostGallery
 */
class FLvpostGallery extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __('Post Gallery', 'fl-builder'),
			'description'   	=> __('Post Gallery Product', 'fl-builder'),
			'category'      	=> __('Media', 'fl-builder'),
			'editor_export' 	=> false,
			'partial_refresh'	=> true
		));
		$this->add_styles_scripts();
	}

	/**
	 * @method add_styles_scripts()
	 */
	public function add_styles_scripts() {
		$this->add_js( 'jquery-wookmark' );
		$this->add_js( 'jquery-mosaicflow' );
		$this->add_js( 'imagesloaded' );

		$override_lightbox = apply_filters( 'fl_builder_override_lightbox', false );
		if ( ! $override_lightbox ) {
			$this->add_js( 'jquery-magnificpopup' );
			$this->add_css( 'jquery-magnificpopup' );
		} else {
			wp_dequeue_script( 'jquery-magnificpopup' );
			wp_dequeue_style( 'jquery-magnificpopup' );
		}
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvpostGallery', array(
	'slider'      => array(
		'title'         => __('General', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
				)
			),

		)
	),
));