<?php global $post;
$images = rwmb_meta( 'gallery', array( 'size' => 'thumbnail' ) );
$video = get_post_meta($post->ID,'video',true);
$crop       = true;
$upscale    = true;
	if($video){
		$embed_code = wp_oembed_get($video, array( 'height' => 400 ));
		echo '<div class="vd-post-gallery-video">'.$embed_code.'</div>';
	} elseif($images){
        echo '<div class="vd-post-gallery">';
            echo '<div class="mb-1 id-'.$id.'" id="parent-container">';
                foreach ( $images as $image ) {
                    $urlbesar = aq_resize( $image['full_url'], 900, 460, $crop, true, $upscale );
                    $gambar = get_post($image['ID']);
                    $image_caption = $gambar->post_excerpt;
                    echo '<div class="p-1">';
                    echo '<a class="d-block position-relative" href="'.$image['full_url'].'" title="'.$image_caption.'">';
                    echo '<img class="w-100" src="'.$urlbesar.'">';
                    if($image_caption){
                        echo '<div class="vd-post-gallery-caption">'.$image_caption.'</div>';
                    }
                    echo '</a></div>';
				}
            echo '</div>';
            echo '<div class="navigasi navid-'.$id.'">';
                foreach ( $images as $image ) {
                    $urlbesar = aq_resize( $image['full_url'], 300, 250, $crop, true, $upscale );
                    echo '<div class="p-1"><div class="border">';
                    echo '<img class="w-100" src="'.$urlbesar.'">';
                    echo '</div>';
                    echo '</div>';
                }
            echo '</div>';
        echo '</div>';
    } elseif(has_post_thumbnail($post->ID)) {
        $urlt = get_the_post_thumbnail_url($post->ID,'full');
        $caption = get_the_post_thumbnail_caption($post->ID);
        echo '<div id="parent-container">';
            echo '<a href="'.$urlt.'" title="'.$caption.'"><img class="w-100" src="'.$urlt.'"></a>';
            echo '<div class="pt-2 text-muted">'.$caption.'</div>';
        echo '</div>';
    }
	
?>