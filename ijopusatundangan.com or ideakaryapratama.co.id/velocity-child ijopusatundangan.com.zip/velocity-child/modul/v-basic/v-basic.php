<?php

/**
 * @class FLvBasicModule
 */
class FLvBasicModule extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __('Basic Module', 'fl-builder'),
			'description'   	=> __('Basic Module', 'fl-builder'),
			'category'      	=> __('Basic', 'fl-builder'),
			'editor_export' 	=> false,
			'partial_refresh'	=> true
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvBasicModule', array(
	'slider'      => array(
		'title'         => __('General', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
                    'no'    => array(
                        'type'          => 'text',
                        'label'         => __('Number', 'fl-builder')
                    ),
                    'title' => array(
                        'type'          => 'text',
                        'label'         => __('Title', 'fl-builder'),
                    ),
                    'desc' => array(
                        'type'          => 'textarea',
                        'label'         => __('Description', 'fl-builder'),
                    ),
				)
			),

		)
	),
));