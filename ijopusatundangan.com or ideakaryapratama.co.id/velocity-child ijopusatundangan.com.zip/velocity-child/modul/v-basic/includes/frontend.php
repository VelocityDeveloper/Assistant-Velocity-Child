<div class="vel-basic-modul">
<div class="vel-basic-no"><?php echo $settings->no; ?></div>
<div class="vel-basic-title"><?php echo $settings->title; ?></div>
<div class="vel-basic-desc"><?php echo $settings->desc; ?></div>
</div>