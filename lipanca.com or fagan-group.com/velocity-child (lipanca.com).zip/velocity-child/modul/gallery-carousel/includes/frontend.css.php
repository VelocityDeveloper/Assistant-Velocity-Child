.imm-thumb {
    height: 200px;
    width: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
.imm-style2 {
    height: 80px !important;
    background-size: contain;
}