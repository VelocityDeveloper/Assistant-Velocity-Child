<?php
/**
 * all function for Ongkir.
 *
 * @package Velocity Toko
 */
 
function rApi() {
    return 'b42467445e8f435ac91a173e55f4fa54';
}

function getOngkir($origin,$destination,$berat) {
    $couriers   = velocitytoko_option('courier');		
    $courier    = implode(":",$couriers);

    $response = wp_remote_post( 'http://pro.rajaongkir.com/api/cost' , array(
    	'method'        => 'POST',
    	'timeout'       => 45,
    	'redirection'   => 5,
    	'httpversion'   => '1.0',
    	'blocking'      => true,
        'headers'       => array('key'=> rApi()),
    	'body'          => array( 
    	    'origin'            => $origin,
    	    'originType'        => 'city',
    	    'destination'       => $destination,
    	    'weight'            => $berat,
    	    'courier'           => $courier,
    	    'destinationType'   => 'subdistrict'
    	    ),
        )
    );
    if ( is_array( $response ) ) {
        $body       = $response['body']; // use the content
    }

    return $body; 
}

function getMatauang($idr) {
    global $argRo;
    $response = wp_remote_get( 'http://pro.rajaongkir.com/api/currency', $argRo );
    if ( is_array( $response ) ) {
        $body       = $response['body']; // use the content
        $body       = json_decode($body,true);
    	$kurs       = $body['rajaongkir']['result']['value'];
		if($kurs == 0){
			$html       = 0;
		} else {
			$html       = $idr/$kurs;
		}
    }
    return $html;
}

function getResi($sku,$kurir) {
    global $argRo;
    $response = wp_remote_post( 'http://pro.rajaongkir.com/api/waybill', array(
    	'method'        => 'POST',
    	'timeout'       => 45,
    	'redirection'   => 5,
    	'httpversion'   => '1.0',
    	'blocking'      => true,
        'headers'       => array('key'=> rApi()),
    	'body'          => array( 'waybill' => $sku, 'courier' => $kurir ),
        )
    );
    if ( is_array( $response ) ) {
        $body       = $response['body']; // use the content
    }
    return $body; 
}

function list_velocitytoko_courier() {
    $array = [ 
        'pos'       => 'POS Indonesia (POS)', 
        'lion'      => 'Lion Parcel (LION)',
        'ninja'     => 'Ninja Xpress (NINJA)',
        'ide'       => 'ID Express (IDE)',
        'sicepat'   => 'SiCepat Express (SICEPAT)', 
        'sap'       => 'SAP Express (SAP)', 
        'ncs'       => ' (NCS)', 
        'anteraja'  => 'AnterAja (ANTERAJA)', 
        'rex'       => 'Royal Express Indonesia (REX)', 
        'jtl'       => 'JTL Express (JTL)', 
        'sentral'   => 'Sentral Cargo (SENTRAL)', 
        'jne'       => 'Jalur Nugraha Ekakurir (JNE)',        
        'tiki'      => 'Citra Van Titipan Kilat (TIKI)', 
        'rpx'       => 'RPX Holding (RPX)',  
        'pandu'     => 'Pandu Logistics (PANDU)', 
        'wahana'    => 'Wahana Prestasi Logistik (WAHANA)',
        'jnt'       => 'J&T Express (J&T)',  
        'pahala'    => 'Pahala Kencana Express (PAHALA)', 
        // 'slis'      => 'Solusi Ekspres (SLIS)',
        'dse'       => '21 Express (DSE)',   
        'first'     => 'First Logistics (FIRST)',  
        'star'      => 'Star Cargo (STAR)',
        'idl'       => 'IDL Cargo (IDL)',        
        // 'jet'       => 'JET Express (JET)',
        // 'esl'       => 'Eka Sari Lorena (ESL)', 
        // 'pcp'       => 'Priority Cargo and Package (PCP)',
        // 'cahaya'    => 'Cahaya Logistik (CAHAYA)', 
        // 'indah'     => 'Indah Logistic (INDAH)',
    ];

    return $array;
}