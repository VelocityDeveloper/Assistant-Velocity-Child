<?php
/**
 * Velocity Toko
 */
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Post type Product.
 */
function product_setup_post_type() {
    $args = array(
        'labels' => array(
            'name' => 'Produk',
            'singular_name' => 'product',
            'add_new' => 'Tambah Produk Baru',
            'add_new_item' => 'Tambah Produk Baru',
            'edit_item' => 'Edit Produk',
            'view_item' => 'Lihat Produk',
            'search_items' => 'Cari Produk',
            'not_found' => 'Tidak ditemukan',
            'not_found_in_trash' => 'Tidak ada Produk di kotak sampah'
        ),
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
        ),
        'menu_icon'     => VELOCITY_TOKO_PLUGIN_URL.'admin/img/product.png',
        'has_archive'   => 'products',
        'show_in_rest'  => false,
        'public'        => true,
        'taxonomies' => array('products'),
    );
    register_post_type( 'product', $args );
}
add_action( 'init', 'product_setup_post_type' );

/**
 * Register taxonomy category-product.
 */
add_action( 'init', 'velocitytoko_addon_category_product' );
function velocitytoko_addon_category_product() {
	register_taxonomy(
		'category-product',
		'product',
		array(
			'label' => __( 'Kategori' ),
			'rewrite' => array( 'slug' => 'category-product' ),
			'hierarchical' => true,
            'public' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_nav_menus' => true,
		)
	);
}

/**
 * Register taxonomy merk.
 */
add_action( 'init', 'velocitytoko_addon_merk_product' );
function velocitytoko_addon_merk_product() {
	register_taxonomy(
		'merk',
		'product',
		array(
			'label' => __( 'Merk' ),
			'rewrite' => array( 'slug' => 'merk' ),
			'hierarchical' => true,
		)
	);
}

add_action( 'transition_post_status', 'vsstemmart_new_post_product', 10, 3 );
function vsstemmart_new_post_product( $new_status, $old_status, $post ) {
    if ( 'publish' !== $new_status or 'publish' === $old_status )
        return;
    if ( 'product' !== $post->post_type )
        return; 

    global $post;
    $postID         = $post->ID;
    $harga          = get_post_meta($postID, 'harga', true);
    $hargapromo     = get_post_meta($postID, 'harga_promo', true);
    if ($hargapromo) {
        update_post_meta($postID, 'harga_filter', $hargapromo);
    } else if($harga) {
        update_post_meta($postID, 'harga_filter', $harga);
    }
}

function velocity_save_produk($post_id){
    if(get_post_type($post_id) == 'product'){
    	$harga          = isset($_POST['harga'])?$_POST['harga']:get_post_meta($post_id, 'harga', true);
    	$hargapromo     = isset($_POST['harga_promo'])?$_POST['harga_promo']:get_post_meta($post_id, 'harga_promo', true);
    	if ($hargapromo) {
    		update_post_meta($post_id, 'harga_filter', $hargapromo);
    	} else if($harga) {
    		update_post_meta($post_id, 'harga_filter', $harga);
    	}
    }
}  
add_action('save_post', 'velocity_save_produk');

//Displaying category-product Columns
add_filter( 'manage_taxonomies_for_product_columns', 'category_product_columns' );
function category_product_columns( $taxonomies ) {
    $taxonomies[] = 'category-product';
    return $taxonomies;
}

// manage column product list
function product_custom_columns($defaults,$post_id='') {
    $screen = get_current_screen();
	if($screen->post_type == 'product'){
        $columns = array(
            'cb'                            => '<input type="checkbox" />',
            'featured_image'                => 'Image',
            'title'                         => 'Title',
            'taxonomy-category-product'     => 'Kategori',
            'date'                          => 'Tanggal',
            'stok'                          => 'Stok',
            'harga'                         => 'Harga',
         );
        if( !function_exists( 'WP_Statistics' ) ) {
            $columns['hit'] = 'Hits';
        }
        $columns['harga'] = __( 'Harga', 'vsstemmart' );
        return $columns;
	} else {
		return $defaults;
	}
}
add_filter('manage_product_posts_columns' , 'product_custom_columns');

function custom_columns_data( $column, $post_id ) {
    switch ( $column ) {
    case 'featured_image':
        echo '<img style="width: 75px;height: auto;" src="'.get_the_post_thumbnail_url($post_id ,'thumbnail').'" alt="" />';
        break;
    case 'harga' :
        if(get_post_meta( $post_id , 'harga' , true )){
            echo vsstemmart_number_money(get_post_meta( $post_id , 'harga' , true ));
        } else {
            echo '-';
        }
        break;
    case 'stok' :
        echo get_post_meta( $post_id , 'stok' , true ); 
        break;
    case 'hit' :
        if(!function_exists( 'WP_Statistics' ) ) {
            echo get_post_meta($post_id,'hit',true);
        }
        break; 
    }
}
add_action( 'manage_posts_custom_column' , 'custom_columns_data', 10, 2 ); 