<?php
/**
 * Velocity Toko register page default.
 */
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

//register product template
add_filter( 'template_include', 'velocitytoko_register_product_template' );
function velocitytoko_register_product_template( $template ) {    
    if ( is_singular('product') ) {
        $template = VELOCITY_TOKO_PLUGIN_DIR . 'public/templates/single-product.php';
    }
    if ( is_post_type_archive('product') || is_tax('category-product') || is_tax('merk') ) {
        $template = VELOCITY_TOKO_PLUGIN_DIR . 'public/templates/archive-product.php';
    }
    return $template;
}

//Remove title archive product
add_filter( 'get_the_archive_title', function ($title) {
    if (is_post_type_archive()) {
        $title = post_type_archive_title( '', false );
    } elseif ( is_tax() ) { //for custom post types
        $title = sprintf( __( '%1$s' ), single_term_title( '', false ) );
    }
    return $title;
});