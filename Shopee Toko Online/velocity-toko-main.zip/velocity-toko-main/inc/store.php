<?php
/**
 * Store function.
 *
 * @package Velocity Toko
 */

 // Start session for vsstemmart
function vsstemmart_session() {
    if(!session_id()) {
        session_start();
    }
    $token = bin2hex(random_bytes(32));
    if(empty($_SESSION['token'])){
        $_SESSION['token'] = $token;
    }
}
add_action('init', 'vsstemmart_session');

function vsstemmart_get_harga($post_id = null , $single = false) {
    if(empty($post_id)) {
        global $post;
        $post_id = $post->ID;
    }
    $result         = [];
    $getharga       = get_post_meta($post_id, 'harga', true);
    $gethargapromo  = get_post_meta($post_id, 'harga_promo', true);

    if(!empty($gethargapromo)) {
        $result['harga'] = $gethargapromo;
    } else {
        $result['harga'] = $getharga;
    }
    $result['harga_asli']   = $getharga;
    $result['harga_promo']  = $gethargapromo;

    return $result;
}

function vsstemmart_currency_text() {
    return 'Rp';
}

function vsstemmart_number_money($number = null) {

    if(empty($number))
    return false;

    return vsstemmart_currency_text().' '.number_format((float)$number,0,',','.');    
}

function vsstemmart_sender_email( $original_email_address ) {
    $input = get_site_url();
    $input = trim($input, '/');
    if (!preg_match('#^http(s)?://#', $input)) {
        $input = 'http://' . $input;
    }
    $urlParts = parse_url($input);
    $domain = preg_replace('/^www\./', '', $urlParts['host']);
    return 'shop@'.$domain;
}
function vsstemmart_sender_name( $original_email_from ) {
    return get_bloginfo('name');
}
add_filter( 'wp_mail_from', 'vsstemmart_sender_email' );
add_filter( 'wp_mail_from_name', 'vsstemmart_sender_name' );

function vsstemmart_footer_script() {
    if(velocitytoko_option('wabutton') == 'on'){
        $nowa       = velocitytoko_option('nowa');
        if (substr($nowa, 0, 1) === '0') {
           $nowa    = '62' . substr($nowa, 1);
        } else if (substr($nowa, 0, 1) === '+') {
            $nowa    = '' . substr($nowa, 1);
        }
        if($nowa){
            echo '<a target="_blank" class="h3 wa-float me-2 position-fixed" href="https://wa.me/'.$nowa.'"><span class="text-white"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 16 16"> <path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/> </svg></span> Butuh Bantuan?</a>';
        }
    }
    if(velocitytoko_option('popupstatus') == 'on'){
        if($_COOKIE['popup'] != 'yes'){
            $popup = velocitytoko_option('popup');
            echo '<div class="modalsambutan modal fade" tabindex="-1" role="dialog">';
              echo '<div class="modal-dialog modal-dialog-centered" role="document">';
                echo '<div class="modal-content">';
                    echo '<button type="button" style="z-index:999;right:0px;" class="btn border-0 close text-end px-2 position-absolute" data-bs-dismiss="modal" aria-label="Close">';
                    echo '<span aria-hidden="true">&times;</span>';
                    echo '</button>';
                    echo '<div class="modal-body">';
                    echo $popup;
                    echo '</div>';
                echo '</div>';
              echo '</div>';
            echo '</div>';
        }
    }
    //floating kontak    
    if(velocitytoko_option('veltoko_kontak_floating') == 'on'){      
        echo '<div class="veltoko-kontak-floating">';
            echo '<div class="kontak-floating bg-light border rounded-start p-2">';
                echo do_shortcode('[kontak]');
            echo '</div>';
        echo '</div>';
    }
}
add_action( 'wp_footer', 'vsstemmart_footer_script' );

function vsstemmart_allPage() {
    $popupstatus = velocitytoko_option( 'popupstatus','off' );
    if($popupstatus == 'on'){
        if($_COOKIE['popup'] != 'yes'){
            $cookie_name = "popup";
            $cookie_value = "yes";
            setcookie($cookie_name, $cookie_value, time() + (86400 * 30)); // 86400 = 1 day
        }
    }
    if ( is_singular('post') || is_singular('product') ) {
        global $wpdb,$post;
        $postID         = $post->ID;
        $count_key      = 'hit';
        $harga          = get_post_meta($postID, 'harga', true);
        $hargapromo     = get_post_meta($postID, 'harga_promo', true);
        $hargafilter    = get_post_meta($postID, 'harga_filter', true);
        if(empty($hargafilter)){
            if ($hargapromo) {
                update_post_meta($postID, 'harga_filter', $hargapromo);
            } else if($harga) {
                update_post_meta($postID, 'harga_filter', $harga);
            }
        } else if($hargapromo && $hargafilter != $hargapromo) {
            update_post_meta($postID, 'harga_filter', $hargapromo);
        } else if($harga && $hargafilter != $harga) {
            update_post_meta($postID, 'harga_filter', $harga);
        }
        
        if( function_exists( 'WP_Statistics' ) ) {
            $table_name = $wpdb->prefix . "statistics_pages";
            $results    = $wpdb->get_results("SELECT sum(count) as result_value FROM $table_name WHERE id = $postID");
            $count = $results?$results[0]->result_value:'0';
        } else {
            $count = get_post_meta($postID, $count_key, true);
            $count++;
        } if($count==''){
            $count      = 0;
            delete_post_meta($postID, $count_key);
            add_post_meta($postID, $count_key, '0');
        } else {
            update_post_meta($postID, $count_key, $count);
        }
    }
}
add_action( 'wp', 'vsstemmart_allPage' );

function kirimSMS($tujuan, $body) {
    $userkey = velocitytoko_option('userkey');
    $passkey = velocitytoko_option('passkey');
    $response = wp_remote_post( 'http://velocitydeveloper.zenziva.com/apps/smsapi.php?userkey='.$userkey.'&passkey='.$passkey.'&nohp='.$tujuan.'&tipe=reguler&pesan='.urlencode($body).' ', array(
    	'timeout'       => 45,
    	'redirection'   => 5,
    	'httpversion'   => '1.0',
    	'blocking'      => true,
        )
    );
    if ( is_array( $response ) ) {
        $body       = $response['body']; // use the content
    }
    // return $body;
}

function kirimWA($phone,$text) {
    $curl = curl_init();
    if (substr($phone, 0, 1) === '0') {
        $phone    = '62' . substr($phone, 1);
    } else if (substr($phone, 0, 1) === '+') {
        $phone    = '' . substr($phone, 1);
    }
    $post = [
        'phone' => $phone,
        'text' => $text,
    ];
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://wa3.otomat.web.id/wa/?api_key=xCUaCJI8aswenwm0pNHktczJ6SaTiMYX&api_id=13",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS  => $post
    ));
	$response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
      $body = "cURL Error #:" . $err;
    } else {
      $body = $response;
    }
	//return $body;
}

function kirimwhatsapp($phone=null,$text=null){
    $endpointwa = velocitytoko_option('endpointwa');
    if($endpointwa){
        $url = $endpointwa;
        
    	if (substr($phone, 0, 1) === '0') {
    		$phone    = '62' . substr($phone, 1);
    	} else if (substr($phone, 0, 1) === '+') {
    		$phone    = '' . substr($phone, 1);
    	}
    	
        $response = wp_remote_post( $url, array(
                'method'      => 'POST',
                'timeout'     => 45,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking'    => true,
                'headers'     => array(),
                'body'        => array(
                    'phone' => $phone,
                    'text' => $text
                ),
            )
        );
        
        if ( is_array( $response ) ) {
            $body       = $response['body']; // use the content
        }
    }
}

/**
 * Redirect wp-admin
 */
function possibly_redirect(){
    global $pagenow;
    if( 'wp-login.php' == $pagenow ) {
      if ( isset( $_POST['wp-submit'] ) ||   // in case of LOGIN
        ( isset($_GET['action']) && $_GET['action']=='logout') ||   // in case of LOGOUT
        ( isset($_GET['action']) && $_GET['action']=='lostpassword') ||   // in case of RESET
        ( isset($_GET['action']) && $_GET['action']=='rp') ||   // in case of RP
        ( isset($_GET['checkemail']) && $_GET['checkemail']=='confirm') ||   // in case of LOST PASSWORD
        ( isset($_GET['checkemail']) && $_GET['checkemail']=='registered') ) return;    // in case of REGISTER
      else wp_redirect( get_permalink( get_page_by_path( 'myaccount' ) ) ); // or wp_redirect(home_url('/login'));
      exit();
    }
}
add_action('init','possibly_redirect');

//get taxonomy list
function velocitytoko_term_list($taxonomy=null,$separator=null,$postId=null){
    $terms      = wp_get_post_terms($postId, $taxonomy);
    $term_list  = array();
    foreach ($terms as $term) {
        $term_list[] = '<a href="' . get_term_link($term) . '">' . $term->name . '</a>';
    }
    return implode($separator, $term_list);
}

function velocitytoko_display_recaptcha() {

    $isreCAPTCHA = 0;

    // rand Captcha number
    $captcha = rand(1000,9999);

    //get BWS recaptcha options
    $gglcptch_options = get_option( 'gglcptch_options');       

    echo '<div class="velocitytoko-recaptcha">';
    echo '<label for="kodecaptcha">Isikan Captcha</label>';

        // if BWS reCAPTCHA is installed and activated
        if(function_exists( 'gglcptch_init' ) && $gglcptch_options && ! empty( $gglcptch_options['public_key'] ) && ! empty( $gglcptch_options['private_key'] ) && $gglcptch_options['recaptcha_version'] == 'v2') {
            
            echo apply_filters( 'gglcptch_display_recaptcha', '' );
            echo '<input id="kodecaptcha" name="kodecaptcha" type="hidden" value="'.$captcha.'">';
            $isreCAPTCHA = 1;

        } else {

            // if BWS reCAPTCHA is not installed or not activated
            echo '<div class="row">';
                echo '<div class="col-3 col-md-2 pe-0">';
                    echo '<div class="captcha rounded">';
                        echo '<span class="captcha-text">'.$captcha.'</span>';
                    echo '</div>';
                echo '</div>';
                echo '<div class="col-9 col-md-10"><input class="form-control" id="kodecaptcha" name="kodecaptcha" type="text" required ></div>';
            echo '</div>';

        }

        echo '<input id="idunik" name="idunik" type="hidden" value="'.$captcha.'">';
        echo '<input id="isreCAPTCHA" name="isreCAPTCHA" type="hidden" value="'.$isreCAPTCHA.'">';
    echo '</div>';

}

function velocitytoko_display_tablecart() {
    // get data Keranjang    
    $Cart   = new Vsstemmart\Keranjang;
    $carts  = $Cart->alldata();  
    $nm     = 0; 
    $linkpg = get_permalink(get_page_by_path('Keranjang'));
    ?>
    <div class="card-table-cart">
        <div class="card rounded-0 pt-4">
            <div class="close-card toggle-tablecart position-absolute top-0 end-0">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
                </svg>
            </div>
            <div class="card-body p-0">                
                <?php if($carts): ?>
                    <?php foreach( $carts as $key => $cart): ?>
                        <?php                      
                        if(!empty($cart['id_produk'])){
                            $idthm      = $cart['id_produk'];
                            $idthmpetik = "'".$cart['id_produk']."'";
                        } else {
                            $idthm      = $cart['id'];
                            $idthmpetik = "'".$cart['id']."'";
                        }       
                        $detail     = json_decode($cart['detail'],true);
                        $idproduk   = $detail[0];
                        $jumlah     = $cart['jumlah'];
                        $imgurl     = get_the_post_thumbnail_url( $idproduk,'thumbnail' );   
                        $getharga   = vsstemmart_get_harga($idproduk);        
                        $harga      = $getharga['harga'];
                        $harga      = !empty($detail[2][2])? $detail[2][2] : $harga;                 
                        $namaopsi   = '';
                        if(!empty($detail[1][1])){
                            $namaopsi   .= $detail[1][0].': '.$detail[1][1].' | ';
                        }
                        if(!empty($detail[2][1]) && !empty($detail[2][2])){
                            $namaopsi   .= $detail[2][0].': '.$detail[2][1];
                        }
                        
                        $class  = $nm>0?'border-top mt-2 pt-2':'';
                        ?>
                        <?php if(get_post_status ( $idproduk ) ): ?>
                            <div class="itemcart mx-2 mx-md-4 <?php echo $class;?>">
                                <div class="row" href="<?php echo get_the_permalink($idproduk);?>">
                                    <div class="col-5 col-md-3 col-xl-2">
                                        <?php if($imgurl): ?>
                                        <a href="<?php echo get_the_permalink($idproduk);?>" class="d-inline-block mb-1">
                                            <img src="<?php echo $imgurl;?>" alt=""/>
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col">
                                        <a href="<?php echo get_the_permalink($idproduk);?>" class="fw-bold d-block">
                                            <?php echo get_the_title($idproduk);?>
                                        </a>
                                        <div class="text-muted">Qty: <?php echo $jumlah;?></div>
                                        <?php if($namaopsi): ?>
                                            <div class="text-muted"><?php echo $namaopsi;?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-12 col-md-3 text-md-end d-md-block d-flex justify-content-between">                                    
                                        <div class="fw-bold mb-md-3"><?php echo vsstemmart_number_money($harga);?></div>                                    
                                        <span class="text-muted" id="delete-<?php echo $idthm;?>" data-toggle="tooltip" title="Hapus <?php echo get_the_title($idproduk);?> Dari keranjang" onclick="deleteOrder(<?php echo $idthmpetik;?>)">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16"> <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/> <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/> </svg>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php $nm++; ?>
                    <?php endforeach; ?>
                    <div class="card-footer d-flex justify-content-center">
                        <a class="btn btn-dark rounded-0 px-5 me-2" href="<?php echo $linkpg;?>">View Cart</a>
                        <a class="btn btn-dark rounded-0 px-5 ms-2"  href="<?php echo $linkpg;?>?action=checkout">Checkout</a>
                    </div> 
                <?php else: ?> 
                    <div class="alert alert-secondary text-center mx-3 rounded-0">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart" viewBox="0 0 16 16">
                            <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
                        </svg>
                        Empty Cart
                    </div> 
                <?php endif; ?>                   
            </div>
        </div>
    </div>
    <?php
}

function velocitytoko_opsi_form($post_id=null,$nodeid=null) {
    if(empty($post_id))
    return false;

    $nodeid         = $nodeid?$nodeid:'cart'.uniqid();
    $partid         = 'cart'.uniqid();
    $opsis          = get_post_meta($post_id, 'opsistandart', true);
    $namaopsi       = get_post_meta($post_id, 'namaopsi', true);
    $opsiharga      = get_post_meta($post_id, 'opsiharga', true);
    $namaopsi2      = get_post_meta($post_id, 'namaopsi2', true);
    $stok           = get_post_meta($post_id, 'stok', true);
    $minorder       = get_post_meta($post_id, 'minorder', true);
    $minorder       = $minorder?$minorder:1;
    $maxorder       = $stok?$stok:'';
    $getharga       = vsstemmart_get_harga($post_id);
    $harga          = $getharga['harga_asli'];
    $posttitle      = get_the_title($post_id);
    ?>
    <div class="form-opsi-buy" data-node-cart="<?php echo $nodeid;?>" data-idpost="<?php echo $post_id;?>" data-titlepost="<?php echo $posttitle;?>">
        <?php if($opsis): ?>
            <div class="opsistandart mb-2">
                <div class="fw-bold mb-2"><?php echo $namaopsi;?> :</div>
                <?php foreach($opsis as $ky => $opsi): ?>
                    <?php 
                    $opsititle = $opsi;
                    if (strpos($opsi, '=') !== false) {
                        $explode    = explode('=', $opsi);  
                        $opsititle  = $explode[0];
                    } ?>
                    <span class="d-inline-block mb-1">
                        <input type="radio" value="<?php echo $opsititle;?>" class="btn-check btn-opsistandart opsistandart-<?php echo $post_id;?>" name="opsistandart" id="opsistandart<?php echo $partid.$ky;?>" autocomplete="off" <?php checked( $ky, 0 ); ?>>
                        <label class="btn btn-sm btn-outline-dark" for="opsistandart<?php echo $partid.$ky;?>">
                            <?php if(strpos($opsi, '=') !== false): ?> 
                                <svg style="color: <?php echo $explode[1];?>;vertical-align: -0.105rem;" xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-circle-fill me-1" viewBox="0 0 16 16"> <circle cx="8" cy="8" r="8"/> </svg> 
                            <?php endif; ?>
                            <?php echo $opsititle;?>
                        </label>
                    </span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if($opsiharga): ?>
            <div class="opsiadvance mb-2">
                <div class="fw-bold mb-2"><?php echo $namaopsi2;?> :</div>
                <?php foreach($opsiharga as $ky => $opsi): ?>
                    <?php
                        $explode    = explode('=', $opsi);                        
                        $hrga       = isset($explode[1]) && !empty($explode[1]) ? vsstemmart_number_money($explode[1]) : '';
                    ?>
                    <span class="mb-1">
                        <input type="radio" value="<?php echo $opsi;?>" data-text="<?php echo $explode[0];?>" class="btn-check btn-opsiadvance opsiadvance-<?php echo $post_id;?>" name="opsiadvance" id="opsiadvance<?php echo $partid.$ky;?>" autocomplete="off" <?php checked( $ky, 0 ); ?>>
                        <label class="btn btn-sm btn-outline-dark" data-price="<?php echo $hrga;?>" for="opsiadvance<?php echo $partid.$ky;?>"><?php echo $explode[0];?></label>
                    </span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="inputjumlah mt-3 mb-3">
            <div class="fw-bold mb-2">Jumlah :</div>
            <div class="input-group input-jumlah-beli">
                <button class="btn btn-secondary btn-sm rounded-0" data-input="minus" type="button">-</button>
                <input type="number" name="jumlah" class="form-control form-control-sm opsijumlah-<?php echo $post_id;?> text-center" min="<?php echo $minorder;?>" max="<?php echo $maxorder;?>" value="<?php echo $minorder;?>">
                <button class="btn btn-secondary btn-sm rounded-0" data-input="plus" type="button">+</button>
            </div>
        </div>


    </div>
    <?php
}

function velocitytoko_modal_formbuy($post_id=null,$idmodal=null,$add=null,$nodeid=null) {

    if(empty($post_id) || empty($idmodal))
    return false;

    $nodeid         = $nodeid?$nodeid:'cart'.uniqid();
    $getharga       = vsstemmart_get_harga($post_id);
    $harga          = $getharga['harga_asli'];
    $opsiharga      = get_post_meta($post_id, 'opsiharga', true);
    if($opsiharga){
        $opsih      = $opsiharga[0];
        $opsih      = explode('=', $opsih);
        $harga      = $opsih[1];
    }
    ?>
    <!-- Modal <?php echo $idmodal;?>-->
    <div class="modal modal-opsibuy opsibeli opsibeli-<?php echo $nodeid;?> fade" id="<?php echo $idmodal;?>" tabindex="-1" aria-labelledby="<?php echo $idmodal;?>Label" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title opsibeli-title-<?php echo $nodeid;?>" id="<?php echo $idmodal;?>Label">
                        <?php echo get_the_title($post_id);?>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo velocitytoko_opsi_form($post_id,$nodeid);?>
                </div>
                <div class="modal-footer justify-content-between">
                    <span class="h5 fw-bold opsibeli-harga-<?php echo $nodeid;?> m-0 text-success">
                        <?php echo vsstemmart_number_money($harga);?>
                    </span>
                    <a onclick="opsistandart(<?php echo $post_id;?>)" class="pointer btn btn-dark opsistandart text-white" id="<?php echo $post_id;?>" data-bs-dismiss="modal">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-fill" viewBox="0 0 16 16"> <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/> </svg>
                        <?php echo $add;?>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php
}