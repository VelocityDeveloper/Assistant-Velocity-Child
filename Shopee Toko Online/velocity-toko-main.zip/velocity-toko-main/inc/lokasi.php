<?php
/**
 * function for get lokasi.
 *
 * @package Velocity Toko
 */

function getCityProvince() {
    // delete_option( 'daftarkotadiprovinsi');
    $get_data = get_option( 'daftarkotadiprovinsi');
    
    if($get_data) {
        $respon = $get_data;
    } else {
        $Lokasi = new Vsstemmart\Lokasi;
        $city = $Lokasi->city();
        $kota = [];
        //$kota[0] = 'Pilih kota asal';
        foreach($city as $data){
            $kota[$data['city_id']] = $data['type'].' '.$data['city_name'].' - '.$data['province'];
        }
        add_option( 'daftarkotadiprovinsi', $kota, '', 'yes' );
        $respon = get_option( 'daftarkotadiprovinsi', true );
    }
    
    return $respon;
}

function getProvince($id=null) {
    $Lokasi = new Vsstemmart\Lokasi;
    return $Lokasi->province($id); 
}

function getCity($id=null) {
    $Lokasi = new Vsstemmart\Lokasi;
    return $Lokasi->city($id); 
}

function getSubdistrict($a) {
    $Lokasi = new Vsstemmart\Lokasi;
    return $Lokasi->subdistrictbycity($a); 
}
function getSingleSubdistrict($id) {
    $Lokasi = new Vsstemmart\Lokasi;
    return $Lokasi->subdistrict($id); 
}
function getSingleCity($id) {
    $Lokasi = new Vsstemmart\Lokasi;
    return $Lokasi->city($id); 
}