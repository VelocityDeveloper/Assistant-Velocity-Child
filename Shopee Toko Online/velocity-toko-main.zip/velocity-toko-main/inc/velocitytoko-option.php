<?php
/**
 * function for get all option.
 * 
 * made to manage store velocity settings easier
 *
 * @package Velocity Toko
 */

if(!function_exists('velocitytoko_option')) {
    function velocitytoko_option($option_name = null, $default = null) {

        if(empty($option_name)) {
            return false;
        }

        if ( empty($default) && class_exists( 'Kirki' ) && isset( Kirki::$all_fields[ $option_name ] ) && isset( Kirki::$all_fields[ $option_name ]['default'] ) ) {
            $default = Kirki::$all_fields[ $option_name ]['default'];
        }

        $option_value = get_theme_mod($option_name,$default);

        return $option_value;

    }
}