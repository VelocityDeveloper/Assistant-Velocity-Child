<?php
/**
 * checkout part function.
 *
 * @package Velocity Toko
 */

global $wpdb;
$user_id           = get_current_user_id();
$user_info         = get_userdata($user_id);
$namatoko          = get_bloginfo('name');
$paypalopt         = velocitytoko_option('paypalopt');
$sitekey           = velocitytoko_option('sitekey_recaptcha_velocitytoko');
$secret            = velocitytoko_option('secret_recaptcha_velocitytoko');
$token             = isset($_SESSION['token'])? $_SESSION['token'] :'';
$detailkupon       = isset($_SESSION['kupon']['detail'])? json_decode($_SESSION['kupon']['detail'],true) :'';
$jeniskupon        = isset($detailkupon['jenis'])? $detailkupon['jenis'] : '';
$kodekupon         = isset($detailkupon['kode'])? $detailkupon['kode'] : '';
$potongankupon     = isset($detailkupon['potongan'])? $detailkupon['potongan'] : '';
$minorder          = isset($detailkupon['minorder'])? $detailkupon['minorder'] : '';
$statusdropship    = velocitytoko_option('dropshipstatus');
$getnama           = get_user_meta( $user_id, 'namatoko', true );
$getalamat         = get_user_meta( $user_id, 'alamattoko', true );
$userdropship      = get_user_meta( $user_id, 'statusdropship', true );
$j=0;
?>

<form name="chckout" method="post" id="chckout" action="?action=finish">
 <div class="row">
    <?php require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/checkout-form.php'; ?>
    <div class="col-md-5">
        <h5 class="text-colortheme fw-bold">Info Pesanan</h5>
        <?php
        echo '<table class="table tabel-keranjang"><tbody>';

        //get data Keranjang        
        $Cart   = new Vsstemmart\Keranjang;
        $carts  = $Cart->alldata();

        $subtotal = 0;
        $berat = 0;
        echo '<tr class="bg-light">';
            echo '<td >';
                echo 'Produk';
            echo '</td>';
            echo '<td class="text-end">';
                echo 'Harga';
            echo '</td>';
        echo '</tr>';
        
        ///START Loop CARTS
        foreach($carts as $cart){

            $detail = json_decode($cart['detail'],true);
            $idproduk = $detail[0];
            $i= $j++;
            $namaopsi = '';
            $valuenamaopsi = '';
            if(isset($detail[1][1]) && $detail[1][1]){
                $namaopsi .= '<br>'.$detail[1][0].': '.$detail[1][1];
                $valuenamaopsi .= ''.$detail[1][0].': '.$detail[1][1];
            }
            if(isset($detail[2][1]) && $detail[2][1] && $detail[2][2]){
                $namaopsi .= '<br>'.$detail[2][0].': '.$detail[2][1];
                $valuenamaopsi .= ','.$detail[2][0].': '.$detail[2][1];
            }
            $getharga = vsstemmart_get_harga($idproduk);
            $harga      = $getharga['harga'];
            $hargaasli  = $getharga['harga_promo']?$getharga['harga_asli']:'';

            $harga = !empty($detail[2][2])? $detail[2][2] : $harga;
            $jumlah = $cart['jumlah'];
            $min = get_post_meta($idproduk, 'minorder', true);
            if($jumlah < $min){
                $jumlah = $min;
            }
            echo '<input type="hidden" name="produk[products]['.$i.'][id]" value="'.$idproduk.'" class="form-control"/>';
            echo '<input type="hidden" name="produk[products]['.$i.'][nama]" value="'.get_the_title($idproduk).'" class="form-control"/>';
            echo '<input type="hidden" name="produk[products]['.$i.'][img]" value="'.get_the_post_thumbnail_url( $idproduk ,'full' ).'" class="form-control"/>';
            echo '<input type="hidden" name="produk[products]['.$i.'][harga]" value="'.$harga.'" class="form-control"/>';
            echo '<input type="hidden" name="produk[products]['.$i.'][hargaasli]" value="'.$hargaasli.'" class="form-control"/>';
            echo '<input type="hidden" name="produk[products]['.$i.'][jumlah]" value="'.$jumlah.'" class="form-control"/>';
            echo '<input type="hidden" name="produk[products]['.$i.'][berat]" value="'.get_post_meta($idproduk, 'berat', true).'" class="form-control"/>';
            if($namaopsi){
                echo '<input type="hidden" name="produk[products]['.$i.'][isiopsi]" value="'.$valuenamaopsi.'" class="form-control"/>';
            }
            echo '<tr class="noborder">';
                echo '<td>';
                    echo get_the_title($idproduk).''.$namaopsi.'<br>';
                echo '</td>';
                echo '<td class="text-end">';
                    echo '<span class="subtotal" >'.vsstemmart_number_money($harga*$jumlah).'</span><br>';
                    echo '<small>'.$jumlah.' x '.vsstemmart_number_money($harga);
                    echo '</small>';
                    $subtotal +=$harga*$jumlah;
                    $berat +=get_post_meta($idproduk, 'berat', true)*$jumlah;
                echo '</td>';
            echo '</tr>';
        }
        //END loop Carts

        echo '<input type="hidden" name="produk[berattotal]" value="'.($berat * 1000).'" class="form-control"/>';
        echo '<input type="hidden" name="invoice" value="'.mt_rand(100000000, 999999999).'" class="form-control invoice"/>';
        echo "<input type='hidden' name='produk[kupon][kode]' value='".$kodekupon."' class='form-control'/>";
        echo "<input type='hidden' name='produk[kupon][potongan]' value='".$potongankupon."' class='form-control'/>";
        echo "<input type='hidden' name='produk[kupon][jenis]' value='".$jeniskupon."' class='form-control'/>";
        echo "<input type='hidden' name='token' value='".$token."' class='form-control'/>";

        echo '<tr class="bg-light">';
            echo '<td >';
                echo 'Subtotal:';
            echo '</td>';
            echo '<td class="text-end">';
                $ongkir         = '0';
                if($jeniskupon=='percent' && $subtotal>=$minorder){
                    $subtotalold    = $subtotal;
                    $subtotal       = $subtotal-($subtotal*$potongankupon/100);
                    echo '<div class="totalharga">'.vsstemmart_number_money($subtotal).' <s><small>'.vsstemmart_number_money($subtotalold).'</small></s></div>';
                    echo '<span class="text-muted"><small>*Mendapat Potongan '.$potongankupon.'% dari Kode Promo.</small></span>';
                } else if($jeniskupon=='rupiah' && $subtotal>=$minorder){
                    $subtotalold    = $subtotal;
                    $subtotal       = $subtotal-$potongankupon;
                    echo '<div class="totalharga">'.vsstemmart_number_money($subtotal).' <s><small>'.vsstemmart_number_money($subtotalold).'</small></s></div>';
                    echo '<span class="text-muted"><small>*Mendapat Potongan '.vsstemmart_number_money($potongankupon).' dari Kode Promo.</small></span>';
                } else if($jeniskupon=='ongkir' && $subtotal>=$minorder){
                    $ongkir         = $potongankupon;
                    echo '<div class="totalharga">'.vsstemmart_number_money($subtotal).'</div>';
                    echo '<span class="text-muted"><small>*Mendapat Potongan Ongkir '.vsstemmart_number_money($potongankupon).' dari Kode Promo.</small></span>';
                } else {
                    echo '<div class="totalharga">'.vsstemmart_number_money($subtotal).'</div>';
                }
                echo '<input type="hidden" class="potonganongkir" name="produk[potongan-ongkir]" value="'.$ongkir.'" class="form-control"/>';
                echo '<input type="hidden" class="subhargatotal" name="produk[subhargatotal]" value="'.$subtotal.'" class="form-control"/>';
                echo '<input type="hidden" class="hargatotal" name="produk[hargatotal]" value="'.$subtotal.'" class="form-control"/>';
            echo '</td>';
        echo '</tr>';
        echo '<tr>';
            echo '<td >';
                echo 'Berat Total:';
            echo '</td>';
            echo '<td class="text-end">';
                echo '<span class="totalberat">'.($berat * 1000).'</span> Gram';
            echo '</td>';
        echo '</tr>';
        echo '<tr>';
            echo '<td >';
                echo 'Ongkir:';
            echo '</td>';
            echo '<td class="text-end">';
                echo '<div class="ongkir"><span class="text-danger">Tentukan Alamat</span></div>';
                echo '<input type="hidden" class="nilaiongkir" name="nilaiongkir" value="0">';
            echo '</td>';
        echo '</tr>';
        echo '<tr class="bg-secondary text-white">';
                echo '<td >';
                    echo 'Total:';
                echo '</td>';
                echo '<td class="text-end">';
                    echo vsstemmart_currency_text().' <span class="total">'.number_format($subtotal,0,',','.').'</span>';
                echo '</td>';
        echo '</tr>';
        echo '<tr>';
            echo '<td >';
                echo '<b>Catatan:</b>';
            echo '</td>';
            echo '<td class="text-end">';
                echo '<textarea maxlength="114" name="catatan" class="form-control"></textarea>';
            echo '</td>';
        echo '</tr>';
        echo '<tr class="bg-light text-dark">';
            echo '<td >';
                echo 'Pembayaran:';
            echo '</td>';
            echo '<td >';
        		echo '<section id="accordion">';
        			echo '<div class="tf-bayar">';
        				echo '<input type="radio" name="pembayaran" id="bank" value="bank" required/>';
        				echo '<label for="bank"> Transfer Bank</label>';
        				echo '<article class="text-center">';
        				    echo do_shortcode('[bank atasnama="false" norek="false"]');
        				echo '</article>';
        			echo '</div>';
        			
        			echo '<div class="cod-bayar">';
        			    echo '<input type="radio" name="pembayaran" id="cod-pay" value="codpay" required/>';
        			    echo '<label for="bank"> Bayar di Tempat (COD) </label>';
        			echo '</div>';
        			
        			if($paypalopt=='on'){
            			echo '<div>';
            				echo '<input type="radio" name="pembayaran" id="paypal" value="paypal" />';
            				echo '<label for="paypal"> Paypal</label>';
            				echo '<article>';
            				    echo do_shortcode('[paypal]');
            				echo '</article>';
            			echo '</div>';
        			}
        		echo '</section>';
            echo '</td>';
        echo '</tr>';
        if($sitekey && $secret){
            echo '<tr>';
                echo '<td colspan="2" class="text-start">';
                    echo '<div id="recaptcha" class="g-recaptcha" data-callback="checkCaptcha" data-expired-callback="expiredCaptcha" data-sitekey="'.$sitekey.'"></div>';
                    echo '<div id="msgCaptcha"> </div>';
                echo '</td>';
            echo '</tr>';
            echo '<tr class="bg-light text-dark">';
                echo '<td colspan="2">';
                    echo '<button id="btn-validate" type="submit" class="btn btn-danger pointer d-block btn-sm ms-auto me-0 border-0" >Konfirmasi Pesanan</button>';
                echo '</td>';
            echo '</tr>';
        } else {
            echo '<tr class="bg-light text-dark">';
                echo '<td colspan="2">';
                    echo '<button type="submit" class="btn btn-danger pointer d-block btn-sm ms-auto me-0 border-0" >Konfirmasi Pesanan</button>';
                echo '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        ?>
    </div>
</div>
</form>