<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
$hasil = $resi?json_decode(getResi($resi,strtolower($kurir)), TRUE):'';
if($hasil && $hasil['rajaongkir']['status']['description']=='OK'){
	$tracking = '<div class="frame-tracking">';
		$tracking .= '<h3 class="text-colortheme">Tracking</h3>';
    	$tracking .= '<table class="table">';
            $tracking .= '<tr>';
                $tracking .= '<th colspan="2"><strong>Detail Pengiriman</strong></th>';
            $tracking .= '</tr>';
            $tracking .= '<tr>';
                $tracking .= '<td>Ekspedisi</td>';
                $tracking .= '<td>'.$hasil['rajaongkir']['result']['summary']['courier_name'].'</td>';
            $tracking .= '</tr>';
            $tracking .= '<tr>';
                $tracking .= '<td>Nomor Resi</td>';
                $tracking .= '<td>'.$hasil['rajaongkir']['result']['summary']['waybill_number'].'</td>';
            $tracking .= '</tr>';
            $tracking .= '<tr>';
                $tracking .= '<td>Jenis Layanan</td>';
                $tracking .= '<td>'.$hasil['rajaongkir']['result']['summary']['service_code'].'</td>';
            $tracking .= '</tr>';
            $tracking .= '<tr>';
                $tracking .= '<td>Tanggal Pengiriman</td>';
                $tracking .= '<td>'.$hasil['rajaongkir']['result']['summary']['waybill_date'].', '.$hasil['rajaongkir']['result']['details']['waybill_time'].'</td>';
            $tracking .= '</tr>';
            $tracking .= '<tr>';
                $tracking .= '<td>Berat</td>';
                $tracking .= '<td>'.$hasil['rajaongkir']['result']['details']['weight'].'</td>';
            $tracking .= '</tr>';
            $tracking .= '<tr>';
                $tracking .= '<td>Status</td>';
                $tracking .= '<td>'.$hasil['rajaongkir']['result']['summary']['status'].'</td>';
            $tracking .= '</tr>';
    	$tracking .= '</table>';
    	
    	$tracking .= '<br/>';
    	$tracking .= '<table class="table">';
            $tracking .= '<tr>';
                $tracking .= '<th colspan="2"><strong>Data Pengirim & Penerima</strong></th>';
            $tracking .= '</tr>';
            $tracking .= '<tr>';
                $tracking .= '<td>Dikirim Dari</td>';
                $tracking .= '<td>'.$hasil['rajaongkir']['result']['summary']['shipper_name'].' ('.$hasil['rajaongkir']['result']['summary']['origin'].')</td>';
            $tracking .= '</tr>';
            $tracking .= '<tr>';
                $tracking .= '<td>Kepada</td>';
                $tracking .= '<td>'.$hasil['rajaongkir']['result']['summary']['receiver_name'].' ('.$hasil['rajaongkir']['result']['summary']['destination'].')</td>';
            $tracking .= '</tr>';
    	$tracking .= '</table>';
	    $tracking .= '<br/>';
			  
	    $tracking .= '<h3 class="text-colortheme">Status Pengiriman</h3>';
    	$tracking .= '<table class="table table-striped">';
            $tracking .= '<tr>';
                $tracking .= '<th>Tanggal</th>';
                $tracking .= '<th>Status</th>';
            $tracking .= '</tr>';
            for ($j=0; $j < count($hasil['rajaongkir']['result']['manifest']); $j++) {
                $tracking .= '<tr>';
                    $tracking .= '<td>'.$hasil['rajaongkir']['result']['manifest'][$j]['manifest_date'].' '.$hasil['rajaongkir']['result']['manifest'][$j]['manifest_time'].'</td>';
                    $tracking .= '<td>'.$hasil['rajaongkir']['result']['manifest'][$j]['manifest_description'].'</td>';
                $tracking .= '</tr>';
            } 
    	$tracking .= '</table>';
	    $tracking .= '<br/>';
	$tracking .= '</div>';
}