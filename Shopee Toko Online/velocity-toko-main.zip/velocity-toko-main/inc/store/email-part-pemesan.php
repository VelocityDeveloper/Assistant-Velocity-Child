<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
$pemesan = '<table style="width:100%"><tbody>';
    $pemesan .= '<tr>';
        $pemesan .= '<td>Nama </td>';
        $pemesan .= '<td>';
            $pemesan .= $nama;
        $pemesan .= '</td>';
    $pemesan .= '</tr>';
    $pemesan .= '<tr>';
        $pemesan .= '<td>Alamat </td>';
        $pemesan .= '<td>';
            $pemesan .= $alamat;
        $pemesan .= '</td>';
    $pemesan .= '</tr>';
    $pemesan .= '<tr>';
        $pemesan .= '<td>Kota </td>';
        $pemesan .= '<td>';
            $pemesan .= $kodekecamatan[0]['city'];
        $pemesan .= '</td>';
    $pemesan .= '</tr>';
    $pemesan .= '<tr>';
        $pemesan .= '<td>Provinsi </td>';
        $pemesan .= '<td>';
            $pemesan .= $kodekecamatan[0]['province'];
        $pemesan .= '</td>';
    $pemesan .= '</tr>';
    $pemesan .= '<tr>';
        $pemesan .= '<td>Kecamatan</td>';
        $pemesan .= '<td>';
            $pemesan .= $kodekecamatan[0]['subdistrict_name'];
        $pemesan .= '</td>';
    $pemesan .= '</tr>';
    $pemesan .= '<tr>';
        $pemesan .= '<td>Kode POS</td>';
        $pemesan .= '<td>';
            $pemesan .= $kodepos;
        $pemesan .= '</td>';
    $pemesan .= '</tr>';
$pemesan .= '</tbody></table>';