<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/email-part-produk.php';
require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/email-part-pemesan.php';

$buyeremail = velocitytoko_option('buyeremail');

$head   = '<h3 style="font-size: 18px;color: #fff;text-transform: uppercase;background-color: #c4527c;padding: 5px;">'.$namatoko.' Invoice #'.$invoice.'</h3>';
$body   = '<div style="margin:0 auto;max-width:600px;border: 1px solid #ddd;padding:15px;">'.$head.''.$buyeremail.'</div>';
$body   = str_replace('[nama-pemesan]',$nama,$body);
$body   = str_replace('[nama-toko]',$namatoko,$body);
$body   = str_replace('[kode-pesanan]',$invoice,$body);
$body   = str_replace('[detail-pesanan]',$detailproduk,$body);
$body   = str_replace('[data-pemesan]',$pemesan,$body);
$body   = str_replace('[tanggal-order]',$date,$body);
$body   = str_replace('[email-cust]',$email,$body);
$body   = str_replace('[nomor-rekening]',$norek,$body);
$body   = str_replace('[alamat-toko]',$alamattoko,$body);
$body   = str_replace('[total-order]',$hargatotal,$body);

///set header Email
$headers   = [];
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=utf-8';
// Additional headers
$headers[] = 'From: '.$namatoko.' <'.$emailtoko.'>';
// $headers[] = 'To: '.$nama.' <'.$email.'>';
// $headers[] = 'Cc: '.$emailtoko.'';
// $headers[] = 'Bcc: '.$emailtoko.'';  
//subject Email
$subject = 'Terimakasih telah berbelanja, berikut detail pesanan untuk Invoice #'.$invoice;

// echo $body;

//kirim ke pembeli 
$sendhtml = wp_mail( $email, $subject, $body, implode("\r\n", $headers) );

//jika gagal kirim karena HTML, hapus HTML tag
if(!$sendhtml) {
    $headers = 'From: '.$namatoko.' <'.$emailtoko.'>';
    wp_mail( $email, $subject, $body, $headers );
}
