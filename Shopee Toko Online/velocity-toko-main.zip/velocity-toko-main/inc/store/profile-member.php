<?php
$user_id    = get_current_user_id();
$chars      = 'abcdefghijklmnopqrstuvwxyz';
$uniqsess   = uniqid().substr(str_shuffle($chars), 0, 5);

//session
if(!isset($_SESSION['uniqsess'])) {
    $_SESSION['uniqsess'] = $uniqsess;
}

//input form
if(isset($_POST['uniqsess']) && ($_POST['uniqsess'] == $_SESSION['uniqsess'])) {
    
    //update meta user
    update_user_meta( $user_id, 'nama', $_POST['nama'] );
    update_user_meta( $user_id, 'hp', $_POST['hp'] );
    update_user_meta( $user_id, 'alamat', $_POST['alamat'] );
    update_user_meta( $user_id, 'kodepos', $_POST['kodepos'] );
    
    if(isset($_POST['subdistrict_destination'])) {
        update_user_meta( $user_id, 'subdistrict_destination', $_POST['subdistrict_destination'] );
    }
    
    ///alert success
    echo '<div class="alert alert-success my-2">Data anda berhasil diupdate</div>';
    
    $_SESSION['uniqsess'] = $uniqsess;
}


$nama       = get_user_meta( $user_id, 'nama',true )?get_user_meta( $user_id, 'nama',true ):'';
$hp         = get_user_meta( $user_id, 'hp',true )?get_user_meta( $user_id, 'hp',true ):'';
$alamate    = get_user_meta( $user_id, 'alamat',true )?get_user_meta( $user_id, 'alamat',true ):'';
$kodepos    = get_user_meta( $user_id, 'kodepos',true )?get_user_meta( $user_id, 'kodepos',true ):'';
$alamat     = get_user_meta( $user_id, 'subdistrict_destination',true )?getSingleSubdistrict(get_user_meta( $user_id, 'subdistrict_destination',true )):'';
$prov       = !empty($alamat)&&isset($alamat[0])?$alamat[0]['province_id']:'';
$city       = !empty($alamat)&&isset($alamat[0])?$alamat[0]['city_id']:'';
$subst      = !empty($alamat)&&isset($alamat[0])?$alamat[0]['subdistrict_id']:'';
// print_r($alamat);
?>

<div class="mb-3 pt-3">
    
    <form action="" method="POST">
        <div class="card">
            <div class="card-header d-flex mx-0 align-items-center bg-secondary text-white">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle me-2" viewBox="0 0 16 16"> <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/> <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/> </svg> Profile
            </div>
            <div class="card-body">
                <div class="form-group mb-3">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" name="nama" placeholder="Nama anda" value="<?php echo $nama; ?>">
                </div>
                <div class="form-group mb-3">
                    <label for="hp">No HP</label>
                    <input type="text" class="form-control" name="hp" placeholder="Nomor telepon" value="<?php echo $hp; ?>">
                </div>
                <div class="form-group mb-3">
                    <label for="alamat">Alamat</label>
                    <textarea class="form-control" name="alamat" placeholder="Detail alamat anda"><?php echo $alamate; ?></textarea>
                </div>
                <div class="form-group mb-3">
                    <label for="prov_destination">Provinsi</label>
                    <select name="prov_destination" id="prov-destination" class="form-control datapengiriman"><option class="" value="">Provinsi</option>
            		        <?php
            				$data_province = getProvince();
            		        for ($i=0; $i < count($data_province); $i++) {
            		                $selec = ($data_province[$i]['province_id'] == $prov)?'selected':'';
                                    echo "<option value='".$data_province[$i]['province_id']."' ".$selec.">".$data_province[$i]['province']."</option>";
            		        }
            				?>
            		</select>
                </div>
                <div class="form-group mb-3">
                    <label for="city_destination">Kota</label>
                        <select name="city_destination" id="city-destination" class="form-control datapengiriman"><option selected class="" value="" >Kota</option>
                		      <?php
                		      $data_City = getCity();
                		      for ($x=0; $x < count($data_City); $x++) {
                		          $type = $data_City[$x]['type'];
                                  if( $type == 'Kabupaten'){
                                      $type = 'Kab';
                                  }
        		                  $selec = ($data_City[$x]['city_id'] == $city)?'selected':'';
                                  echo "<option value='".$data_City[$x]['city_id']."' class='". $data_City[$x]['province_id']."' ".$selec.">".$type." ".$data_City[$x]['city_name']."</option>";
                		      }
                			  ?>
                		</select>
                </div>
                <div class="form-group mb-3">
                    <label for="subdistrict_destination">Kecamatan</label>
                        <select name="subdistrict_destination" id="subdistrict-destination" class="form-control datapengiriman">
                        <?php
                        if($alamat){
                            $a = $alamat[0]['city_id'];
                            $data_Subdistrict = getSubdistrict($a);
                            echo "<option value=''>Kecamatan</option>";
                            for ($x=0; $x < count($data_Subdistrict); $x++) {
        		                $selec = ($data_Subdistrict[$x]['subdistrict_id'] == $subst)?'selected':'';
                                echo "<option value='".$data_Subdistrict[$x]['subdistrict_id']."' class='". $data_Subdistrict[$x]['city_id']."' ".$selec.">".$data_Subdistrict[$x]['subdistrict_name']."</option>";
                            }
                        }
                        ?>
                        </select>
                </div>
                <div class="form-group mb-3">
                    <label for="kodepos">Kode Pos</label>
                    <input type="text" class="form-control" name="kodepos" placeholder="Kodepos" value="<?php echo $kodepos; ?>">
                </div>
                <div class="text-end">
                    <button type="submit" class="btn btn-dark">Simpan</button>
                </div>
                <input type="hidden" name="uniqsess" value="<?php echo $_SESSION['uniqsess']; ?>">
            </div>
        </div>
    </form>
    
</div>
