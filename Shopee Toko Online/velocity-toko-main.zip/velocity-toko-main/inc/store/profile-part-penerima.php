<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */

$dp_prov    = isset($kodekec[0]['province'])?$kodekec[0]['province']:'';
$dp_city    = isset($kodekec[0]['city'])?$kodekec[0]['city']:'';
$dp_subd    = isset($kodekec[0]['subdistrict_name'])?$kodekec[0]['subdistrict_name']:'';

$detailpenerima  = '<strong>Detail Penerima</strong>';
$detailpenerima .= '<p><table class="table-sm table table-borderless">';
$detailpenerima .= '<tr><td>Nama</td><td>: '.$nama.'</td></tr>';
$detailpenerima .= '<tr><td>Alamat</td><td>: '.$alamat.'</td></tr>';
$detailpenerima .= '<tr><td>Provinsi</td><td>: '.$dp_prov.'</td></tr>';
$detailpenerima .= '<tr><td>Kota</td><td>: '.$dp_city.'</td></tr>';
$detailpenerima .= '<tr><td>Kecamatan</td><td>: '.$dp_subd.'</td></tr>';
$detailpenerima .= '<tr><td>Kode Pos</td><td>: '.$kodepos.'</td></tr>';
$detailpenerima .= '</table></p>';