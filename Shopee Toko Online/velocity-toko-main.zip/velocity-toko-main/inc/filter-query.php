<?php
/**
 * The template for modify query product
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package velocity toko
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

function velocitytoko_product_custom_query( $query ) {

    if ( is_archive() && is_post_type_archive( 'product' )  && $query->is_main_query() ) {

        //sort by
        $short  = isset($_GET['short'])?$_GET['short']:'';
        if ($short=='murah') {
            $query->set( 'orderby', 'meta_value_num');
            $query->set( 'meta_key', 'harga_filter');
            $query->set( 'order', 'DESC');
        } else if ($short=='mahal') {
            $query->set( 'orderby', 'meta_value_num');
            $query->set( 'meta_key', 'harga_filter');
            $query->set( 'order', 'ASC');
        } else if($short=='baru') {
            $query->set( 'orderby', 'date');
            $query->set( 'order', 'DESC');
        } else if($short=='lama') {
            $query->set( 'orderby', 'date');
            $query->set( 'order', 'ASC');
        } else if($short=='namaa') {
            $query->set( 'orderby', 'title');
            $query->set( 'order', 'ASC');
        } 

        //metaquery
        $metaquery = array();

        //metaquery list label 
        $listlabel  = isset($_GET['label'])?$_GET['label']:'';
        if($listlabel) {
            $metaquery[] = array(
                'key'       => 'label',
                'value'     => $listlabel,
                'compare'   => 'IN'
            );
        }

        //metaquery harga
        $rangeharga     = isset($_GET['rangeharga'])?explode('-',$_GET['rangeharga']):'';
        $hargamin       = '';
        $hargamax       = '';
        if(!empty($_GET['rangeharga'])){
            $hargamin   = preg_replace('/[^0-9]/', '', $rangeharga[0]);
            $hargamax   = preg_replace('/[^0-9]/', '', $rangeharga[1]);
        }
        if($hargamin){
            $metaquery[] = array(
                'key'       => 'harga',
                'value'     => $hargamin,
                'compare'   => '>',
                'type'      => 'numeric',
            );
        }
        if($hargamax){
            $metaquery[] = array(
                'key'       => 'harga',
                'value'     => $hargamax,
                'compare'   => '<',
                'type'      => 'numeric',
            );
        }

        //if count metaquery more than 1, then set metaquery
        if(count($metaquery)>1){
            $metaquery['relation'] = 'AND';
        }

        if($metaquery) {
            $query->set( 'meta_query', $metaquery);
        }

        //taxonomy query
        $taxquery = array();

        //taxonomy category-product 
        $kategori = isset($_GET['setkategori'])? $_GET['setkategori'] :'';
        if($kategori) {
            $taxquery[] = array(
                'taxonomy' => 'category-product',
                'field'    => 'term_id',
                'terms'    => $kategori,
            );
        }

        //taxonomy merk 
        $merk = isset($_GET['setmerk'])? $_GET['setmerk'] :'';
        if($merk) {
            $taxquery[] = array(
                'taxonomy' => 'merk',
                'field'    => 'term_id',
                'terms'    => $merk,
            );
        }

        //if count taxquery more than 1, then set taxquery
        if(count($taxquery)>1){
            $taxquery['relation'] = 'AND';
        }

        if($taxquery) {
            $query->set( 'tax_query', $taxquery);
        }

        $query->set( 'post_type', 'product');

    }
}
add_filter( 'pre_get_posts', 'velocitytoko_product_custom_query' );
