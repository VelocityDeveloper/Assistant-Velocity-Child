<?php
/**
 * Velocity Toko register page default.
 */
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

//regsiter page template
add_filter( 'template_include', 'velocitytoko_register_page_template' );
function velocitytoko_register_page_template( $template ) {

    if ( is_singular() ) {
        $page_template = get_post_meta( get_the_ID(), '_wp_page_template', true );
        if ( 'velocitytoko-templates_keranjang' === $page_template ) {
            $template = VELOCITY_TOKO_PLUGIN_DIR . 'public/templates/page/page-keranjang.php';
        } elseif('velocitytoko-templates_profile' === $page_template){
            $template = VELOCITY_TOKO_PLUGIN_DIR . 'public/templates/page/page-profile.php';
        } elseif('velocitytoko-templates_katalog' === $page_template){
            $template = VELOCITY_TOKO_PLUGIN_DIR . 'public/templates/page/page-katalog.php';
        }
    }

    return $template;
}
function velocitytoko_templates_page($post_templates) {

    $post_templates['velocitytoko-templates_keranjang'] = __( 'Velocity Toko Keranjang', 'velocity-toko' );
    $post_templates['velocitytoko-templates_profile']   = __( 'Velocity Toko Profile', 'velocity-toko' );
    $post_templates['velocitytoko-templates_katalog']   = __( 'Velocity Toko Katalog', 'velocity-toko' );

    return $post_templates;
}
add_filter( "theme_page_templates", 'velocitytoko_templates_page' );


// Register Keranjang Page
add_filter( 'after_setup_theme', 'vsstemmart_create_keranjang' );
function vsstemmart_create_keranjang() {
	$post_id        = -1;
	$slug           = 'keranjang';
	$title          = 'Keranjang';
	if( null == get_page_by_path( $slug ) ) {
		$post_id = wp_insert_post(
			array(
				'comment_status'	=>	'closed',
				'ping_status'		=>	'closed',
				'post_author'		=>	'1',
				'post_name'			=>	$slug,
				'post_title'		=>	$title,
				'post_status'		=>	'publish',
				'post_type'			=>	'page',
				'page_template'		=>  'velocitytoko-templates_keranjang'
			)
		);
	} else {
    		$post_id = -2;
	}
}

// Register Profile Page
add_filter( 'after_setup_theme', 'vsstemmart_create_profile' );
function vsstemmart_create_profile() {
	$post_id        = -1;
	$slug           = 'myaccount';
	$title          = 'My Account';
	if( null == get_page_by_path( $slug ) ) {
		$post_id = wp_insert_post(
			array(
				'comment_status'	=>	'closed',
				'ping_status'		=>	'closed',
				'post_author'		=>	'1',
				'post_name'			=>	$slug,
				'post_title'		=>	$title,
				'post_status'		=>	'publish',
				'post_type'			=>	'page',
				'page_template'		=>  'velocitytoko-templates_profile'
			)
		);
	} else {
    		$post_id = -2;
	}
}

// Register Profile Page
add_filter( 'after_setup_theme', 'vsstemmart_create_katalog' );
function vsstemmart_create_katalog() {
	$post_id        = -1;
	$slug           = 'katalog';
	$title          = 'Katalog';
	if( null == get_page_by_path( $slug ) ) {
		$post_id = wp_insert_post(
			array(
				'comment_status'	=>	'closed',
				'ping_status'		=>	'closed',
				'post_author'		=>	'1',
				'post_name'			=>	$slug,
				'post_title'		=>	$title,
				'post_status'		=>	'publish',
				'post_type'			=>	'page',
				'page_template'		=>  'velocitytoko-templates_katalog'
			)
		);
	} else {
    		$post_id = -2;
	}
}