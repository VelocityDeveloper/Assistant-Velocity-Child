<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */

 global $wpdb;
 global $post;
 $count_posts           = wp_count_posts('product');
 $published_posts       = $count_posts->publish;
 $count_blog            = wp_count_posts();
 $published_blog        = $count_posts->publish;
 $countmember           = count_users();
 $table_order           = $wpdb->prefix . "order"; 
 $table_kupon           = $wpdb->prefix . "kupon"; 
 $semuakupon            = $wpdb->get_var("SELECT COUNT(*) FROM $table_kupon");
 $datearray             = array('11','10','9','8','7','6','5','4','3','2','1', '0');
 $tottarget             = 0;
 $totkeuntungan         = 0;
 $totgagal              = 0;
 $totrefund             = 0;
 
 $labelbest             = new WP_Query( array( 'post_type' => 'product', 'meta_key' => 'label', 'meta_value' => 'label-best' ) );
 $labelnew              = new WP_Query( array( 'post_type' => 'product', 'meta_key' => 'label', 'meta_value' => 'label-new' ) );
 $labellimited          = new WP_Query( array( 'post_type' => 'product', 'meta_key' => 'label', 'meta_value' => 'label-limited' ) );
 $labelpromo            = new WP_Query( array( 'post_type' => 'product', 'meta_key' => 'label' ) );
 $labelflash            = new WP_Query( array( 'post_type' => 'product', 'meta_key' => 'flashsale' ) );
 if($table_order){
     foreach($datearray as $date){
         $bulan             = date("m-Y", strtotime('-'.$date." months"));
         $semuavalue[]      = $wpdb->get_var("SELECT COUNT(*) FROM $table_order WHERE date LIKE  '%$bulan%'");
         $suksesvalue[]     = $wpdb->get_var("SELECT COUNT(*) FROM $table_order WHERE status = 'Sukses' AND date LIKE  '%$bulan%'");
         $lunasvalue[]      = $wpdb->get_var("SELECT COUNT(*) FROM $table_order WHERE status = 'Lunas' AND date LIKE  '%$bulan%'");
         $gagalvalue[]      = $wpdb->get_var("SELECT COUNT(*) FROM $table_order WHERE status = 'Gagal' AND date LIKE  '%$bulan%'");
         $refundvalue[]     = $wpdb->get_var("SELECT COUNT(*) FROM $table_order WHERE status = 'Refund' AND date LIKE  '%$bulan%'");
         $datas             = $wpdb->get_results("SELECT * FROM $table_order WHERE date LIKE  '%$bulan%'");
         $keuntungan['x'.$date] = 0;
         
         foreach($datas as $data) {
            $keuntungan['x'.$date] += json_decode($data->detail,true)['produk']['hargatotal'];
            $tottarget              += json_decode($data->detail,true)['produk']['hargatotal'];
         }
         $keuntungan['x'.$date] = $keuntungan['x'.$date];
         
         $datasukses            = $wpdb->get_results("SELECT * FROM $table_order WHERE status = 'Sukses' AND date LIKE  '%$bulan%'");
         $datalunas             = $wpdb->get_results("SELECT * FROM $table_order WHERE status = 'Lunas' AND date LIKE  '%$bulan%'");
         $datagagal             = $wpdb->get_results("SELECT * FROM $table_order WHERE status = 'Gagal' AND date LIKE  '%$bulan%'");
         $datarefund            = $wpdb->get_results("SELECT * FROM $table_order WHERE status = 'Refund' AND date LIKE  '%$bulan%'");
         
         $gagalrefund['x'.$date]        = 0;
         $keuntunganpasti['x'.$date]    = 0;
         $totgagal                      = 0;
         $totrefund                     = 0;
         $totkeuntungan                 = 0;
         foreach($datagagal as $gagal) {
            $gagalrefund['x'.$date] += json_decode($gagal->detail,true)['produk']['hargatotal'];
            $totgagal               += json_decode($gagal->detail,true)['produk']['hargatotal'];
         }
         foreach($datarefund as $refund) {
            $gagalrefund['x'.$date] += json_decode($refund->detail,true)['produk']['hargatotal'];
            $totrefund              += json_decode($refund->detail,true)['produk']['hargatotal'];
         }
         $gagalrefund['x'.$date] = $gagalrefund['x'.$date];
         foreach($datasukses as $sukses) {
            $keuntunganpasti['x'.$date] += json_decode($sukses->detail,true)['produk']['hargatotal'];
            $totkeuntungan              += json_decode($sukses->detail,true)['produk']['hargatotal'];
         }
         foreach($datalunas as $lunas) {
            $keuntunganpasti['x'.$date] += json_decode($lunas->detail,true)['produk']['hargatotal'];
            $totkeuntungan              += json_decode($lunas->detail,true)['produk']['hargatotal'];
         }
         $keuntunganpasti['x'.$date] = $keuntunganpasti['x'.$date];
     }
    
     $semuaorder            = $wpdb->get_var("SELECT COUNT(*) FROM $table_order");
     $menunggupembayaran    = $wpdb->get_var("SELECT COUNT(*) FROM $table_order WHERE status = 'Transaksi Baru'");
     $lunas                 = $wpdb->get_var("SELECT COUNT(*) FROM $table_order WHERE status = 'Lunas'");
     $sukses                = $wpdb->get_var("SELECT COUNT(*) FROM $table_order WHERE status = 'Sukses'");
     $gagal                 = $wpdb->get_var("SELECT COUNT(*) FROM $table_order WHERE status = 'Gagal'");
     $refund                = $wpdb->get_var("SELECT COUNT(*) FROM $table_order WHERE status = 'Refund'");
    
     ?>
     
    <div class="container pl-0 mt-3">
        <div class="row">
            <div class="col-md-3 col-6">
                <div class="card p-0 text-white bg-gradient">
                    <div class="card-header"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-archive" viewBox="0 0 16 16"> <path d="M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 1 12.5V5a1 1 0 0 1-1-1V2zm2 3v7.5A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5V5H2zm13-3H1v2h14V2zM5 7.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/> </svg>  Produk
                    </div>
                    <div class="card-body"><?php echo $published_posts;?> </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card p-0 text-white bg-gradient">
                    <div class="card-header"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-people" viewBox="0 0 16 16"> <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1h8zm-7.978-1A.261.261 0 0 1 7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002a.274.274 0 0 1-.014.002H7.022zM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM6.936 9.28a5.88 5.88 0 0 0-1.23-.247A7.35 7.35 0 0 0 5 9c-4 0-5 3-5 4 0 .667.333 1 1 1h4.216A2.238 2.238 0 0 1 5 13c0-1.01.377-2.042 1.09-2.904.243-.294.526-.569.846-.816zM4.92 10A5.493 5.493 0 0 0 4 13H1c0-.26.164-1.03.76-1.724.545-.636 1.492-1.256 3.16-1.275zM1.5 5.5a3 3 0 1 1 6 0 3 3 0 0 1-6 0zm3-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/> </svg>  Member
                    </div>
                    <div class="card-body"><?php echo $countmember['total_users'];?> </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card p-0 text-white bg-gradient">
                    <div class="card-header"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-rss" viewBox="0 0 16 16"> <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/> <path d="M5.5 12a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm-3-8.5a1 1 0 0 1 1-1c5.523 0 10 4.477 10 10a1 1 0 1 1-2 0 8 8 0 0 0-8-8 1 1 0 0 1-1-1zm0 4a1 1 0 0 1 1-1 6 6 0 0 1 6 6 1 1 0 1 1-2 0 4 4 0 0 0-4-4 1 1 0 0 1-1-1z"/> </svg>  Blog
                    </div>
                    <div class="card-body"><?php echo $published_blog;?> </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card p-0 text-white bg-gradient">
                    <div class="card-header"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-fill" viewBox="0 0 16 16"> <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/> </svg> Kupon
                    </div>
                    <div class="card-body"><?php echo $semuakupon;?> </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9">
                <div class="container mt-4 bg-light p-0">
                    <div class="card-header text-white bg-gradient2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-graph-up" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M0 0h1v15h15v1H0V0Zm14.817 3.113a.5.5 0 0 1 .07.704l-4.5 5.5a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61 4.15-5.073a.5.5 0 0 1 .704-.07Z"/> </svg>  Grafik Penjualan Tahun Ini
                    </div>
                    <div class="card-body">
                        <canvas id="graph"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="container mx-0 mt-4 p-0 row">
                    <div class="col-12 card-header bg-gradient2 text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-graph-up" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M0 0h1v15h15v1H0V0Zm14.817 3.113a.5.5 0 0 1 .07.704l-4.5 5.5a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61 4.15-5.073a.5.5 0 0 1 .704-.07Z"/> </svg>  Rangkuman Penjualan
                    </div>
                    <div class="col-6 col-md-12 px-2 px-md-0">
                        <div class="card p-0 text-dark bg-muted">
                            <div class="card-header p-2 bg-dark text-white">Total Pesanan Masuk
                            </div>
                            <div class="card-body p-2 "><?php echo $semuaorder;?> Pesanan</div>
                        </div>
                    </div>
                    <div class="col-6 col-md-12 px-2 px-md-0">
                        <div class="card p-0 text-dark bg-muted">
                            <div class="card-header p-2 bg-dark text-white">Total Pesanan Blm Diproses
                            </div>
                            <div class="card-body p-2"><?php echo $menunggupembayaran;?> Pesanan</div>
                        </div>
                    </div>
                    <div class="col-6 col-md-12 px-2 px-md-0">
                        <div class="card p-0 text-info bg-muted">
                            <div class="card-header p-2 bg-dark text-white">Total Pesanan Sukses & Lunas
                            </div>
                            <div class="card-body p-2 text-info"><b><?php echo $sukses + $lunas;?> Pesanan</b></div>
                        </div>
                    </div>
                    <div class="col-6 col-md-12 px-2 px-md-0">
                        <div class="card p-0 text-dark bg-muted">
                            <div class="card-header p-2 bg-dark text-white">Total Pesanan Gagal & Refund
                            </div>
                            <div class="card-body p-2"><?php echo $gagal;?> Pesanan</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9">
                <div class="container mt-4 bg-light p-0">
                    <div class="card-header text-white bg-gradient3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-graph-up" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M0 0h1v15h15v1H0V0Zm14.817 3.113a.5.5 0 0 1 .07.704l-4.5 5.5a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61 4.15-5.073a.5.5 0 0 1 .704-.07Z"/> </svg>  Grafik Pembayaran Tahun Ini
                    </div>
                    <div class="card-body">
                        <canvas id="graphuntung"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="container mx-0 mt-4 p-0 row">
                    <div class="col-12 card-header bg-gradient3 text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-graph-up" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M0 0h1v15h15v1H0V0Zm14.817 3.113a.5.5 0 0 1 .07.704l-4.5 5.5a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61 4.15-5.073a.5.5 0 0 1 .704-.07Z"/> </svg>  Rangkuman Pembayaran
                    </div>
                    <div class="col-6 col-md-12 px-2 px-md-0">
                        <div class="card p-0 text-dark bg-muted">
                            <div class="card-header p-2 bg-dark text-white">Total Pengajuan Pembelian
                            </div>
                            <div class="card-body p-2 text-muted"><?php echo vsstemmart_currency_text();?> <?php echo number_format($tottarget, 2, ',', '.');?></div>
                        </div>
                    </div>
                    <div class="col-6 col-md-12 px-2 px-md-0">
                        <div class="card p-0 text-dark bg-muted">
                            <div class="card-header p-2 bg-dark text-white"><b>Pembayaran Lunas</b>
                            </div>
                            <div class="card-body p-2 text-info"><b><?php echo vsstemmart_currency_text();?> <?php echo number_format($totkeuntungan, 2, ',', '.');?></b></div>
                        </div>
                    </div>
                    <div class="col-6 col-md-12 px-2 px-md-0">
                        <div class="card p-0 text-dark bg-muted">
                            <div class="card-header p-2 bg-dark text-white">Pembelian cancel
                            </div>
                            <div class="card-body p-2 text-muted"><?php echo vsstemmart_currency_text();?> <?php echo number_format($totgagal, 2, ',', '.');?> </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-12 px-2 px-md-0">
                        <div class="card p-0 text-dark bg-muted">
                            <div class="card-header p-2 bg-dark text-white">Pembelian Refund
                            </div>
                            <div class="card-body p-2 text-muted"><?php echo vsstemmart_currency_text();?> <?php echo number_format($totrefund, 2, ',', '.');?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-9">
                <div class="container mt-4 bg-light p-0">
                    <div class="card-header text-white bg-gradient4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-graph-up" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M0 0h1v15h15v1H0V0Zm14.817 3.113a.5.5 0 0 1 .07.704l-4.5 5.5a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61 4.15-5.073a.5.5 0 0 1 .704-.07Z"/> </svg>  Data Produk Berdasarkan Label
                    </div>
                    <div class="card-body">
                        <canvas id="dataproduk"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="container mt-4 bg-light p-0">
                    <div class="card-header text-white bg-gradient4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16"> <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/> <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/> </svg>  Produk Populer
                    </div>
                    <ul class="list-group list-group-flush">
                        <?php
                        $query = array(
                        	'post_type'         => 'product',
                        	'orderby'           => 'meta_value_num',
                        	'meta_key'          => 'hit',
                        	'posts_per_page'    => '8',
                        );
                        $my_query = new WP_Query($query);
                        if ( $my_query->have_posts() ) { 
                        	while ( $my_query->have_posts() ) { 
                        		$my_query->the_post();
                        		echo '<li class="list-group-item">';
                            		echo '<a href="'.get_the_permalink().'">'.get_the_title().' <span class="badge badge-pill badge-danger">'.get_post_meta($post->ID, 'hit', true).'</span></a>';
                        		echo '</li>';
                        	}
                        }
                        wp_reset_postdata();
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function() {
    	var cty = document.getElementById("dataproduk").getContext('2d');
    	var infojumlah = new Chart(cty, {
    	  type: 'doughnut',
    	  data: {
    	    labels: ["Limited", "Best Seller ", "New", "Promo", "Flash Shale"],
    	    datasets: [{
    	      backgroundColor: [
    	        "#F16194",
    	        "#F77E49",
    	        "#F4988B",
    	        "#36a2eb",
    	        "#333333",
    	      ],
    	      data: [ <?php echo $labellimited->found_posts; ?>, <?php echo $labelbest->found_posts; ?>, <?php echo $labelnew->found_posts; ?>, <?php echo $labelpromo->found_posts; ?>, <?php echo $labelflash->found_posts; ?> ]
    	    }]
    	  },
    	options: {
    		tooltips: {
    			callbacks: {
    				label: function(tooltipItem, data) {
    					var allData = data.datasets[tooltipItem.datasetIndex].data;
    					var tooltipLabel = data.labels[tooltipItem.index];
    					var tooltipData = allData[tooltipItem.index];
    					var total = 0;
    					for (var i in allData) {
    						total += allData[i];
    					}
    					var tooltipPercentage = Math.round((tooltipData / total) * 100);
    					return tooltipLabel + ': ' + tooltipData + ' Produk (' + tooltipPercentage + '%)';
    				}
    			}
    		}
    	}//option
    	});
       
    });
    </script>
    
    <script>
    	var config = {
    		type: 'line',
    		data: {
    			labels: [
    			    '<?php echo date("F", strtotime("-11 months"));?>', 
    			    '<?php echo date("F", strtotime("-10 months"));?>', 
    			    '<?php echo date("F", strtotime("-9 months"));?>', 
    			    '<?php echo date("F", strtotime("-8 months"));?>', 
    			    '<?php echo date("F", strtotime("-7 months"));?>', 
    			    '<?php echo date("F", strtotime("-6 months"));?>', 
    			    '<?php echo date("F", strtotime("-5 months"));?>', 
    			    '<?php echo date("F", strtotime("-4 months"));?>', 
    			    '<?php echo date("F", strtotime("-3 months"));?>', 
    			    '<?php echo date("F", strtotime("-2 months"));?>', 
    			    '<?php echo date("F", strtotime("-1 months"));?>', 
    			    '<?php echo date("F");?>'
    			    ],
    			datasets: [{
    				label: 'Order Masuk',
    				fill: false,
    				backgroundColor: window.chartColors.blue,
    				borderColor: window.chartColors.blue,
    				data: [
    					<?php echo $semuavalue['0']; ?>,
    					<?php echo $semuavalue['1']; ?>,
    					<?php echo $semuavalue['2']; ?>,
    					<?php echo $semuavalue['3']; ?>,
    					<?php echo $semuavalue['4']; ?>,
    					<?php echo $semuavalue['5']; ?>,
    					<?php echo $semuavalue['6']; ?>,
    					<?php echo $semuavalue['7']; ?>,
    					<?php echo $semuavalue['8']; ?>,
    					<?php echo $semuavalue['9']; ?>,
    					<?php echo $semuavalue['10']; ?>,
    					<?php echo $semuavalue['11']; ?>
    				],
    			}, {
    				label: 'Gagal',
    				fill: false,
    				backgroundColor: window.chartColors.red,
    				borderColor: window.chartColors.red,
    				data: [
    					<?php echo $gagalvalue['0']; ?>,
    					<?php echo $gagalvalue['1']; ?>,
    					<?php echo $gagalvalue['2']; ?>,
    					<?php echo $gagalvalue['3']; ?>,
    					<?php echo $gagalvalue['4']; ?>,
    					<?php echo $gagalvalue['5']; ?>,
    					<?php echo $gagalvalue['6']; ?>,
    					<?php echo $gagalvalue['7']; ?>,
    					<?php echo $gagalvalue['8']; ?>,
    					<?php echo $gagalvalue['9']; ?>,
    					<?php echo $gagalvalue['10']; ?>,
    					<?php echo $gagalvalue['11']; ?>
    				],
    			}, {
    				label: 'Lunas',
    				backgroundColor: window.chartColors.green,
    				borderColor: window.chartColors.green,
    				data: [
    					<?php echo $lunasvalue['0']; ?>,
    					<?php echo $lunasvalue['1']; ?>,
    					<?php echo $lunasvalue['2']; ?>,
    					<?php echo $lunasvalue['3']; ?>,
    					<?php echo $lunasvalue['4']; ?>,
    					<?php echo $lunasvalue['5']; ?>,
    					<?php echo $lunasvalue['6']; ?>,
    					<?php echo $lunasvalue['7']; ?>,
    					<?php echo $lunasvalue['8']; ?>,
    					<?php echo $lunasvalue['9']; ?>,
    					<?php echo $lunasvalue['10']; ?>,
    					<?php echo $lunasvalue['11']; ?>
    				],
    				fill: false,
    			}, {
    				label: 'Sukses',
    				backgroundColor: window.chartColors.yellow,
    				borderColor: window.chartColors.yellow,
    				data: [
    					<?php echo $suksesvalue['0']; ?>,
    					<?php echo $suksesvalue['1']; ?>,
    					<?php echo $suksesvalue['2']; ?>,
    					<?php echo $suksesvalue['3']; ?>,
    					<?php echo $suksesvalue['4']; ?>,
    					<?php echo $suksesvalue['5']; ?>,
    					<?php echo $suksesvalue['6']; ?>,
    					<?php echo $suksesvalue['7']; ?>,
    					<?php echo $suksesvalue['8']; ?>,
    					<?php echo $suksesvalue['9']; ?>,
    					<?php echo $suksesvalue['10']; ?>,
    					<?php echo $suksesvalue['11']; ?>
    				],
    				fill: false,
    			}, {
    				label: 'Refund',
    				backgroundColor: window.chartColors.grey,
    				borderColor: window.chartColors.grey,
    				data: [
    					<?php echo $suksesvalue['0']; ?>,
    					<?php echo $suksesvalue['1']; ?>,
    					<?php echo $suksesvalue['2']; ?>,
    					<?php echo $suksesvalue['3']; ?>,
    					<?php echo $suksesvalue['4']; ?>,
    					<?php echo $suksesvalue['5']; ?>,
    					<?php echo $suksesvalue['6']; ?>,
    					<?php echo $suksesvalue['7']; ?>,
    					<?php echo $suksesvalue['8']; ?>,
    					<?php echo $suksesvalue['9']; ?>,
    					<?php echo $suksesvalue['10']; ?>,
    					<?php echo $suksesvalue['11']; ?>
    				],
    				fill: false,
    			}]
    		},
    		options: {
    			responsive: true,
    			title: {
    				display: true,
    				text: 'Data penjualan dalam 1 tahun'
    			},
    			tooltips: {
    				mode: 'index',
    				intersect: false,
    			},
    			hover: {
    				mode: 'nearest',
    				intersect: true
    			},
    			scales: {
    				xAxes: [{
    					display: true,
    					scaleLabel: {
    						display: true,
    						labelString: 'Bulan'
    					}
    				}],
    				yAxes: [{
    					display: true,
    					scaleLabel: {
    						display: true,
    						labelString: 'Pembelian'
    					}
    				}]
    			}
    		}
    	};
    	//untung
    	var configuntung = {
    		type: 'line',
    		data: {
    			labels: [
    			    '<?php echo date("F", strtotime("-11 months"));?>', 
    			    '<?php echo date("F", strtotime("-10 months"));?>', 
    			    '<?php echo date("F", strtotime("-9 months"));?>', 
    			    '<?php echo date("F", strtotime("-8 months"));?>', 
    			    '<?php echo date("F", strtotime("-7 months"));?>', 
    			    '<?php echo date("F", strtotime("-6 months"));?>', 
    			    '<?php echo date("F", strtotime("-5 months"));?>', 
    			    '<?php echo date("F", strtotime("-4 months"));?>', 
    			    '<?php echo date("F", strtotime("-3 months"));?>', 
    			    '<?php echo date("F", strtotime("-2 months"));?>', 
    			    '<?php echo date("F", strtotime("-1 months"));?>', 
    			    '<?php echo date("F");?>'
    			    ],
    			datasets: [{
    				label: 'Lunas / Sukses',
    				fill: false,
    				backgroundColor: 'rgba(255, 99, 132,0.7)',
    				borderColor: 'rgb(255, 99, 132)',
    				data: [
    					<?php echo $keuntunganpasti['x11']; ?>,
    					<?php echo $keuntunganpasti['x10']; ?>,
    					<?php echo $keuntunganpasti['x9']; ?>,
    					<?php echo $keuntunganpasti['x8']; ?>,
    					<?php echo $keuntunganpasti['x7']; ?>,
    					<?php echo $keuntunganpasti['x6']; ?>,
    					<?php echo $keuntunganpasti['x5']; ?>,
    					<?php echo $keuntunganpasti['x4']; ?>,
    					<?php echo $keuntunganpasti['x3']; ?>,
    					<?php echo $keuntunganpasti['x2']; ?>,
    					<?php echo $keuntunganpasti['x1']; ?>,
    					<?php echo $keuntunganpasti['x0']; ?>
    				],
    				fill: true,
    			}, {
    				label: 'Permintaan Masuk',
    				fill: false,
    				backgroundColor: 'rgba(54, 162, 235,0.1)',
    				borderColor: 'rgba(54, 162, 235,0.4)',
    				data: [
    					<?php echo $keuntungan['x11']; ?>,
    					<?php echo $keuntungan['x10']; ?>,
    					<?php echo $keuntungan['x9']; ?>,
    					<?php echo $keuntungan['x8']; ?>,
    					<?php echo $keuntungan['x7']; ?>,
    					<?php echo $keuntungan['x6']; ?>,
    					<?php echo $keuntungan['x5']; ?>,
    					<?php echo $keuntungan['x4']; ?>,
    					<?php echo $keuntungan['x3']; ?>,
    					<?php echo $keuntungan['x2']; ?>,
    					<?php echo $keuntungan['x1']; ?>,
    					<?php echo $keuntungan['x0']; ?>
    				],
    				fill: true,
    			}, {
    				label: 'Gagal / Refund',
    				backgroundColor: 'rgba(221, 221, 221,0.3)',
    				borderColor: 'rgb(0, 0, 0)',
    				data: [
    					<?php echo $gagalrefund['x11']; ?>,
    					<?php echo $gagalrefund['x10']; ?>,
    					<?php echo $gagalrefund['x9']; ?>,
    					<?php echo $gagalrefund['x8']; ?>,
    					<?php echo $gagalrefund['x7']; ?>,
    					<?php echo $gagalrefund['x6']; ?>,
    					<?php echo $gagalrefund['x5']; ?>,
    					<?php echo $gagalrefund['x4']; ?>,
    					<?php echo $gagalrefund['x3']; ?>,
    					<?php echo $gagalrefund['x2']; ?>,
    					<?php echo $gagalrefund['x1']; ?>,
    					<?php echo $gagalrefund['x0']; ?>
    				],
    				fill: true,
    			}]
    		},
    		options: {
    			responsive: true,
    			title: {
    				display: true,
    				text: 'Omset Dalam 1 Tahun'
    			},
    			tooltips: {
    				mode: 'index',
    				intersect: false,
    				callbacks: {
        				label: function(tooltipItem, data) {
        					var allData = data.datasets[tooltipItem.datasetIndex].data;
        					var tooltipLabel = data.datasets[tooltipItem.datasetIndex].label;
        					var tooltipData = allData[tooltipItem.index];
        					var total = 0;
        					for (var i in allData) {
        						total += allData[i];
        					}
                            var bilangan = tooltipData;
                            	
                            var	number_string = bilangan.toString(),
                            	sisa 	= number_string.length % 3,
                            	rupiah 	= number_string.substr(0, sisa),
                            	ribuan 	= number_string.substr(sisa).match(/\d{3}/g);
                            		
                            if (ribuan) {
                            	separator = sisa ? '.' : '';
                            	rupiah += separator + ribuan.join('.');
                            }
        					var tooltipPercentage = Math.round((tooltipData / total) * 100);
        					return  tooltipLabel + ': <?php echo vsstemmart_currency_text();?> ' + (rupiah) + '';
        				}
    			    }
    			},
    			hover: {
    				mode: 'nearest',
    				intersect: true
    			},
    			scales: {
    				xAxes: [{
    					display: true,
    					scaleLabel: {
    						display: true,
    						labelString: 'Bulan'
    					}
    				}],
    				yAxes: [{
    					display: true,
        				ticks: {
                            callback: function(value, index, values) {
                                var bilangan = value;
    	
                                var	number_string = bilangan.toString(),
                                	sisa 	= number_string.length % 3,
                                	rupiah 	= number_string.substr(0, sisa),
                                	ribuan 	= number_string.substr(sisa).match(/\d{3}/g);
                                		
                                if (ribuan) {
                                	separator = sisa ? '.' : '';
                                	rupiah += separator + ribuan.join('.');
                                }
                                return 'Rp' + rupiah;
                            }
                        },
    					scaleLabel: {
    						display: true,
    						labelString: 'Omset'
    					}
    				}]
    			}
    		}
    	};
    
    	window.onload = function() {
    	    var ctx = document.getElementById('graph').getContext('2d');
    		window.myLine = new Chart(ctx, config);
    		
    		var ctxuntung = document.getElementById('graphuntung').getContext('2d');
     		window.myLine = new Chart(ctxuntung, configuntung);
    	};
    </script>
<?php
} else {
    ?>
    <div class="card p-0 text-white bg-gradient">
        <div class="card-header"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-archive" viewBox="0 0 16 16"> <path d="M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 1 12.5V5a1 1 0 0 1-1-1V2zm2 3v7.5A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5V5H2zm13-3H1v2h14V2zM5 7.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/> </svg>  Data Pembelian Kosong :(
        </div>
        <div class="card-body">Belum ada pembelian masuk</div>
    </div>
    <?php
}