<?php 
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="second-post slider-bottom-<?php echo $id; ?>">
    <?php foreach($posts as $post) { ?>
        <div class="m-2">
            <?php echo do_shortcode('[velocity-katalog-loop post_id="'.$post->ID.'"]'); ?>
        </div>
    <?php } ?>
</div>
