<?php $prices = $settings->price_carousel; ?>

<div class="velocity-price-<?php echo $id; ?>">
<?php foreach($prices as $price){ ?>
    <div class="p-2 text-center">
        <div class="border bg-white h-100">
            <div class="fw-bold fs-5 py-4 bg-light text-dark m-3"><?php echo $price->title;?></div>
            <div class="fs-4 text-white py-2" style="background-color:#<?php echo $price->bgprice;?>"><?php echo $price->price;?></div>
            <p class="mb-0 p-3 fst-italic text-secondary"><?php echo $price->desc;?></p>
        </div>
    </div>
<?php } ?>
</div>