<?php


class FLvPriceBoxCarousel extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __('Price Box Carousel', 'fl-builder'),
			'description'   	=> __('By Velocity Developer', 'fl-builder'),
			'category'      	=> __('Actions', 'fl-builder'),
			'editor_export' 	=> false,
			'partial_refresh'	=> true
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvPriceBoxCarousel', array(
	'slider'      => array(
		'title'         => __('General', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => 'General',
				'fields'        => array(
					'price_carousel'     => array(
						'type'         => 'form',
						'label'        => __('Price', 'fl-builder'),
						'form'         => 'price_carousel_form',
						'preview_text' => 'title',
						'multiple'     => true
					),
				)
			),
		)
	),
));




FLBuilder::register_settings_form('price_carousel_form', array(
	'title' => __( 'Add Price', 'fl-builder' ),
	'tabs'  => array(
		'general'      => array(
			'title'         => __('General', 'fl-builder'),
			'sections'      => array(
				'title'       => array(
					'title'         => __( 'General', 'fl-builder' ),
					'fields'        => array(
						'title'          => array(
							'type'          => 'text',
							'label'         => __('Title', 'fl-builder'),
						),
						'price'          => array(
							'type'          => 'text',
							'label'         => __('Price', 'fl-builder'),
						),
						'bgprice'  => array(
							'type'        => 'color',
							'connections' => array( 'color' ),
							'label'       => __( 'Price Background', 'fl-builder' ),
							'default'     => '3d78bc',
							'show_alpha'  => true,
						),
						'desc'          => array(
							'type'          => 'textarea',
							'label'         => __('Description', 'fl-builder'),
						),
					),
				),
			)
		),
	)
));