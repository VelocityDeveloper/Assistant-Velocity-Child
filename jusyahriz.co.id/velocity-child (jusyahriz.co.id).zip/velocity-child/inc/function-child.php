<?php
/**
 * Fuction yang digunakan di theme ini.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}


add_action('init', 'velocity_admin_init');
function velocity_admin_init() {
    register_post_type('katalog', array(
        'labels' => array(
            'name' => 'Katalog',
            'singular_name' => 'katalog',
        ),
        'menu_icon' => 'dashicons-screenoptions',
        'public' => true,
        'has_archive' => true,
        'taxonomies' => array('kategori-katalog'),
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
        ),
    ));
	register_taxonomy(
	'kategori-katalog',
	'katalog',
	array(
		'label' => __( 'Kategori Katalog' ),
		'rewrite' => array( 'slug' => 'kategori-katalog' ),
		'hierarchical' => true,
		'show_admin_column' => true,
	));
}

function pippin_add_taxonomy_filters() {
	global $typenow; 
	// an array of all the taxonomyies you want to display. Use the taxonomy name or slug
	$taxonomies = array('kategori-katalog'); 
	// must set this to the post type you want the filter(s) displayed on
	if( $typenow == 'katalog' ){ 
		foreach ($taxonomies as $tax_slug) {
			$tax_obj = get_taxonomy($tax_slug);
			$tax_name = $tax_obj->labels->name;
			$terms = get_terms($tax_slug);
			if(count($terms) > 0) {
				echo "<select name='$tax_slug' id='$tax_slug' class='postform'>";
				echo "<option value=''>Semua $tax_name</option>";
				foreach ($terms as $term) { 
					echo '<option value='. $term->slug, $_GET[$tax_slug] == $term->slug ? ' selected="selected"' : '','>' . $term->name .' (' . $term->count .')</option>'; 
				}
				echo "</select>";
			}
		}
	}
}
add_action( 'restrict_manage_posts', 'pippin_add_taxonomy_filters' );




add_action("admin_init", "admin_init");
function admin_init(){
	add_meta_box("harga", "Harga", "harga_function", "katalog", "side", "low");
}

function harga_function(){
	global $post;
	$custom = get_post_custom($post->ID);
	$harga = $custom["harga"][0]; ?>
	<input name="harga" value="<?php echo $harga; ?>" type="number" /><br>
	<small>Isikan dengan angka saja, contoh: <font color="red">70000</font></small>
<?php }


add_action('save_post', 'save_details');
function save_details(){
	global $post;
	update_post_meta($post->ID, "harga", $_POST["harga"]);
}

