<?php $testimonials = $settings->t_columns;
echo '<div id="testimoni-modul" class="testimoni-'.$id.'">';
foreach($testimonials as $testimoni){
    echo '<div class="testimoni-list p-2 text-center">';
      echo '<div class="shadow-sm rounded py-5 bg-white">';
          echo '<div class="foto-testimoni" style="background-image:url('.wp_get_attachment_url($testimoni->image).')"></div>';
          echo '<div class="nama-testimoni h6 fw-bold mt-3">'.$testimoni->title.'</div>';
          echo '<div class="prof-testimoni text-secondary">'.$testimoni->profession.'</div>';
          echo '<div class="testimoni-description mt-3">'.$testimoni->description.'</div>';
      echo '</div>';
    echo '</div>';
}
echo '</div>';?>
