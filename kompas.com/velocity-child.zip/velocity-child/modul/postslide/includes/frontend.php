<?php 
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;
 ?>
<div class="frame-luar">
    <div class="slider-panah"></div>
    <div class="slider-frame-img">
        <?php foreach($posts as $post) { ?>
        		    <div class="frame-slide">
        		        <div class="image-post">
						<img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?>" />
						</div>
        		        <div class="frame-isi">
<?php $categories = get_the_category($post->ID);
if ( ! empty( $categories ) ) {
	foreach( $categories as $category ) {
		echo '<a class="text-uppercase px-2 d-inline-block me-2 mb-2 bg-white text-dark" href="'.esc_url(get_category_link($category->term_id)).'"><small>'.esc_html($category->name).'</small></a>';
	}
} ?>
                            <div class="judul mb-3"><a href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post);?></a></div>
                            <div class="text-uppercase text-white"><small>By <?php the_author_meta('display_name',$post->post_author); ?> - <?php echo get_the_date('F j, Y',$post->ID);?></small></div>
                        </div>
        		    </div>
        <?php } ?>
    </div>
</div>
<div class="frame-kecil">
<div class="slider-frame-navi bg-dark">
    <?php foreach($posts as $post) { ?>
        <div><img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?>" />
            <div class="p-2 text-white"><?php echo get_the_title($post);?></div>
        </div>
    <?php } ?>
</div>
</div>