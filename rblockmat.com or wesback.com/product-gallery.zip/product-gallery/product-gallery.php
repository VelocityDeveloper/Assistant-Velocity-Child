<?php

/**
 * @class FLvProductGallery
 */
class FLvProductGallery extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __('Product Gallery', 'fl-builder'),
			'description'   	=> __('By Velocity Developer', 'fl-builder'),
			'category'      	=> __('Basic', 'fl-builder'),
			'editor_export' 	=> false,
			'partial_refresh'	=> true
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvProductGallery', array(
	'slider'      => array(
		'title'         => __('General', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
				)
			),

		)
	),
));