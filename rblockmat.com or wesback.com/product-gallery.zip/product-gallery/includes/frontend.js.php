jQuery(function($) {
	positiveZoom.init('#slider-zoom-<?php echo $id; ?>');
});
