<div class="product-gallery-<?php echo $id; ?>">
<?php 
global $post;
$post_id = $post->ID;
$gallery = get_post_meta($post_id, 'gallery');
$dataimg    = [];
    if (has_post_thumbnail($post_id)) {
        $dataimg[]  = [
            'id'        => get_post_thumbnail_id($post_id),
            'full'      => get_the_post_thumbnail_url($post_id, 'full'),
        ];
    }
    if ($gallery) {
        foreach ($gallery as $img) {
            $dataimg[]  = [
                'id'        => $img,
                'full'      => wp_get_attachment_image_url($img, 'full'),
            ];
        }
    }

    if ($dataimg) { ?>
        <div id="slider-zoom-<?php echo $id; ?>" class="positive-gallery-slider">
            <div class="side-img">
            <div class="zoom-image mb-3"></div>
              <div class="row m-0">
                <?php foreach ($dataimg as $image) {      
                  echo '<div class="col-3 p-2"><div class="thumb-frame p-2 border h-100 bg-white">';
      				echo '<img src="'.$image['full'].'" class="small-preview">';    
                  echo '</div></div>';
                } ?>
              </div>
            </div>
        </div>  
    <?php } ?>
</div>

