
jQuery(function($) {

  $('.slider-frame-img').slick({
    autoplay: true,
    infinite: true,
    //arrows: false,
    speed: 600,
    prevArrow: '',
    nextArrow: '',
    horizontal: true,
    appendArrows: $('.slider-nav-img')
  });

  $('.slider-frame-navi').slick({
    autoplay: true,
    //arrows: false,
    asNavFor: '.slider-frame-img',
    prevArrow: '<i class="fa fa-chevron-left"></i>',
    nextArrow: '<i class="fa fa-chevron-right"></i>',
    slidesToShow: 7,
    speed: 600,
    infinite: true,
    slidesToScroll:1,
    //dots: true,
    //centerMode: true,
    focusOnSelect: true,
    responsive: [
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 7,
          }
        },
        {
          breakpoint: 576,
          settings: {
            slidesToShow: 4,
          }
        },
        {
          breakpoint: 400,
          settings: {
            slidesToShow: 3,
          }
        },
    ]
  });
});