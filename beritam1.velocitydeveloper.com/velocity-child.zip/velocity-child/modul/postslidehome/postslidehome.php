<?php
/**
 * This is an example module with only the basic
 * setup necessary to get it working.
 *
 * @class postslidehome
 */
class postslidehome extends FLBuilderModule {

    /** 
     * Constructor function for the module. You must pass the
     * name, description, dir and url in an array to the parent class.
     *
     * @method __construct
     */  
    public function __construct()
    {
        parent::__construct(array(
            'name'          => __('Post Slide Home', 'fl-builder'),
            'description'   => __('Modul Post Slide Home', 'fl-builder'),
            'category'		=> __('Velocity Modules', 'fl-builder'),
        ));
    }
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('postslidehome', array(
    'general'       => array( // Tab
        'title'         => __('General', 'fl-builder'), // Tab title
        'sections'      => array( // Tab Sections
			'content'       => array(
				'title'         => __( 'Post', 'fl-builder' ),
				'fields'        => array(
					'posts_per_page' => array(
						'type'          => 'text',
						'label'         => __( 'Posts Slider Total', 'fl-builder' ),
						'default'       => '10',
						'size'          => '4',
					),
				),
			),
        )
    ),
	'content'   => array(
		'title'         => __( 'Content', 'fl-builder' ),
		'file'          => FL_BUILDER_DIR . 'includes/loop-settings.php',
	),
 
));