<div class="row slidepost align-items-center m-0">
    <div class="col-2 col-md-2 frame-label px-0 text-center">
        <div class="label-pop">
            <h2><i class="fa fa-bolt"></i><span class="label">  <?php echo $settings->judul; ?></span></h2>
        </div>
    </div>
    <div class="col-10 col-md-8">
        <div class="slider-frame row horizontal-<?php echo $id;?>">
            <?php 
            $query = FLBuilderLoop::query( $settings );
            $posts = $query->posts;
            foreach($posts as $post) {
        		$postid = $post->ID; 
                echo '<div>';
                	echo '<a class="judul-pos" href="'.get_the_permalink($postid).'">'.get_the_title($postid).'</a>';
                echo '</div>';
            } ?>
        </div>
    </div>
    <div class="nav-<?php echo $id;?> slider-nav col-2 hidden-xs-down pe-0"></div>
</div>
