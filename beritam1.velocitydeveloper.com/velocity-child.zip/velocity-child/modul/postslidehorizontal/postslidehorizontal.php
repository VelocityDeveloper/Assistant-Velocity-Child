<?php
/**
 * This is an example module with only the basic
 * setup necessary to get it working.
 *
 * @class postslidehorizontal
 */
class postslidehorizontal extends FLBuilderModule {

    /** 
     * Constructor function for the module. You must pass the
     * name, description, dir and url in an array to the parent class.
     *
     * @method __construct
     */  
    public function __construct()
    {
        parent::__construct(array(
            'name'          => __('Post Slide Horizontal', 'fl-builder'),
            'description'   => __('Modul Post Slide Horizontal', 'fl-builder'),
            'category'		=> __('Velocity Modules', 'fl-builder'),
            'editor_export' => true, // Defaults to true and can be omitted.
            'enabled'       => true, // Defaults to true and can be omitted.
        ));
    }

}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('postslidehorizontal', array(
    'general'       => array( // Tab
        'title'         => __('General', 'fl-builder'), // Tab title
        'sections'      => array( // Tab Sections
            'general'       => array( // Section
                'title'         => __('Velocity Options', 'fl-builder'), // Section Title
                'fields'        => array( // Section Fields
                    'judul'     => array(
                        'type'          => 'text',
                        'label'         => __( 'Judul', 'fl-builder' ),
                    ),
					'posts_per_page' => array(
						'type'          => 'text',
						'label'         => __( 'Posts Slider Total', 'fl-builder' ),
						'default'       => '10',
						'size'          => '4',
					),
                
                )
            )
        )
    ),
	'content'   => array(
		'title'         => __( 'Content', 'fl-builder' ),
		'file'          => FL_BUILDER_DIR . 'includes/loop-settings.php',
	),
 
));