<?php
/**
 * This is an example module with only the basic
 * setup necessary to get it working.
 *
 * @class tabtrending
 */
class tabtrending extends FLBuilderModule {

    public function __construct()
    {
        parent::__construct(array(
            'name'          => __('Tab Trending', 'fl-builder'),
            'description'   => __('Modul Tab Trending', 'fl-builder'),
            'category'		=> __('Velocity Modules', 'fl-builder'),
            'editor_export' => true, // Defaults to true and can be omitted.
            'enabled'       => true, // Defaults to true and can be omitted.
        ));
    }

}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('tabtrending', array(
    'general'       => array( // Tab
        'title'         => __('No Setting', 'fl-builder'), // Tab title
        'sections'      => array(
        )
    ),
 
));