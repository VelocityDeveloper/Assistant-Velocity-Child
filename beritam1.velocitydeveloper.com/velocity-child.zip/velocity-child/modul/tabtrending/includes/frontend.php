

<div class="tab-trending trending-<?php echo $id; ?>">
    
    <!--TOMBOL TAB-->
    <ul class="nav nav-pills mb-3 nav-justified" id="pills-tab" role="tablist">
      <li class="nav-item">
        <a class="nav-link active" id="pills-trending-tab" data-bs-toggle="pill" href="#pills-trending" role="tab" aria-controls="pills-trending" aria-selected="true">Trending</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="pills-comment-tab" data-bs-toggle="pill" href="#pills-comment" role="tab" aria-controls="pills-comment" aria-selected="false">Comments</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="pills-latest-tab" data-bs-toggle="pill" href="#pills-latest" role="tab" aria-controls="pills-latest" aria-selected="false">Latest</a>
      </li>
    </ul>
    
    <!--ISI TAB-->
    <div class="tab-content" id="pills-tabContent">
        
        <!--TAB TRENDING-->
        <div class="tab-pane fade show active" id="pills-trending" role="tabpanel" aria-labelledby="pills-trending-tab">
            <?php 
                $args = array (
                        'posts_per_page' => 3,
                        'post_type' => 'post',
                        'meta_key' => 'hit',
                        'orderby' => 'meta_value_num', 
                    );
                $query = new WP_Query( $args );
                //print_r($query);
                if ( $query->have_posts() ) {
                while ( $query->have_posts() ) {
                    $query->the_post();
            ?>
                
                <div class="row mb-3">
                    <div class="imagepost col-4 pr-0">
                        <img  src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Picture">
                    </div>
                    <div class="frameisi col-8">
                        <div class="judulpost"><a href="<?php echo get_the_permalink()?>"><?php echo get_the_title()?></a></div>
                        <div class="tanggalpost"><i class="fa fa-clock"></i>  <?php echo get_the_date()?></div>
                    </div>
                </div>
                
            <?php 
            } // end while
            wp_reset_postdata();
            } // end if
            ?>
        </div>
        
        <!--TAB comment-->
        <div class="tab-pane fade" id="pills-comment" role="tabpanel" aria-labelledby="pills-comment-tab">
            <?php 
                $args = array (
                        'posts_per_page' => 3,
                        'post_type' => 'post',
                        'orderby' => 'comment_count', 
                    );
                $query = new WP_Query( $args );
                //print_r($query);
                if ( $query->have_posts() ) {
                while ( $query->have_posts() ) {
                    $query->the_post();
            ?>
                
                <div class="row mb-3">
                    <div class="imagepost col-4 pr-0">
                        <img  src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Picture">
                    </div>
                    <div class="frameisi col-8">
                        <div class="judulpost"><a href="<?php echo get_the_permalink()?>"><?php echo get_the_title()?></a></div>
                        <div class="tanggalpost"><i class="fa fa-comment"></i>  <?php echo get_comments_number();?></div>
                    </div>
                </div>
                
            <?php 
            } // end while
            wp_reset_postdata();
            } // end if
            ?>
        </div>
        
      <!--TAB latest-->
        <div class="tab-pane fade" id="pills-latest" role="tabpanel" aria-labelledby="pills-latest-tab">
            <?php 
                $args = array (
                        'posts_per_page' => 3,
                        'post_type' => 'post',
                    );
                $query = new WP_Query( $args );
                //print_r($query);
                if ( $query->have_posts() ) {
                while ( $query->have_posts() ) {
                    $query->the_post();
            ?>
                
                <div class="row mb-3">
                    <div class="imagepost col-4 pr-0">
                        <img  src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Picture">
                    </div>
                    <div class="frameisi col-8">
                        <div class="judulpost"><a href="<?php echo get_the_permalink()?>"><?php echo get_the_title()?></a></div>
                        <div class="tanggalpost"><i class="fa fa-clock"></i>  <?php echo get_the_date()?></div>
                    </div>
                </div>
                
            <?php 
            } // end while
            wp_reset_postdata();
            } // end if
            ?>
        </div>
    </div>

</div>
