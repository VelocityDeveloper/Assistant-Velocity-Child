jQuery(function($) {

$("#lastWord h2").html(function(){
  var text= $(this).text().trim().split(" ");
  var last = text.pop();
  return text.join(" ") + (text.length > 0 ? " <span class='warna'>" + last + "</span>" : last);
});

$( ".postlayangnext-remove" ).click(function() {
      $("#postlayangnext").remove();
    });
    
$( ".tombols" ).click(function() {
    var id = $(this).attr("id");
      $(".form-"+id).toggle();
      $("#"+id).toggleClass( "collapsed" );
});

    $(".postshare-button").click(function() {
        var idp         = $(this).attr("data-id");
        jQuery.ajax({
                type    : "POST",
                url     : ajaxurl,
                data    : {action:'sharetambah', id:idp },
                success :function(data) {
                    $('#datashare').html(data);
                },
        });
    });
});

jQuery(document).ready(function() {
    // jQuery(window).scroll(function() {
    //     100 < jQuery(this).scrollTop() ? jQuery("#keataspage").fadeIn(400) : jQuery("#keataspage").fadeOut(400)
    // });
    jQuery(window).scroll(function() {
        500 < jQuery(this).scrollTop() ? jQuery("#postlayangnext").fadeIn(400) : jQuery("#postlayangnext").fadeOut(400)
    });
});