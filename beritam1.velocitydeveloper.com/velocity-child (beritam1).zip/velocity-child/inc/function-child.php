<?php
/**
 * Fuction yang digunakan di theme ini.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Update jumlah pengunjung dengan plugin WP-Statistics
function velocity_allpage() {
    global $wpdb,$post;
    $postID = $post->ID;
    $count_key = 'hit';
    if(empty($post))
    return false;
    $table_name = $wpdb->prefix . "statistics_pages";
    $results    = $wpdb->get_results("SELECT sum(count) as result_value FROM $table_name WHERE id = $postID");
    $count = $results?$results[0]->result_value:'0';
    if($count=='') {
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    } else {
        update_post_meta($postID, $count_key, $count);
    }
}
add_action( 'wp', 'velocity_allpage' );

// Menampilkan jumlah pengunjung: [hits]
function hits($atts) {
   global $post;
    $atribut = shortcode_atts( array(
        'post_id'     => $post->ID,
    ), $atts );
    $post_id	    = $atribut['post_id'];
   $view = get_post_meta($post_id,'hit',true);
   if(empty($view)){
	   $jml = '0';
   } else {
	   $jml = $view;
   }
   return $jml;
}
add_shortcode( 'hits', 'hits' );

// [cari]
function cariform() {
    $id = rand(9,9999);
    $html = '<div class="vel-cari">
       <span class="tombols" id="'.$id.'"></span>
       <form action="'.get_home_url().'" method="get" class="form-'.$id.'" id="formsearchvel" style="display: none;">
        <input class="search-input" name="s" placeholder="Search.." type="text" required>
        <button class="search-button" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
       </form>
    </div>';
    return $html;
}
add_shortcode ('cari', 'cariform');


//pasang nextpost disingle
function nextpost_disingle() {
    if ( is_singular('post') && !wp_is_mobile()) {
        $prev_post = get_adjacent_post(false, '', true);
        if(!empty($prev_post)) {
            $images = get_the_post_thumbnail_url($prev_post->ID,'thumbnail');
            echo '<div id="postlayangnext"><div class="card border-0"><span class="postlayangnext-remove"><i class="fa fa-times" aria-hidden="true"></i></span><div class="card-body p-3 row">';
            echo '<div class="col-4 pr-0"><image src="'.$images.'"></div>';
            echo '<div class="col-8"><a href="' . get_permalink($prev_post->ID) . '" title="' . $prev_post->post_title . '">' . $prev_post->post_title . '</a></div>';
            echo '</div></div><span class="postlayangnext-text">Next Post</span></div>';
        }
    }
}
add_action('wp_head', 'nextpost_disingle');



function wpvkp_social_buttons($content) {
    global $post;
    if(is_singular() || is_home()){
    
        // Get current page URL 
        $sb_url = urlencode(get_the_permalink($post->ID));
 
        // Get current page title
        $sb_title = str_replace( ' ', '%20', get_the_title($post->ID));
        
        // Get Post Thumbnail for pinterest
        $sb_thumb = get_the_post_thumbnail_url($post->ID,'full');
 
        // Construct sharing URL without using any script
        $whatsappURL ='https://api.whatsapp.com/send?text='.$sb_title.' '.$sb_url;
        $twitterURL = 'https://twitter.com/intent/tweet?text='.$sb_title.'&amp;url='.$sb_url.'&amp;via=wpvkp';
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$sb_url;
        $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$sb_url.'&amp;title='.$sb_title;

       if(!empty($sb_thumb)) {
            $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;media='.$sb_thumb[0].'&amp;description='.$sb_title;
        }
        else {
            $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;description='.$sb_title;
        }
        
        // Based on popular demand added Pinterest too
        $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;media='.$sb_thumb[0].'&amp;description='.$sb_title;
        
        //get views and get shares
        $countviews = get_post_meta($post->ID, 'hit', true)?get_post_meta($post->ID, 'hit', true):0;
        $countshare = get_post_meta($post->ID, 'post_share_count', true)?get_post_meta($post->ID, 'post_share_count', true):0;
 
        // Add sharing button at the end of page/page content
        $content .= '<div class="social-box"><div class="social-btn">';
        $content .= '<div class="btn btn-sm btn-outline-info me-2 mb-1"><span id="datashare" class="font-weight-bold">'.$countshare.'</span> Shares</div>';
        $content .= '<div class="btn btn-sm btn-outline-secondary me-2 mb-1"><span class="font-weight-bold">'.$countviews.'</span> Views</div>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-twitter postshare-button" href="'. $twitterURL .'" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-twitter" aria-hidden="true"></i> Twitter</span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-facebook postshare-button" href="'.$facebookURL.'" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-facebook-square" aria-hidden="true"></i> Facebook</span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-pinterest postshare-button" href="'.$pinterestURL.'" data-pin-custom="true" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-pinterest" aria-hidden="true"></i> Pin It</span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-linkedin postshare-button" href="'.$linkedInURL.'" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-linkedin" aria-hidden="true"></i> LinkedIn</span></a>';
        $content .= '<a class="btn btn-sm btn-success me-2 mb-1 postshare-button" href="'.$whatsappURL.'" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-whatsapp" aria-hidden="true"></i> Whatsapp</span></a>';
        $content .= '</div></div>';
        
        return $content;
    }else{
        // if not a post/page then don't include sharing button
        return $content;
    }
};
// Enable the_content if you want to automatically show social buttons below your post.
//add_filter( 'the_content', 'wpvkp_social_buttons');
// This will create a wordpress shortcode [social].
// Please it in any widget and social buttons appear their.
// You will need to enabled shortcode execution in widgets.
add_shortcode('social-share','wpvkp_social_buttons');



//hoverslidearchive
function hoverslidearchive() {
ob_start(); 
global $post;
$obj = get_queried_object();
$category_id = $obj->term_id; ?>
<div class="row ml-0 mr-0 hoverslidearchive">
    <?php
    $args = array (
                'showposts' => 4,
                'post_per_page' => 4,
                'cat' => $category_id,
            );
        $query = new WP_Query( $args );
        //echo '<pre>',print_r($query),'</pre>';
        if ( $query->have_posts() ) {
        	while ( $query->have_posts() ) {
        		$query->the_post(); 
        		$postid =get_the_ID();
                $categories = get_the_category($postid);
                $catname = $categories[0]->name;
                $catid = $categories[0]->cat_ID;
        		?>
        		
                <div class="col-md-6 framepost">
                    <div class="frame-image">
                        <div class="imghover">
                            <a href="<?php echo get_the_permalink()?>">
                                <?php 
                                    if (has_post_thumbnail()){
                                        echo get_the_post_thumbnail();
                                    }else{
                                        echo '<img src="'.get_stylesheet_directory().'/img/no-image.jpg"/>';
                                    }
                                ?>
                            </a>
                        </div>
                        <div class="overlay"></div>
                        <div class="isihover">
                            <div class="kateg mb-2"><a href="<?php echo get_category_link($catid)?>"><?php echo $catname;?></a></div>
                            <h4 class="fs-5"><a class="text-white" href="<?php echo get_the_permalink()?>"><?php echo get_the_title()?></a></h4>
                            <div class="tanggal"><i class="fa fa-clock"></i> <?php echo get_the_date()?></div>
                        </div>
                    </div>
        		</div>
        		
        	<?php 
        	} // end while
        	wp_reset_postdata();
        } // end if
        ?>
</div>  

<?php
return ob_get_clean();
}
add_shortcode( 'hoverslidearchive', 'hoverslidearchive' );



///ajax
add_action('wp_head','vsstemmart_ajaxurl');
function vsstemmart_ajaxurl() {
    $html    = '<script type="text/javascript">';
    $html   .= 'var ajaxurl = "' . admin_url( 'admin-ajax.php' ) . '"';
    $html   .= '</script>';
    echo $html;
}
add_action('wp_ajax_sharetambah', 'sharetambah_ajax');
add_action('wp_ajax_nopriv_sharetambah', 'sharetambah_ajax');
function sharetambah_ajax() {
    $postID = isset($_POST['id']) ? $_POST['id'] : '';
    $count_key = 'post_share_count';
    $count = get_post_meta($postID, $count_key, true);
    $count++;
	update_post_meta($postID, $count_key, $count);
    echo get_post_meta($postID, $count_key, true);
    wp_die();
}