
<div class="frame-luar">
    <div class="slider-panah"></div>
    <div class="slider-frame-img">
        <?php 
        $query = FLBuilderLoop::query( $settings );
        $posts = $query->posts;
        foreach($posts as $post) {
        		$postid = $post->ID;
                $categories = get_the_category($postid);
                $catname = $categories[0]->name;
                $catid = $categories[0]->cat_ID;
                if (has_post_thumbnail($postid)){
                    $urlimg = get_the_post_thumbnail_url($postid,'full');
                    $urlresize = aq_resize($urlimg, 750, 370, true, true, true );
                    $thumbnail = '<img class="w-100" src="'.$urlresize.'" />';
                } else {
                    $thumbnail = '<svg style="background-color: #333333;width: 100%;height: auto;" width="750" height="370"></svg>';
        		}
                ?>
        		    <div class="frame-slide">
        		        <div class="image-post"><?php echo $thumbnail; ?></div>
        		        <div class="frame-isi">
                            <div class="kategori mb-2"><a href="<?php echo get_category_link($catid);?>"><?php echo $catname;?></a></div>
                            <div class="judul mb-3"><a href="<?php echo get_the_permalink($postid)?>"><?php echo get_the_title($postid)?></a></div>
                            <div class="tanggal">by <span class="nama-author"><?php echo get_the_author($postid);?></span> <?php echo get_the_date('F j, Y',$postid);?></div>
                        </div>
        		    </div>
        <?php } ?>
    </div>
</div>
<div class="frame-kecil py-2">
    <div class="slider-frame-navi">
    <?php foreach($posts as $post) {
        $postid = $post->ID;
        if (has_post_thumbnail($postid)){
            $urlimg = get_the_post_thumbnail_url($postid,'full');
            $urlresize = aq_resize($urlimg, 130, 100, true, true, true );
            $thumbnail = '<img class="w-100" src="'.$urlresize.'" />';
        } else {
            $thumbnail = '<svg style="background-color: #333333;width: 100%;height: auto;" width="130" height="100"></svg>';
        } ?>
        <div><?php echo $thumbnail;?></div> 
    <?php } ?>
</div>
</div>
