
jQuery(function($) {

$('.horizontal-<?php echo $id;?>').slick({
autoplay: true,
//arrows: false,
prevArrow: '<i class="fa fa-angle-left"></i>',
nextArrow: '<i class="fa fa-angle-right"></i>',
vertical: true,
appendArrows: $('.nav-<?php echo $id;?>')
});

});