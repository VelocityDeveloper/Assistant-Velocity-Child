Velocity Child Theme
=================

Child Theme for the Velocity System WordPress theme.

### Usage
Simply download the zip and upload the zip (velocity-child-theme-master.zip) under your WordPress dashboard at Appearance > Themes. Or extract and upload via FTP at wp-content/themes/.


### Renaming
You can of course rename the zip file so it isn't called velocity-child-master.zip (you should do this so it makes more sense) and also change the "Theme Name" at the top of the style.css file.
