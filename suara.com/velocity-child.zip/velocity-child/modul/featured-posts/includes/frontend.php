<?php 
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="mb-0 velocity-featured-posts">
<?php foreach(array_slice($posts,0,4) as $post) { ?>  
<div class="vfp-list pb-2 p-md-1">
  <div class="vfp-image" style="background-image: url(<?php echo wp_get_attachment_url(get_post_thumbnail_id($post));?>);">
    <a class="vfp-post-url" href="<?php echo get_the_permalink($post->ID);?>"></a>
    <div class="vfp-content">
      <?php
      $categories = get_the_category($post->ID);
      if (!empty($categories)) {
        echo '<div class="vfp-categories">';
          foreach($categories as $category) {
              echo '<a class="text-white" href="'.esc_url( get_category_link($category->term_id)).'">'.esc_html($category->name).'</a>';
          }
        echo '</div>';
      } ?>
    	<div class="vfp-title"><a class="text-white" href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post->ID);?></a></div>
    </div>
  </div>
</div>
<?php } ?>
</div>
