<?php global $post;
$images = rwmb_meta( 'gallery', array( 'size' => 'thumbnail' ) );
$video = get_post_meta($post->ID,'video',true);
$width   = 400;
$height  = 400;
$crop    = true;
$upscale = true;
	if($video){
		$embed_code = wp_oembed_get($video, array( 'height' => 400 ));
		echo '<div class="width-100 mb-2">'.$embed_code.'</div>';
	} else if($images){
        echo '<div class="slider-produk mb-3">';
            echo '<div class="bg-white border p-2 mb-1 id-'.$id.'" id="parent-container-'.$id.'">';
                if(has_post_thumbnail($post->ID)){
                  	$caption = get_the_post_thumbnail_caption($post->ID);
                    $urlt = get_the_post_thumbnail_url($post->ID,'full');
                    echo '<div class="p-1 text-center"><a href="'.$urlt.'" data-caption="'.$caption.'"><img class="lazy" src="'.$urlt.'" alt="" data-src="'.$urlt.'">';
                    if($caption){
                        echo '<div class="mt-2 text-dark">'.$caption.'</div>';
                    }
                    echo '</a></div>';
                }
                foreach ( $images as $image ) {
                    $caption = wp_get_attachment_caption($image['ID']);
                    $urlbesar = $image['full_url'];
                    echo '<div class="p-1">';
                    echo '<a href="'.$image['full_url'].'" data-caption="'.$caption.'">';
                    echo '<img class="lazy" src="'.$urlbesar.'" alt="" data-src="'.$urlbesar.'">';
                    if($caption){
                        echo '<div class="mt-2 text-dark">'.$caption.'</div>';
                    }
                    echo '</a></div>';
				}
            echo '</div>';
            echo '<div class="navigasi navid-'.$id.'">';
                if(has_post_thumbnail($post->ID)){
                    $urlkecilt       = aq_resize( $urlt, 165, 165, $crop, true, $upscale );
                    $urlbesart       = aq_resize( $urlt, $width, $height, $crop, true, $upscale );
                    echo '<div class="p-1"><div class="border"><img class="lazy img-float w-100" src="'.$urlkecilt.'" alt="" data-src="'.$urlbesart.'"></div></div>';
                }
                foreach ( $images as $image ) {
                    $urlkecil = aq_resize( $image['full_url'], 165, 165, $crop, true, $upscale );
                    $urlbesar = aq_resize( $image['full_url'], $width, $height, $crop, true, $upscale );
                    echo '<div class="p-1"><div class="border">';
                    echo '<img class="lazy w-100" src="'.$urlkecil.'" alt="" data-src="'.$urlbesar.'">';
                    echo '</div>';
                    echo '</div>';
                }
            echo '</div>';
        echo '</div>';
    } else if(has_post_thumbnail($post->ID)){
        $url            = get_the_post_thumbnail_url($post->ID,'full');
        echo '<div class="slider-produk mb-3">';
            echo '<div class="id-'.$id.'" id="parent-container-'.$id.'">';
                echo '<div class="p-1"><a href="'.$url.'"><img class="lazy img-float w-100" src="'.$url.'" alt="" data-src="'.$url.'"></a></div>';
            echo '</div>';
        echo '</div>';
    }
	
?>