jQuery(function($) {
    jQuery(document).ready(function ($) {
        if ($(window).width() > 768){
            const HeaderHeight = $('header.fl-builder-content').height();
            const stickyHeaderTop = $('.header-sticky');
            $(window).scroll(function(){
                if( $(window).scrollTop() > HeaderHeight ) {
                    stickyHeaderTop.addClass('header-sticky-scrolled');
                } else {
                    stickyHeaderTop.removeClass('header-sticky-scrolled');
                }
            });
        }
    });
});