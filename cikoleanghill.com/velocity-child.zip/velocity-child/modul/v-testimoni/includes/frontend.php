<?php $testimonials = $settings->t_columns;
echo '<div id="testimoni-modul" class="testimoni-'.$id.'">';
foreach($testimonials as $testimoni){
	$star = $testimoni->star;
	$image = $testimoni->image;
    echo '<div class="testimoni-list p-2 text-center">';
	if($image){
		$imgurl = wp_get_attachment_url($testimoni->image);
		$image_url = aq_resize($imgurl,150,150,true,true,false);
		echo '<img class="rounded-circle d-inline-block" src="'.$image_url.'" >';
	} else {
		echo '<i class="fa fa-user-circle-o fa-custom" aria-hidden="true"></i>';
	}
    echo '<div class="mt-3">';
	for ($x = 1; $x <= $star; $x++) {
		echo '<i class="fa fa-star m-1 text-warning fa-lg" aria-hidden="true"></i>';
	}
	$sisa = 5 - $star;
	if($sisa > 0){
		for ($x = 1; $x <= $sisa; $x++) {
			echo '<i class="fa fa-star-o m-1 text-warning fa-lg" aria-hidden="true"></i>';
		}
	}
    echo '<div class="mt-2 fs-6 fw-bold">'.$testimoni->title.'</div>';
    echo '<div class="mb-2 fst-italic"><small>'.$testimoni->profession.'</small></div>';
    echo '<p>"'.$testimoni->description.'"</p>';
    echo '</div>';
    echo '</div>';
}
echo '</div>';?>
