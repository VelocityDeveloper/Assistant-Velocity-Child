jQuery(function($) {
$('.testimoni-<?php echo $id; ?>').slick({
  dots: true,
  infinite: false,
  arrows: false,
  autoplay: true,
  speed: 300,
  slidesToShow: 1,
  slidesToScroll: 1,
});
});

