<?php

/**
 * @class FLvIconSeparator
 */
class FLvIconSeparator extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'            => __( 'Icon Separator', 'fl-builder' ),
			'description'     => __( 'Display an icon separator.', 'fl-builder' ),
			'category'		=> __('Basic', 'fl-builder'),
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvIconSeparator', array(
	'general' => array( // Tab
		'title'    => __( 'General', 'fl-builder' ), // Tab title
		'sections' => array( // Tab Sections
			'general' => array( // Section
				'title'  => '', // Section Title
				'fields' => array( // Section Fields
					'icon'    => array(
						'type'    => 'icon',
						'label'   => __( 'Icon', 'fl-builder' ),
						'preview' => array(
							'type' => 'none',
						),
					),
					'width'  => array(
						'type'       => 'unit',
						'label'      => __( 'Width (%)', 'fl-builder' ),
						'default'    => '30',
					),
					'size'  => array(
						'type'       => 'unit',
						'label'      => __( 'Size (px)', 'fl-builder' ),
						'default'    => '30',
					),
					'color'          => array(
						'type'        => 'color',
						'connections' => array( 'color' ),
						'label'       => __( 'Color', 'fl-builder' ),
						'show_reset'  => true,
						'show_alpha'  => true,
						'default'    => '333333',
						'preview'     => array(
							'type'      => 'css',
							'selector'  => '.velocity-icon-separator i',
							'property'  => 'color',
							'important' => true,
						),
					),

				),
			),
		),
	),
));
