<div class="icon-separator-<?php echo $id;?> text-center">
  <div class="velocity-frame-separator">
    <div class="velocity-left-separator"><span></span></div>
    <div class="velocity-icon-separator"><i class="<?php echo $settings->icon; ?>" aria-hidden="true"></i></div>
    <div class="velocity-right-separator"><span></span></div>
  </div>
</div>
