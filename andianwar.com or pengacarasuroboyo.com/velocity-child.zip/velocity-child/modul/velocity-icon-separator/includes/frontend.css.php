.icon-separator-<?php echo $id;?> i {
	color: #<?php echo $settings->color; ?>;
	font-size: <?php echo $settings->size; ?>px;
}
.icon-separator-<?php echo $id;?> .velocity-frame-separator {
	width: <?php echo $settings->width; ?>%;
	display: table;
    margin-left: auto;
    margin-right: auto;
}
.icon-separator-<?php echo $id;?> .velocity-left-separator,
.icon-separator-<?php echo $id;?> .velocity-right-separator  {
	width: 50%;
	display: table-cell;
	vertical-align: middle;
}
.icon-separator-<?php echo $id;?> span {
	border-top: 1px solid #<?php echo $settings->color; ?>;
	display: block;
	margin-top: 0 !important;
}
.icon-separator-<?php echo $id;?> .velocity-icon-separator {
  display: table-cell;
  padding-left: 10px;
  padding-right: 10px;
}