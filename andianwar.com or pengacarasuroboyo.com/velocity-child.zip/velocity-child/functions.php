<?php
/**
 * Child theme functions
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development
 * and http://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions would be used.
 *
 * Text Domain: justg
 * @link http://codex.wordpress.org/Plugin_API
 *
 */

/**
 * Load other required files
 *
 */

 $inc = get_stylesheet_directory() . '/inc';
 $includes = [
	'enqueue.php',
	'function-child.php',
	'shortcodes.php'
 ];

 foreach( $includes as $include ) {
	 require_once( $inc . '/' . $include );
 }

function vsstem_modul() {
	if ( class_exists( 'FLBuilder' ) ) {
	    get_template_part('modul/velocity-icon-separator/velocity-icon-separator');
	}
}
add_action( 'init', 'vsstem_modul' );

// [cari]
function cariform() {
    $id = rand(9,9999);
    $html = '<div class="vel-cari position-relative">
       <span class="tombols" id="'.$id.'"></span>
       <form action="'.get_home_url().'" method="get" class="form-'.$id.'" id="formsearchvel" style="display: none;">
        <input class="search-input" name="s" placeholder="Search.." type="text" required>
        <button class="search-button" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
       </form>
    </div>';
    return $html;
}
add_shortcode ('cari', 'cariform');

// [social-share]
function vel_social_buttons($content) {
    global $post,$wp;
    if(is_singular() || is_home()){
        $post_id = $post->ID;
		// Get current URL 
        $sb_url = urlencode(get_permalink($post_id));
		//$sb_url = home_url(add_query_arg(array($_GET), $wp->request));
 
        // Get current web title
        $sb_title = str_replace( ' ', '%20', get_the_title($post_id));
        //$sb_title = wp_title('',false);
         
        // Construct sharing URL without using any script
        $twitterURL = 'https://twitter.com/intent/tweet?text='.$sb_title.'&amp;url='.$sb_url;
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$sb_url;
        $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$sb_url.'&amp;title='.$sb_title;
        $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;description='.$sb_title;
        $whatsappURL ='https://api.whatsapp.com/send?text='.$sb_title.' '.$sb_url;
        $telegramURL ='https://telegram.me/share/url?url='.$sb_url.'';
        $emailURL ='mailto:?subject=I wanted you to see this site&amp;body='.$sb_title.' '.$sb_url.' ';
        
        //get views and get shares
        //$countviews = get_post_meta($post_id, 'hit', true)?get_post_meta($post_id, 'hit', true):0;
        //$countshare = get_post_meta($post_id, 'post_share_count', true)?get_post_meta($post_id, 'post_share_count', true):0;
 
        // Add sharing button at the end of page/page content
        $content .= '<div class="social-box">';
        //$content .= '<div class="btn btn-sm btn-outline-info me-2 mb-1"><span id="datashare" class="font-weight-bold">'.$countshare.'</span> Shares</div>';
        //$content .= '<div class="btn btn-sm btn-outline-secondary me-2 mb-1"><span class="font-weight-bold">'.$countviews.'</span> Views</div>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-twitter postshare-button" href="'.$twitterURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-twitter" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-facebook postshare-button" href="'.$facebookURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-facebook-square" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-whatsapp postshare-button" href="'.$whatsappURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-whatsapp" aria-hidden="true"></i></span></a>';
        //$content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-pinterest postshare-button" href="'.$pinterestURL.'" data-pin-custom="true" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-pinterest" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-linkedin postshare-button" href="'.$linkedInURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-linkedin" aria-hidden="true"></i></span></a>';
        //$content .= '<a class="btn btn-sm btn-info me-2 mb-1 s-telegram postshare-button" href="'.$telegramURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-telegram" aria-hidden="true"></i></span></a>';
        //$content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-email postshare-button" href="'.$emailURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-envelope-o" aria-hidden="true"></i></span></a>';
        $content .= '</div>';
        
        return $content;
    } else {
        // if not a post/page then don't include sharing button
        return $content;
    }
};
add_shortcode('social-share','vel_social_buttons');