# Plugin Velocity Toko

Plugin Toko Online untuk projek Velocity Developer

## Shortcode

#### Thumbnail

```php
[thumbnail width='150' height='300' crop='false' upscale='true']
```

- width: lebar gambar
- height: tinggi gambar
- flip: flip hover effect. true/false

#### Thumbnail Full

```php
[thumbnailfull]
```

#### Print Button

```php
[print targetid="print"]
```

#### Slider Produk

```php
[slider-produk]
```

- width: lebar gambar
- height: tinggi gambar
- nav-vertical: tampilkan Navigasi Vertical. true/false

#### Harga Produk

```php
[harga diskon='true' countdown='true']
```

- diskon: tampilkan harga diskon. true/false
- countdown: tampilkan countdown. true/false

#### Tombol Love

```php
[love text='true']
```

#### Cart / icon Keranjang

```php
[cart]
```

#### Profile / icon profile

```php
[profile]
```

#### Paypal

```php
[paypal]
```

#### Bank / daftar bank

```php
[bank logo="true" atasnama="true" norek="true"]
```

- logo: tampilkan logo bank. true/false
- atasnama: tampilkan atasnama akun. true/false
- norek: tampilkan no rekening akun. true/false

#### Detail Produk

```php
[detail-produk]
```

#### View Produk

```php
[view]
```

#### Tombol Share

```php
[share]
```

#### Tombol Beli Lain

```php
[beli-lain]
```

#### Daftar Kontak

```php
[kontak]
```

#### Tombol Beli

```php
[beli text='true']
```

- text : tampilkan text beli. true/false
- class : class tambahan untuk tombol
- button-text : ubah text tombol
- modal : tampilan opsi beli dalam modal / inline. true/false
- node-cart : id node, untuk sync data produk

#### Form Cek Ongkir

```php
[cek-ongkir]
```

#### List Taxonomy

```php
[list-group-taxonomy taxonomy="category-product"]
```

- taxonomy: name taxonomy. category-product/tag-product

#### Carousel Product

```php
[carousel-product limit="3"]
```

- limit: Limit tampil produk. (number)
- category: Id category produk. (number)
- label: label produk. 'best/new/limited' (string) (optional)

#### Excerpt Post

```php
[vtoko-excerpt length="150"]
```

- length: jumlah kata / karakter (number)

#### Form Search Product

```php
[vtoko-search-product placeholder="Cari produk.."]
```

- placeholder : placeholder input (string)
- category : tampilkan category dropdown. true/false

#### Sosmed Card

```php
[vtoko-sosmed]
```

- facebook: url facebook (string)
- twitter: url twitter (string)
- instagram: url instagram (string)
- youtube: url youtube (string)

#### Title Product

```php
[vtoko-title]
```

- link: tampilkan dalam bentuk link. true/false
- node-cart : id node, untuk sync data produk
