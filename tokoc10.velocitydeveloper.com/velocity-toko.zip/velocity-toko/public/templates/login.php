<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
?>

<div style="max-width:500px" class="mx-auto w-100 my-4 p-3 form-login card">
    <form name="velocitytoko_login" id="login" action="login" method="post">
        <h3 class="title">Login Customer Area</h3>
        <p class="status"></p>
        <div class="form-group">
            <label for="username">Username</label>
            <input id="username" type="text" class="form-control" name="username" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input id="password" type="password" class="form-control" name="password" required>
        </div>
        <input id="redirect" type="hidden" value="<?php echo get_home_url();?>">
        <div class="form-group mb-2">
            <?php echo velocitytoko_display_recaptcha(); ?>
        </div>
        <div class="mb-4"><a class="lost" href="<?php echo wp_lostpassword_url();?>">Lost your password?</a></div>
        <input class="btn btn-dark" type="submit" value="Login" name="submit">
        <?php wp_nonce_field( 'ajax-login-nonce', 'security' );?>
        <a class="btn ms-3 btn-dark" href="?register=yes" title="Daftar">Daftar</a>
    </form>
</div>