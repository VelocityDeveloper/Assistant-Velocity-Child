<?php
/**
 * Template Name: Katalog
 *
 * @package velocity-toko
 */

get_header();
$container		= get_theme_mod( 'justg_container_type','container' );
$search_query 	= new WP_Query( array(
    'post_type'         => 'product',
    'post_status'       => 'publish',
    'order'             => 'asc',
    'orderby'           => 'title',
    'posts_per_page'    => -1
) );
?>

<div class="wrapper" id="page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

			<div class="content-area order-2" id="primary">

        		<?php echo do_shortcode('[print targetid="main"]');?>

				<main class="site-main mt-3" id="main">
						<?php if ( $search_query->have_posts() ) : ?>
							<div class="row">
								<?php while ( $search_query->have_posts() ) : $search_query->the_post(); ?>

									<?php echo apply_filters( 'velocitytoko_content_loop_archive', $post ); ?>

								<?php endwhile; ?>
							</div>
						<?php else : ?>
							<div class="container text-center">
								<span>
									<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor" class="bi bi-bag" viewBox="0 0 16 16"> <path d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1zm3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4h-3.5zM2 5h12v9a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5z"/> </svg>
								</span>
								<h3 class="mt-4 mb-3"> Tidak Ditemukan! :(</h3>
								Coba gunakan filter lain.
							</div>
						<?php endif; ?>

					</main><!-- #main -->

				</div><!-- #primary -->


		</div><!-- #content -->

	</div><!-- #page-wrapper -->

<?php
get_footer();

