<?php
/* Template Name: profile
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package velocity-toko
 */

get_header();
global $wpdb;
global $post;
$container	    = get_theme_mod( 'justg_container_type','container' );
$table_order    = $wpdb->prefix . "order"; 
$user_id        = get_current_user_id();
$current_user   = wp_get_current_user();
$details        = $wpdb->get_results("SELECT * FROM $table_order WHERE id_pembeli = '".$user_id."'");
$getinvoice     = isset($_GET['invoice'])?$_GET['invoice']:'';
$register       = isset($_GET['register'])?$_GET['register']:'';
?>

<div class="wrapper" id="page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

		<div class="row">

			<div class="content-area col order-2 px-md-0" id="primary">

				<main class="site-main" id="main" role="main">
            
          <?php
          $nama = get_user_meta( $user_id, 'nama',true );
          if(null == $nama){
              $nama = $current_user->user_login;
          }
          if($getinvoice != ''){
              if($getinvoice == 'yes') {
                  $getinvoice = '';
              }
              ?>
              <div class="mb-4 justify-content-center">
                  <div class="card">
                              <div class="card-header fs-6">
                                  Status Pesanan
                              </div>
                              <div class="card-body">
                                  <form class="form-row row" method="get">
                                    <div class="col-12 col-md-9 mb-2 mb-md-0">
                                      <div class="input-group">
                                        <div class="input-group-prepend">
                                          <span class="input-group-text rounded-0 rounded-start py-2" id="invoice">Kode Invoice</span>
                                        </div>
                                        <input type="text" class="form-control" max="10" value="<?php echo $getinvoice; ?>" id="invoice" name="invoice" required>
                                      </div>
                                    </div>
                                    <div class="col-12 col-md-3 ps-md-0">
                                        <button type="submit" class="btn btn-dark w-100 py-2">Cek Pesanan</button>
                                    </div>
                                  </form>
                              </div>
                          </div>
                      </div>
                      <?php
              require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/profile-detail-invoice.php';
          } else if($register=='yes'){
              require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/register.php';
          } else {
              if(is_user_logged_in()){
                  ?>
                  <div class="container alert alert-info">
                      <div class="row align-items-center">
                          <div class="col-sm-6 mb-3 mb-sm-0"><h5 class="m-0 title">Hallo, <?php echo $nama;?></h5></div>
                          <div class="col-sm-6 text-sm-end">
                              <?php if( current_user_can('editor') || current_user_can('administrator') ): ?>
                                  <a class="btn-sm btn btn btn-info me-2" href="<?php echo admin_url();?>">wp-admin</a>
                              <?php endif; ?>
                              <a class="btn-sm btn btn-warning" href="<?php echo wp_logout_url();?>">Logout</a>
                          </div>
                      </div>
                  </div>
                  
                          <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                              <a class="nav-link active show" data-bs-target="#profile" role="tab" data-bs-toggle="tab">Profile</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" data-bs-target="#riwayat" role="tab" data-bs-toggle="tab">Riwayat Pesanan</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" data-bs-target="#wishlist" role="tab" data-bs-toggle="tab">Wishlist</a>
                            </li>
                          </ul>
                          
                          <!-- Tab panes -->
                          <div class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active show" id="profile">
                                <?php require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/profile-member.php'; ?>
                                <?php require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/profile-dropship.php'; ?>
                            </div>
                            <div role="tabpanel" class="tab-pane" id="riwayat">
                                <?php require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/profile-history.php'; ?>
                            </div>
                            <div role="tabpanel" class="tab-pane" id="wishlist">
                                <?php require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/profile-love.php'; ?>
                            </div>
                          </div>
              <?php
              } else {
                  require VELOCITY_TOKO_PLUGIN_DIR . '/public/templates/login.php';
              }
          }
          ?>

          </main><!-- #main -->
  
        </div><!-- #primary -->
    
      </div>
  
    </div><!-- #content -->
  
  </div><!-- #page-wrapper -->
  
  <?php
  get_footer();
  
