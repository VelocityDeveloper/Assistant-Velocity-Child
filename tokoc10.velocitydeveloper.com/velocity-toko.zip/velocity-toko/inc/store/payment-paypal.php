<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
 ?>
 <div class="text-center">
    <h3 class="mb-3">Terima Kasih, Pesanan Anda Berhasil di kirim!</h3>
    
    <?php
        $pesan              = velocitytoko_option('pesancheckout');
        $pesan              = str_replace('[nama-customer]',$nama,$pesan);
        $pesan              = str_replace('[nama-toko]',$namatoko,$pesan);
        $pesan              = str_replace('[email-cust]',$email,$pesan);
        echo $pesan;
    ?>
    
    <div class="row pesan-transfer mt-3 mb-3">
        <div class="col-sm-4">
            <i class="fa fa-credit-card"></i>
            <p>Bayar dengan Paypal, klik icon paypal checkout dibawah dan ikuti langkah pembayaran sampai selesai</p>
        </div>
        <div class="col-sm-4">
            <i class="fa fa-check-square-o"></i>
            <p>Konfirmasi pembayaran dengan cara mengisi <a href="<?php echo get_permalink( get_page_by_path( 'myaccount' ) ); ?>?invoice=<?php echo $invoice; ?>">formulir online</a> atau menghubungi customer service kami di <?php echo velocitytoko_option('notlp_velocitytoko'); ?></p>
        </div>
        <div class="col-sm-4">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-text" viewBox="0 0 16 16">
        <path d="M5 4a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1H5zm-.5 2.5A.5.5 0 0 1 5 6h6a.5.5 0 0 1 0 1H5a.5.5 0 0 1-.5-.5zM5 8a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1H5zm0 2a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1H5z"/>
        <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2zm10-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1z"/>
        </svg> 
            <p>Pesanan akan segera di proses setelah anda melakukan konfirmasi pembayaran</p>
        </div>
    </div>
    
    <div class="frame-invoice">
        <p class="text-dark">Kode Pemesanan Anda (Invoice) :</p><br>
        <span>
            <?php echo $invoice; ?>
        </span>
    </div>
    
    <div class="mt-4" id="paypal-button"></div>
    
    <div>
        <p class="mt-3">Setelah Melakukan Pembayaran silahkan melakukan konfirmasi Pembayaran melalui <b><a href="<?php echo get_permalink( get_page_by_path( 'myaccount' ) ); ?>?invoice=<?php echo $invoice; ?>">Klik Disini</a></b></p>
    </div>
</div>
<script src="https://www.paypalobjects.com/api/checkout.js"></script>
<script>
paypal.Button.render({
    // Configure environment
    env: '<?php echo $paypalmode; ?>', // sandbox | production
    client: {
    sandbox: '<?php echo $paypalclientid; ?>',
    production: '<?php echo $paypalclientid; ?>'
    },
    // Customize button (optional)
    locale: 'id_ID',
    style: {
    size: 'large',
    color: 'gold',
    shape: 'pill',
    fundingicons: 'true',
    },
    funding: {
      allowed: [ paypal.FUNDING.CARD ],
      disallowed: [ paypal.FUNDING.CREDIT ]
    },
    // Set up a payment
    payment: function (data, actions) {
    return actions.payment.create({
      transactions: [{
        amount: {
          total: '<?php echo $hargatotaldolar; ?>',
          currency: 'USD'
        }
      }]
    });
    },
    // Execute the payment
    onAuthorize: function (data, actions) {
    return actions.payment.execute()
      .then(function () {
        // Show a confirmation message to the buyer
        window.alert('Terimakasih Telah melakukan pembayaran!');
      });
    }
}, '#paypal-button');
</script>