<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
$alamat = '';
 ?>
<div class="col-md-7">
        <h3 class="text-colortheme">Detail Informasi</h3>
        <?php if($statusdropship == 'on' && $userdropship == 'on' && !empty($getnama)){ ?>
            <div class="alert alert-warning" role="alert">
              Status pembelian sebagai dropshiper, barang akan dikirim dengan nama toko <b><?php echo $getnama;?></b>. Isi data di bawah sesuai data customer anda.
              <input type="hidden"  id="dropship" name="dropship" value="yes" class="form-control datapengiriman" required></input>
            </div>
        <?php }else if($statusdropship == 'on' && $userdropship == 'on' && empty($getnama)){ ?>
            <div class="alert alert-warning" role="alert">
              Status pembelian sebagai dropshiper Aktif, tp nama toko anda kosong. Silahkan lengkapi data dropship anda di bagian profile atau kami lanjutkan dengan nama toko <?php echo $namatoko;?>.
            </div>
        <?php } ?>

        <?php if(get_user_meta( $user_id, 'alamat',true ) && (($statusdropship == 'off') || ($statusdropship == 'on' && $userdropship != 'on' ))){ ?>
           
            <div class="card mb-2 font-weight-bold">
                <div class="card-body">
                    <div class="row align-items-start">
                        <div class="col-md-6 position-relative">
                            <?php
                                echo '<label id="toggleyes" class="pointer opsitoggle">
                                <input type="radio" name="pengiriman" value="yes" class="float-left pe-2" required>
                                <p class="float-left">';
                                    echo get_user_meta( $user_id, 'nama',true ).'<br>';
                                    echo get_user_meta( $user_id, 'hp',true ).'<br>';
                                    echo get_user_meta( $user_id, 'alamat',true ).'<br>';
                                    $alamat = get_user_meta( $user_id, 'subdistrict_destination',true )?getSingleSubdistrict(get_user_meta( $user_id, 'subdistrict_destination',true )):'';
                                    if($alamat) {
                                        echo $alamat[0]['subdistrict_name'].', '.$alamat[0]['city'].', '.$alamat[0]['province'].'<br>';
                                    }
                                    echo get_user_meta( $user_id, 'kodepos',true ).'<br>';
                                    echo '<a href="/myaccount/">';
                                        echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-fill" viewBox="0 0 16 16"> <path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z"/> </svg> Edit';
                                    echo '</a>';
                                echo '</p></label>';
                            ?>
                        </div>
                        <div class="col-md-6 position-relative">
                            <label id="toggleno" class="pointer opsitoggle">
                                <input type="radio" name="pengiriman" value="no" class="float-left pe-2" required>
                                <p class="float-left">Kirim ke Alamat Lainya</p></label>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                <small class="text-muted">Pilih Alamat Tujuan</small>
                </div>
            </div>

        <?php
        } else {
            echo '<input type="hidden" name="pengiriman" value="no" class="fa fa-check-circle-o float-left pe-2" required>';
        }
        ?>
        <table class="table ifno noborder">
            <tr>
                <td>
                    Email *
                </td>
                <td>
                    <input type="email"  id="email" name="email" value="" class="form-control datapengiriman" required></input>
                </td>
            </tr>
            <tr>
                <td>
                    Nama Lengkap *
                </td>
                <td>
                    <input type="text"  id="nama" maxlength="50" name="nama" value="" class="form-control datapengiriman" required></input>
                </td>
            </tr>
            <tr>
                <td>
                    Nomor Handphone *
                </td>
                <td>
                    <input type="number" maxlength="15" id="hp" name="hp" value="" class="form-control datapengiriman" required></input>
                </td>
            </tr>
            <tr>
                <td>
                    Alamat *
                </td>
                <td>
                    <input type="text"  id="alamat" maxlength="100" name="alamat" value="" class="form-control datapengiriman" required></input>
                </td>
            </tr>
            <tr>
                <td>
                    Provinsi *
                </td>
                <td>
                    <select name="prov_destination" required id="prov-destination" class="form-control datapengiriman"><option class="" value="">Provinsi</option>
            		        <?php
            				$data_province = getProvince();
            		        for ($i=0; $i < count($data_province); $i++) {
                                    echo "<option value='".$data_province[$i]['province_id']."' >".$data_province[$i]['province']."</option>";
            		        }
            				?>
            		</select>
                </td>
            </tr>
            <tr>
                <td>
                    Kota *
                </td>
                <td>
                    <select name="city_destination" required id="city-destination" class="form-control datapengiriman"><option selected class="" value="" >Kota</option>
            		      <?php
            		      $data_City = getCity();
            		      for ($x=0; $x < count($data_City); $x++) {
            		          $type = $data_City[$x]['type'];
                              if( $type == 'Kabupaten'){
                                  $type = 'Kab';
                              }
                              echo "<option value='".$data_City[$x]['city_id']."' class='". $data_City[$x]['province_id']."' >".$type." ".$data_City[$x]['city_name']."</option>";
            		      }
            			  ?>
            		</select>
                </td>
            </tr>
            <tr>
                <td>
                    Kecamatan *
                </td>
                <td>
                    <select name="subdistrict_destination" required id="subdistrict-destination" class="form-control datapengiriman">
                    <?php
                    if($alamat){
                        $a = $alamat[0]['city_id'];
                        $data_Subdistrict = getSubdistrict($a);
                        echo "<option value=''>Kecamatan</option>";
                        for ($x=0; $x < count($data_Subdistrict); $x++) {
                            echo "<option value='".$data_Subdistrict[$x]['subdistrict_id']."' class='". $data_Subdistrict[$x]['city_id']."' >".$data_Subdistrict[$x]['subdistrict_name']."</option>";
                        }
                    }
                    ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>
                    Kode Pos *
                </td>
                <td>
                    <input type="number"  id="kodepos" name="kodepos" value="" maxlength="10" class="form-control datapengiriman" required></input>
                </td>
            </tr>
            
        </table>
		
    </div>