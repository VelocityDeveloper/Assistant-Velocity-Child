<?php 
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="vd-post-carousel">
    <div class="vd-carousel-<?php echo $id; ?>">
        <?php foreach($posts as $post) { ?>
            <div class="p-2">
                <?php echo do_shortcode('[velocity-post-loop post_id="'.$post->ID.'"]');?>
            </div>
        <?php } ?>
    </div>
</div>
