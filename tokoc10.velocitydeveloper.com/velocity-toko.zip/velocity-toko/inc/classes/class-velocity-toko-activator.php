<?php
/**
 * Fired during plugin activation
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Velocity_toko
 * @subpackage Velocity_toko/inc/classes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 */
class Velocity_Toko_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
        self::create_db_velocity_toko();
        flush_rewrite_rules();
	}

    public static function create_db_velocity_toko() {
        
        global $wpdb;
        date_default_timezone_set('Asia/Jakarta'); 
        $table_cart     = $wpdb->prefix . "keranjang";     
        $table_order    = $wpdb->prefix . "order";   
        $table_kupon    = $wpdb->prefix . "kupon";   
        $table_ongkir   = $wpdb->prefix . "ongkir";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        $sql = "CREATE TABLE IF NOT EXISTS $table_cart 
        (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            id_pembeli varchar(255) NOT NULL,
            id_produk varchar(114) NOT NULL,
            jumlah varchar(114) NOT NULL,
            detail text NOT NULL,
            PRIMARY KEY  (id)
        );  
        ";
        dbDelta($sql);

        $sql = "CREATE TABLE IF NOT EXISTS $table_order 
        (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            id_pembeli varchar(255) NOT NULL,
            invoice varchar(114) NOT NULL,
            date varchar(114) NOT NULL,
            detail text NOT NULL,
            status varchar(114) NOT NULL,
            kurir varchar(114) NOT NULL,
            resi varchar(114) NOT NULL,
            PRIMARY KEY  (id)
        );  
        ";
        dbDelta($sql);

        $sql = "CREATE TABLE IF NOT EXISTS $table_ongkir
        (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            kecamatan varchar(114) NOT NULL,
            ongkir varchar(255) NOT NULL,
            PRIMARY KEY  (id)
        );  
        ";
        dbDelta($sql);

        $sql = "CREATE TABLE IF NOT EXISTS $table_kupon
        (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            kode varchar(114) NOT NULL,
            detail text NOT NULL,
            PRIMARY KEY  (id)
        );  
        ";
        dbDelta($sql);

    }

}