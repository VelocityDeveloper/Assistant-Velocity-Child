<?php
/**
 * function register asset css and sj to frontend public.
 *
 * @package Velocity Toko
 */

if ( ! function_exists( 'velocitytoko_register_scripts' ) ) {
	/**
	 * Load theme's JavaScript and Style sources.
	 */
	function velocitytoko_register_scripts() {

		// Get the version.
		$the_version = VELOCITY_TOKO_VERSION;

		wp_enqueue_style( 'slick-style', VELOCITY_TOKO_PLUGIN_URL . 'public/css/slick.min.css', array(), $the_version, false );
		wp_enqueue_style( 'slick-theme-style', VELOCITY_TOKO_PLUGIN_URL . 'public/css/slick-theme.min.css', array(), $the_version, false );
		wp_enqueue_style( 'magnific-popup-style', VELOCITY_TOKO_PLUGIN_URL . 'public/css/magnific-popup.css', array(), $the_version, false );
		wp_enqueue_style( 'jquery-ui-style', VELOCITY_TOKO_PLUGIN_URL . 'public/css/jquery-ui.min.css', array(), $the_version, false );
		wp_enqueue_style( 'velocitytoko-store-style', VELOCITY_TOKO_PLUGIN_URL . 'public/css/style-store.css', array(), $the_version, false );
		wp_enqueue_style( 'velocitytoko-style', VELOCITY_TOKO_PLUGIN_URL . 'public/css/style.css', array(), $the_version, false );

		$css_version = $the_version . '.' . filemtime( VELOCITY_TOKO_PLUGIN_DIR . 'custom/css/custom.css' );
		wp_enqueue_style( 'velocitytoko-custom-style', VELOCITY_TOKO_PLUGIN_URL . 'custom/css/custom.css', array(), $css_version, false );
		
		wp_enqueue_script( 'jquery');
		wp_enqueue_script( 'jquery-ui-slider');
		wp_enqueue_script( 'google-recaptcha','https://www.google.com/recaptcha/api.js', array(), $the_version, true );
		wp_enqueue_script( 'jquery-ui', VELOCITY_TOKO_PLUGIN_URL . 'public/js/jquery-ui.min.js', array(), $the_version, true );
		wp_enqueue_script( 'velocitytoko-lib-script', VELOCITY_TOKO_PLUGIN_URL . 'public/js/lib.min.js', array(), $the_version, true );
		wp_enqueue_script( 'magnific-popup', VELOCITY_TOKO_PLUGIN_URL . 'public/js/jquery.magnific-popup.min.js', array(), $the_version, true );
		wp_enqueue_script( 'velocitytoko-store-script', VELOCITY_TOKO_PLUGIN_URL . 'public/js/store.js', array('jquery'), $the_version, true );

		$js_version = $the_version . '.' . filemtime( VELOCITY_TOKO_PLUGIN_DIR . 'custom/js/custom.js' );
		wp_enqueue_script( 'velocitytoko-custom-script', VELOCITY_TOKO_PLUGIN_URL . 'custom/js/custom.js', array('jquery'), $js_version, false );
    }
    add_action( 'wp_enqueue_scripts', 'velocitytoko_register_scripts' );
}