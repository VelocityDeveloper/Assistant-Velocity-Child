<?php
/**
 * Customizer use Kirki
 *
 * @package Velocity Toko
 */
 
// Exit if accessed directly.
defined('ABSPATH') || exit;

if (!class_exists('Kirki'))
return false;

//Panel Velocity Toko
new \Kirki\Panel(
    'velocitytoko_id',
    [
        'priority'    => 20,
        'title'       => esc_html__( 'Velocity Toko', 'velocity-toko' ),
        'description' => esc_html__( 'Velocity Toko settings.', 'velocity-toko' ),
    ]
);
    //Style Section
    new \Kirki\Section(
        'section_style_velocitytoko',
        [
            'title'       => esc_html__( 'Style', 'velocity-toko' ),
            'description' => esc_html__( 'Anda dapat mengatur tampilan toko disini.', 'velocity-toko' ),
            'panel'       => 'velocitytoko_id',
            'priority'    => 10,
        ]
    );
        new \Kirki\Field\Color(
            [
                'settings'    => 'velocitytoko_color_main',
                'label'       => __( 'Warna Tema A', 'kirki' ),
                'description' => esc_html__( '', 'kirki' ),
                'section'     => 'section_style_velocitytoko',
                'default'     => '#1E73BE',
                'transport'   => 'auto',
                'output'      => [
                    [
                        'element'   => '.bg-colortheme, .page-item.active .page-link',
                        'property'  => 'background-color',
                    ],
                    [
                        'element'   => '.bg-colortheme, .page-item.active .page-link',
                        'property'  => 'border-color',
                    ],
                    [
                        'element'   => ':root',
                        'property'  => '--velocitytoko-color-main',
                    ]
                ],
            ]
        );
        new \Kirki\Field\Color(
            [
                'settings'    => 'velocitytoko_color_secondary',
                'label'       => __( 'Warna Tema B', 'kirki' ),
                'description' => esc_html__( '', 'kirki' ),
                'section'     => 'section_style_velocitytoko',
                'default'     => '#333333',
                'transport'   => 'auto',
                'output'      => [
                    [
                        'element'   => '.bg-colortheme:hover, .page-item.active .page-link:hover',
                        'property'  => 'background-color',
                    ],
                    [
                        'element'   => '.bg-colortheme:hover, .page-item.active .page-link',
                        'property'  => 'border-color',
                    ],
                    [
                        'element'   => '.text-colortheme, .text-colortheme i, .page-link',
                        'property'  => 'color',
                    ],
                    [
                        'element'   => ':root',
                        'property'  => '--velocitytoko-color-secondary',
                    ]
                ],
            ]
        );

    //Pengiriman Section
    new \Kirki\Section(
        'section_pengiriman',
        [
            'title'       => esc_html__( 'Pengiriman', 'velocity-toko' ),
            'description' => esc_html__( 'Anda dapat mengatur Pengiriman disini.', 'velocity-toko' ),
            'panel'       => 'velocitytoko_id',
            'priority'    => 160,
        ]
    );
        new \Kirki\Field\Radio_Buttonset(
            [
                'settings'    => 'ongkir',
                'label'       => esc_html__( 'Aktifkan Ongkos Kirim', 'velocity-toko' ),
                'description' => esc_html__( 'Jika tidak dicentang maka biaya ongkos kirim gratis.', 'velocity-toko' ),
                'section'     => 'section_pengiriman',
                'default'     => '0',
                'choices'     => [
                    '0' => esc_html__( 'Disable', 'velocity-toko' ),
                    '1'  => esc_html__( 'Enable', 'velocity-toko' ),
                ],
            ]
        );
        new \Kirki\Field\Select(
            [
                'settings'    => 'city_origin',
                'label'       => esc_html__( 'Kota Asal Pengiriman', 'velocity-toko' ),
                'section'     => 'section_pengiriman',
                'default'     => '',
                'placeholder' => esc_html__( 'Ketik Nama Kota Anda dan pilih.', 'velocity-toko' ),
                'choices'     => getCityProvince(),
            ]
        );
        new \Kirki\Field\Multicheck(
            [
                'settings'    => 'courier',
                'label'       => esc_html__( 'Pilih Kurir', 'velocity-toko' ),
                'section'     => 'section_pengiriman',
                'default'     => '',
                'placeholder' => esc_html__( 'Ketik Nama Kota Anda dan pilih.', 'velocity-toko' ),
                'choices'     => list_velocitytoko_courier(),
            ]
        );
        new \Kirki\Field\Select(
            [
                'settings'    => 'cod',
                'label'       => esc_html__( 'COD', 'velocity-toko' ),
                'section'     => 'section_pengiriman',
                'default'     => '',
                'description' => esc_html__( 'Pilih Kota dengan opsi COD.', 'velocity-toko' ),
                'placeholder' => esc_html__( 'Ketik Nama Kota Anda dan pilih', 'velocity-toko' ),
                'choices'     => getCityProvince(),
                'multiple'    => 5,
            ]
        );
    //Checkout Section
    new \Kirki\Section(
        'section_checkout',
        [
            'title'       => esc_html__( 'Checkout', 'velocity-toko' ),
            'description' => esc_html__( 'Anda dapat mengatur Checkout disini.', 'velocity-toko' ),
            'panel'       => 'velocitytoko_id',
            'priority'    => 160,
        ]
    );
        new \Kirki\Field\Editor(
            [
                'settings'    => 'pesancheckout',
                'label'       => esc_html__( 'Pesan setelah checkout', 'velocity-toko' ),
                'description' => esc_html__( 'Bisa Menggunakan Shortcode [nama-toko] [nama-customer] [email-cust]', 'velocity-toko' ),
                'section'     => 'section_checkout',
                'default'     => 'Hi <strong>[nama-customer]</strong>,<br>
                Terima kasih telah berbelanja di <strong>[nama-toko]</strong>.<br>
                Bersama dengan ini kami juga telah mengirmkan detail pesanan anda ke email <strong>[email-cust]</strong> (Silahkan cek inbox/spam box),<br>
                Silakan ikuti petunjuk di bawah untuk proses pemesanan barang Anda lebih lanjut.',
            ]
        );

    //Kontak Section
    new \Kirki\Section(
        'section_kontak',
        [
            'title'       => esc_html__( 'Kontak', 'velocity-toko' ),
            'description' => esc_html__( 'Anda dapat mengatur Kontak disini.', 'velocity-toko' ),
            'panel'       => 'velocitytoko_id',
            'priority'    => 160,
        ]
    );    
        new \Kirki\Field\Text(
            [
                'settings'      => 'nosms_velocitytoko',
                'label'         => esc_html__( 'No SMS', 'velocity-toko' ),
                'section'       => 'section_kontak',
                'description'   => esc_html__( 'Contoh. 085123456789', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );
        new \Kirki\Field\Text(
            [
                'settings'      => 'notlp_velocitytoko',
                'label'         => esc_html__( 'No Telepon', 'velocity-toko' ),
                'section'       => 'section_kontak',
                'description'   => esc_html__( 'Contoh. 085123456789', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );
        new \Kirki\Field\Text(
            [
                'settings'      => 'nowa_velocitytoko',
                'label'         => esc_html__( 'No Whatsapp', 'velocity-toko' ),
                'section'       => 'section_kontak',
                'description'   => esc_html__( 'Contoh. 085123456789', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );
        new \Kirki\Field\Text(
            [
                'settings'      => 'notelegram_velocitytoko',
                'label'         => esc_html__( 'Username Telegram', 'velocity-toko' ),
                'section'       => 'section_kontak',
                'description'   => esc_html__( '', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );
        new \Kirki\Field\Text(
            [
                'settings'      => 'emailtoko_velocitytoko',
                'label'         => esc_html__( 'Email', 'velocity-toko' ),
                'section'       => 'section_kontak',
                'description'   => esc_html__( '', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );
        new \Kirki\Field\Checkbox_Switch(
            [
                'settings'    => 'veltoko_kontak_floating',
                'label'       => esc_html__( 'Aktifkan Kontak Float', 'velocity-toko' ),
                'description' => esc_html__( 'Info kontak melayang disisi website', 'velocity-toko' ),
                'section'     => 'section_kontak',
                'default'     => 'off',
                'choices'     => [
                    'on'  => esc_html__( 'Enable', 'velocity-toko' ),
                    'off' => esc_html__( 'Disable', 'velocity-toko' ),
                ],
            ]
        );

    //Welcome Popup Section
    new \Kirki\Section(
        'section_welcomepopup',
        [
            'title'       => esc_html__( 'Welcome Popup', 'velocity-toko' ),
            'description' => esc_html__( 'Anda dapat mengatur sambutan disini.', 'velocity-toko' ),
            'panel'       => 'velocitytoko_id',
            'priority'    => 160,
        ]
    );
        new \Kirki\Field\Checkbox_Switch(
            [
                'settings'    => 'popupstatus',
                'label'       => esc_html__( 'Aktifkan Sambutan', 'velocity-toko' ),
                'description' => esc_html__( '', 'velocity-toko' ),
                'section'     => 'section_welcomepopup',
                'default'     => 'off',
                'choices'     => [
                    'on'  => esc_html__( 'Enable', 'velocity-toko' ),
                    'off' => esc_html__( 'Disable', 'velocity-toko' ),
                ],
            ]
        );
        new \Kirki\Field\Editor(
            [
                'settings'    => 'popup',
                'label'       => esc_html__( 'Sambutan Toko', 'velocity-toko' ),
                'description' => esc_html__( 'Sambutan akan ditampilkan saat pertama kali membuka toko.', 'velocity-toko' ),
                'section'     => 'section_welcomepopup',
                'default'     => '<p style="text-align: center;">SELAMAT DATANG DI WEBSITE KAMI</p><p style="text-align: center;">Dapatkan Promo menarik dari Kami</p>',
            ]
        );
    //Dropship Section
    new \Kirki\Section(
        'section_dropship',
        [
            'title'       => esc_html__( 'Dropship', 'velocity-toko' ),
            'description' => esc_html__( 'Anda dapat mengatur dropship disini.', 'velocity-toko' ),
            'panel'       => 'velocitytoko_id',
            'priority'    => 160,
        ]
    );
        new \Kirki\Field\Checkbox_Switch(
            [
                'settings'    => 'dropshipstatus',
                'label'       => esc_html__( 'Aktifkan Dropship', 'velocity-toko' ),
                'description' => esc_html__( 'Fitur dropship akan memberikan opsi kepada member untuk membeli barang dengan data toko member. 
                Semua invoice dan notifikasi akan dikirim dengan nama toko sesuai pengaturan member. Semua invoice akan dikirim dengan nama toko, 
                mohon dipastikan anda mengirimkan barang dengan nama toko sesuai di menu Dashboard Toko > Data Pembelian .', 'velocity-toko' ),
                'section'     => 'section_dropship',
                'default'     => 'off',
                'choices'     => [
                    'on'  => esc_html__( 'Enable', 'velocity-toko' ),
                    'off' => esc_html__( 'Disable', 'velocity-toko' ),
                ],
            ]
        );
    
    //Payment Section
    new \Kirki\Section(
        'section_payment',
        [
            'title'       => esc_html__( 'Payment', 'velocity-toko' ),
            'description' => esc_html__( 'Anda dapat mengatur Payment disini.', 'velocity-toko' ),
            'panel'       => 'velocitytoko_id',
            'priority'    => 160,
        ]
    );
        new \Kirki\Field\Checkbox_Switch(
            [
                'settings'    => 'paypalopt',
                'label'       => esc_html__( 'Paypall', 'velocity-toko' ),
                'description' => esc_html__( '', 'velocity-toko' ),
                'section'     => 'section_payment',
                'default'     => 'off',
                'choices'     => [
                    'on'  => esc_html__( 'Enable', 'velocity-toko' ),
                    'off' => esc_html__( 'Disable', 'velocity-toko' ),
                ],
            ]
        );
        new \Kirki\Field\Radio_Buttonset(
            [
                'settings'    => 'paypaltype',
                'label'       => esc_html__( 'Paypall Mode', 'velocity-toko' ),
                'description' => esc_html__( 'Jika diaktifkan mode Sandbox tidak ada transaksi asli, mode Sandbox hanya untuk ujicoba. Aktifkan mode Production untuk transaksi asli.', 'velocity-toko' ),
                'section'     => 'section_payment',
                'default'     => 'sandbox',
                'choices'     => [
                    'sandbox'       => esc_html__( 'Sandbox', 'velocity-toko' ),
                    'production'    => esc_html__( 'Production', 'velocity-toko' ),
                ],
            ]
        );
        new \Kirki\Field\Text(
            [
                'settings'      => 'paypal',
                'label'         => esc_html__( 'Paypall App Client ID', 'velocity-toko' ),
                'section'       => 'section_payment',
                'description'   => esc_html__( 'Contoh. AdtNsuxHt4ZuLco79-vkW6JmtH_E21C0R-oSqNVzO-4VSex85ZkJOlqEcjHaE9vBR9PXNwYxWtGUiurT<br>Buat PayPal app: https://developer.paypal.com/developer/applications/create', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );

    //Bank Section
    new \Kirki\Section(
        'section_bank',
        [
            'title'       => esc_html__( 'Bank', 'velocity-toko' ),
            'description' => esc_html__( 'Anda dapat mengatur data bank disini.', 'velocity-toko' ),
            'panel'       => 'velocitytoko_id',
            'priority'    => 160,
        ]
    );
        new \Kirki\Field\Repeater(
            [
                'settings'      => 'databank_velocitytoko',
                'label'         => esc_html__( 'Data Bank', 'velocity-toko' ),
                'section'       => 'section_bank',
                'priority'      => 10,
                'default'       => '',
                'button_label'  => esc_html__( 'Tambah Bank', 'velocity-toko' ),
                'row_label'     => [
                        'type'  => 'field',
                        'value' => esc_html__( 'Bank', 'velocity-toko' ),
                        'field' => 'kodebank',
                ],
                'fields'        => [                
                    'namabank'    => [
                        'type'        => 'select',
                        'label'       => esc_html__( 'Bank', 'velocity-toko' ),
                        'choices'     => [
                            0               => esc_html__( 'Pilih Bank', 'velocity-toko' ),
                            'bca'           => esc_html__( 'BCA', 'velocity-toko' ),
                            'mandiri'       => esc_html__( 'Mandiri', 'velocity-toko' ),
                            'bni'           => esc_html__( 'BNI', 'velocity-toko' ),
                            'bri'           => esc_html__( 'BRI', 'velocity-toko' ),
                            'permata'       => esc_html__( 'Permata', 'velocity-toko' ),
                            'cimb_niaga'    => esc_html__( 'CIMB Niaga', 'velocity-toko' ),
                            'Mega'          => esc_html__( 'Bank Mega', 'velocity-toko' ),
                            'muamalat'      => esc_html__( 'Muamalat', 'velocity-toko' ),
                            'danamon'       => esc_html__( 'Danamon', 'velocity-toko' ),
                        ],
                    ],               
                    'nobank'    => [
                        'type'        => 'text',
                        'label'       => esc_html__( 'Nomor Rekening', 'velocity-toko' ),
                    ],             
                    'atasnama'    => [
                        'type'        => 'text',
                        'label'       => esc_html__( 'Atas Nama', 'velocity-toko' ),
                    ],
                ]
            ]
        );        
        new \Kirki\Field\Repeater(
            [
                'settings'      => 'databanklain_velocitytoko',
                'label'         => esc_html__( 'Data Bank Lain', 'velocity-toko' ),
                'section'       => 'section_bank',
                'priority'      => 10,
                'default'       => '',
                'button_label'  => esc_html__( 'Tambah Bank', 'velocity-toko' ),
                'row_label'     => [
                        'type'  => 'field',
                        'value' => esc_html__( 'Bank', 'velocity-toko' ),
                        'field' => 'namabank',
                ],
                'fields'        => [              
                    'namabank'  => [
                        'type'        => 'text',
                        'label'       => esc_html__( 'Nama Bank', 'velocity-toko' ),
                    ],               
                    'nobank'    => [
                        'type'        => 'text',
                        'label'       => esc_html__( 'Nomor Rekening', 'velocity-toko' ),
                    ],             
                    'atasnama'    => [
                        'type'        => 'text',
                        'label'       => esc_html__( 'Atas Nama', 'velocity-toko' ),
                    ],            
                    'logo'    => [
                        'type'        => 'image',
                        'label'       => esc_html__( 'Logo Bank', 'velocity-toko' ),
                    ],
                ]
            ]
        );
        
    //Antispam Section
    new \Kirki\Section(
        'section_antispam',
        [
            'title'       => esc_html__( 'Anti Spam', 'velocity-toko' ),
            'description' => esc_html__( 'Anda dapat mengatur data Anti Spam disini.', 'velocity-toko' ),
            'panel'       => 'velocitytoko_id',
            'priority'    => 160,
        ]
    );    
        new \Kirki\Field\Text(
            [
                'settings'      => 'sitekey_recaptcha_velocitytoko',
                'label'         => esc_html__( 'Sitekey reCAPTCHA', 'velocity-toko' ),
                'section'       => 'section_antispam',
                'description'   => esc_html__( 'Dapatkan Site Key di https://www.google.com/recaptcha/', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );
        new \Kirki\Field\Text(
            [
                'settings'      => 'secret_recaptcha_velocitytoko',
                'label'         => esc_html__( 'Secret reCAPTCHA', 'velocity-toko' ),
                'section'       => 'section_antispam',
                'description'   => esc_html__( 'Dapatkan Secret Key di https://www.google.com/recaptcha/', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );
 
    //WA & SMS Section
    new \Kirki\Section(
        'section_wasms',
        [
            'title'       => esc_html__( 'WA & SMS', 'velocity-toko' ),
            'description' => esc_html__( 'Anda dapat mengatur data relay WA & SMS disini.', 'velocity-toko' ),
            'panel'       => 'velocitytoko_id',
            'priority'    => 160,
        ]
    ); 
        new \Kirki\Field\Text(
            [
                'settings'      => 'userkey',
                'label'         => esc_html__( 'SMS Userkey', 'velocity-toko' ),
                'section'       => 'section_wasms',
                'description'   => esc_html__( 'Dapatkan Userkey Key di http://www.zenziva.id/', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );
        new \Kirki\Field\Text(
            [
                'settings'      => 'passkey',
                'label'         => esc_html__( 'SMS Passkey', 'velocity-toko' ),
                'section'       => 'section_wasms',
                'description'   => esc_html__( 'Dapatkan Passkey Key di http://www.zenziva.id/', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );
        new \Kirki\Field\Text(
            [
                'settings'      => 'endpointwa',
                'label'         => esc_html__( 'Whatsapp End Poin API', 'velocity-toko' ),
                'section'       => 'section_wasms',
                'description'   => esc_html__( 'Masukkan End Point API whatsapp dari velocity developer.', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );
        new \Kirki\Field\Checkbox_Switch(
            [
                'settings'    => 'smspembeli',
                'label'       => esc_html__( 'Kirim SMS & WA ke Pembeli', 'velocity-toko' ),
                'description' => esc_html__( '', 'velocity-toko' ),
                'section'     => 'section_wasms',
                'default'     => 'off',
                'choices'     => [
                    'on'  => esc_html__( 'Enable', 'velocity-toko' ),
                    'off' => esc_html__( 'Disable', 'velocity-toko' ),
                ],
            ]
        );
        new \Kirki\Field\Checkbox_Switch(
            [
                'settings'    => 'smspenjual',
                'label'       => esc_html__( 'Kirim SMS & WA ke Penjual', 'velocity-toko' ),
                'description' => esc_html__( '', 'velocity-toko' ),
                'section'     => 'section_wasms',
                'default'     => 'off',
                'choices'     => [
                    'on'  => esc_html__( 'Enable', 'velocity-toko' ),
                    'off' => esc_html__( 'Disable', 'velocity-toko' ),
                ],
            ]
        );

    //Email Template Section
    new \Kirki\Section(
        'section_emailtemplate',
        [
            'title'       => esc_html__( 'Email Template', 'velocity-toko' ),
            'description' => esc_html__( 'Anda dapat mengatur Email Template disini.', 'velocity-toko' ),
            'panel'       => 'velocitytoko_id',
            'priority'    => 160,
        ]
    );
        new \Kirki\Field\Text(
            [
                'settings'      => 'emailadmin',
                'label'         => esc_html__( 'Email Admin', 'velocity-toko' ),
                'section'       => 'section_emailtemplate',
                'description'   => esc_html__( 'Email Admin, untuk menerima email pemesanan. Jika dikosongkan secara default menggunakan email admin website.', 'velocity-toko' ),
                'default'       => '',
                'priority'      => 10,
            ]
        );        
        new \Kirki\Field\Editor(
            [
                'settings'    => 'adminemail',
                'label'       => esc_html__( 'Email Dikirim ke Admin', 'velocity-toko' ),
                'description' => esc_html__( 'Bisa Menggunakan Shortcode [nama-toko] [kode-pesanan] [tanggal-order] [detail-pesanan] [data-pemesan]', 'velocity-toko' ),
                'section'     => 'section_emailtemplate',
                'default'     => '<p class="body">
                <span class="head">Hallo Admin,</span></p>
                Ada pemesanan baru di <strong>[nama-toko]</strong>,<br>
                Silahkan folow up pemesan, sampai transaksi berhasil!.<br>
                Kode pemesanan :<br>
                <strong>[kode-pesanan]</strong><br><br>
                Waktu pemesanan: [tanggal-order]<br><br>
                Berikut Detail Pesanan:<br>
                [detail-pesanan]<br>
                <p><strong>Berikut Detail Pemesan:</strong></p>
                <p class="sd">[data-pemesan]</p>
                <br>
                
                <strong>Hormat kami,</strong><br>
                <strong>[nama-toko]</strong>',
            ]
        );      
        new \Kirki\Field\Editor(
            [
                'settings'    => 'buyeremail',
                'label'       => esc_html__( 'Email Dikirim ke Pembeli', 'velocity-toko' ),
                'description' => esc_html__( 'Bisa Menggunakan Shortcode [nama-pemesan] [nama-toko] [kode-pesanan] [tanggal-order] [detail-pesanan] [total-order] [nomor-rekening] [nama-toko] [alamat-toko]', 'velocity-toko' ),
                'section'     => 'section_emailtemplate',
                'default'     => '<p>Hallo <strong>[nama-pemesan]</strong>,</p>
                Terima kasih telah berbelanja di <strong>[nama-toko]</strong>,<br>
                Semoga Anda menyukai berbagai produk yang telah Anda beli!.<br>
                <br>
                Kode pemesanan Anda :<br>
                <strong>[kode-pesanan]</strong><br>
                Berikut konfirmasi pemesanan untuk pengiriman barang Anda:<br>
                Waktu pemesanan: [tanggal-order]<br>
                [detail-pesanan]<br>
                Silahkan transfer<span style="padding: 8px;">[total-order]</span><br>
                <br>
                [nomor-rekening]<br>
                <p class="fgwarn" style="color: #ff6f6f;"><b style="font-size: 13px;">Penting!</b></p>
                <ul style="list-style: disc; color: #f00;">
                 	<li class="fgwarn">Pengiriman baru dapat diproses jika Anda telah melakukan konfirmasi pembayaran.</li>
                 	<li class="fgwarn">Pastikan selalu memasukan kode pesanan untuk memudahkan proses pemesanan.</li>
                </ul>
                <strong>Hormat kami,</strong><br>
                <strong>[nama-toko]</strong><br>
                [alamat-toko]',
            ]
        );   
        new \Kirki\Field\Editor(
            [
                'settings'    => 'statusemail',
                'label'       => esc_html__( 'Email Perubahan Status', 'velocity-toko' ),
                'description' => esc_html__( 'Bisa Menggunakan Shortcode [link] [nama-toko] [alamat-toko] [kode-pesanan] [status]', 'velocity-toko' ),
                'section'     => 'section_emailtemplate',
                'default'     => '<p>Hallo,</p>
                Terima kasih telah berbelanja di <strong>[nama-toko]</strong>,<br>
                <br>
                Perubahan status pesanan <strong>#[kode-pesanan]</strong> menjadi [status]</p>
                <p>Lihat detai di [link]</p>
                <p><strong>Hormat kami,</strong>
                <br>
                <strong>[nama-toko]</strong>
                <br>
                [alamat-toko]</p>',
            ]
        );