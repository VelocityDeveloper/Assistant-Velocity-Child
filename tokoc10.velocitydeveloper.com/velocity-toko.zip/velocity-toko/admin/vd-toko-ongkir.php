<?php
/**
 * Theme basic setup.
 * * @package velocity-toko
 */
global $wpdb;

$table_name = $wpdb->prefix . "ongkir"; 
$kecamatan  = isset($_POST['kecamatan']) ? $_POST['kecamatan'] : '';
$ongkir     = isset($_POST['ongkir']) ? $_POST['ongkir'] : '';

if($kecamatan && $ongkir) {
    $sudahada = $wpdb->get_results("SELECT * FROM $table_name WHERE kecamatan = $kecamatan");
    if(empty($sudahada[0]->kecamatan)){
        $result_check = $wpdb->insert($table_name, 
            array(
                'kecamatan' => $kecamatan,
                'ongkir'    => $ongkir,
            )
        );
    } else {
        $result_check = $wpdb->update($table_name, 
            array( 'ongkir'     => $ongkir,),
            array( 'kecamatan'  => $kecamatan,)
		);
    }    
}

///ambil data
$details    = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");

?>
    <div class="ongkir-opt container mt-3 pl-0 ">
        <div class="card-header bg-gradient2 text-white">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-graph-up" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M0 0h1v15h15v1H0V0Zm14.817 3.113a.5.5 0 0 1 .07.704l-4.5 5.5a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61 4.15-5.073a.5.5 0 0 1 .704-.07Z"/> </svg>  Manajemen Ongkir 
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="card p-0">  
                    <div class="card-header font-weight-bold">Tambah/Ubah data</div>
                    <form action="" method="post" class="card-body">
                        <div class="form-group">
                            <label for="provinsi">Provinsi</label>
                            <select name="provinsi" required class="form-control form-control-sm mb-2 cariprovinsi">
                                <option value="">Pilih Provinsi</option>
                                <?php foreach(getProvince() as $dataprov): ?>
                                    <option value="<?php echo $dataprov['province_id'];?>"><?php echo $dataprov['province'];?></option>
                                <?php endforeach; ?>
                            </select>    
                        </div> 
                        <div class="form-group form-kota">
                            <label for="kota">Kota</label>
                            <select name="kota" required class="form-control carikota">
                                <option value="">Pilih kota/kab</option>
                            </select>    
                        </div>  
                        <div class="form-group form-kecamatan">
                            <label for="kota">kecamatan</label>                
                            <select name="kecamatan" required class="form-control carikecamatan">
                                <option value="">Pilih kecamatan</option>
                            </select>   
                        </div>
                        <div class="form-group">
                            <label for="kota">Biaya Ongkir</label>   
                            <input required name="ongkir" class="form-control" type="number" data-toggle="tooltip" title="Masukkan Ongkir disini">
                        </div>
                        <div class="form-group">  
                            <button class="tambah btn btn-sm btn-info" type="submit">Simpan <span class="loadingme"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-save" viewBox="0 0 16 16"> <path d="M2 1a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H9.5a1 1 0 0 0-1 1v7.293l2.646-2.647a.5.5 0 0 1 .708.708l-3.5 3.5a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L7.5 9.293V2a2 2 0 0 1 2-2H14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h2.5a.5.5 0 0 1 0 1H2z"/> </svg></span></button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-8 py-3">
                <div class="border mt-1 p-2 p-md-3 rounded"> 
                    <table class="table table-striped">
                        <thead class="thead-light"> 
                            <tr><th colspan="2">Tujuan</th><th>Harga</th><th></th></tr> 
                        </thead>
                        <tbody>                     
                        <?php foreach($details as $detail):?>
                            <?php $datatujuan = $detail->kecamatan?getSingleSubdistrict($detail->kecamatan):'';?>
                            <tr>
                                <td><?php echo $datatujuan[0]?$datatujuan[0]['subdistrict_name']:'';?></td>
                                <td><?php echo $datatujuan[0]?$datatujuan[0]['city']:'';?></td>
                                <td><?php echo $detail->ongkir;?></td>
                                <td>
                                <a href="?page=ongkir&hapus=<?php echo $detail->id;?>" id="<?php echo $detail->id;?>" data-id="<?php echo $detail->id;?>" class="ongkir-hapus btn btn-sm btn-danger" ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16"> <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/> <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/> </svg></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table> 
                </div>
            </div>
        </div>                                

    </div>
    
    <script>
        jQuery(function($){
            $('.cariprovinsi').change(function(){
                $('.form-kota label').append('<small class="loading text-info"> Loading...</small>');
                jQuery.ajax({
                    type    : "POST",
                    url     : ajaxurl,
                    data    : {action:'kota', prov_destination:$(this).val() },
                    success:function(data) {
                        $('.form-kota select').html(data);
                        $('.form-kota label .loading').remove();
                    },
                });
            });
            $('.carikota').change(function(){
                $('.form-kecamatan label').append('<small class="loading text-info"> Loading...</small>');
                jQuery.ajax({
                    type    : "POST",
                    url     : ajaxurl,
                    data    : {action:'kecamatan', city_destination:$(this).val() },
                    success:function(data) {
                        $('.form-kecamatan select').html(data);
                        $('.form-kecamatan label .loading').remove();
                    },
                });
            });
        });
    </script>

