<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
global $wpdb;
$table_order    = $wpdb->prefix . "kupon"; 
$id             = isset($_GET['id']) ? $_GET['id'] : '';
$tindakan       = isset($_GET['tindakan']) ? $_GET['tindakan'] : '';
$detail         = isset($_GET['detail']) ? $_GET['detail'] : '';
$kode           = isset($_POST['kode']) ? $_POST['kode'] : '';
$details        = $wpdb->get_results("SELECT * FROM $table_order ORDER BY id DESC");
if(!empty($id)){
    $curentselect   = $wpdb->get_results("SELECT * FROM $table_order WHERE id = $id");
    $curentselect   = json_decode($curentselect[0]->detail, true);
}

if($tindakan == 'edit'){
    $idform             = 'formkupon-edit';
    $placekode          = 'value="'.$curentselect['kode'].'"';
    $placenama          = 'value="'.$curentselect['nama'].'"';
    $placepotongan      = 'value="'.$curentselect['potongan'].'"';
    $placejenis         = '<option selected value="'.$curentselect['jenis'].'" class="form-control form-control-sm" type="text">'.$curentselect['jenis'].'</option>';
    $placeminorder      = 'value="'.$curentselect['minorder'].'"';
    $placetanggalend    = 'value="'.$curentselect['tanggalend'].'"';
    $placejumlah        = 'value="'.$curentselect['jumlah'].'"';
    $placestatus        = '<option selected value="'.$curentselect['status'].'" class="form-control form-control-sm" type="text">'.$curentselect['status'].'</option>';
    $placesubmit        = 'Update';
    $opacity            = 'style="opacity:0.2;"';
} else {
    $idform = 'formkupon';
    $placekode          = 'placeholder="Kode Kupon"';
    $placenama          = 'placeholder="Nama Kupon"';
    $placepotongan      = 'placeholder="Potongan"';
    $placejenis         = '';
    $placeminorder      = 'placeholder="Minimal Order"';
    $placetanggalend    = 'placeholder="Tanggal kadaluarsa"';
    $placejumlah        = 'placeholder="Jumlah Kupon"';
    $placestatus        = '';
    $placesubmit        = 'Tambah';
    $opacity            = '';
}
		
    echo '<div class="container mt-3 pl-0 ">';
    echo '<div class="card-header bg-gradient2 text-white">';
        echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-graph-up" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M0 0h1v15h15v1H0V0Zm14.817 3.113a.5.5 0 0 1 .07.704l-4.5 5.5a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61 4.15-5.073a.5.5 0 0 1 .704-.07Z"/> </svg>  Manajemen Kupon';
    echo '</div>';
	echo '<table class="table table-striped"><tbody>';
	echo '<thead class="thead-light">';
    echo '<tr><th >Kode Kupon</th><th >Nama</th><th >Potongan</th><th >Jenis</th><th >Minimal</th><th >Kadaluarsa</th><th >Jumlah</th><th >Status</th><th >Tindakan</th></tr>';
    echo '</thead>';
    echo '<form id="'.$idform.'" data-id="'.$id.'" method="post" >';
    echo '<tr>';
        echo '<td>';
            echo '<input required '.$placekode.' name="kode" class="form-control form-control-sm" maxlength="25" type="text">';
        echo '</td>';
        echo '<td>';
            echo '<input required '.$placenama.' name="nama" class="form-control form-control-sm" type="text">';
        echo '</td>';
        echo '<td>';
            echo '<input required '.$placepotongan.' name="potongan" class="form-control form-control-sm" type="number" data-toggle="tooltip" title="Potongan dalam '.vsstemmart_currency_text().' atau %. Untuk potongan jenis ongkir hanya bisa menggunakan potongan '.vsstemmart_currency_text().'">';
        echo '</td>';
        echo '<td>';
            echo '<select required name="jenis" class="form-control form-control-sm">';
                echo $placejenis;
                echo '<option value="percent" class="form-control form-control-sm" type="text">%</option>';
                echo '<option value="rupiah" class="form-control form-control-sm" type="text">'.vsstemmart_currency_text().'</option>';
                echo '<option value="ongkir" class="form-control form-control-sm" type="text">Ongkir</option>';
            echo '</select>';
        echo '</td>';
        echo '<td>';
            echo '<input required '.$placeminorder.' name="minorder" class="form-control form-control-sm" type="number" data-toggle="tooltip" title="Minimal belanja untuk mendapatkan potongan">';
        echo '</td>';
        echo '<td>';
            echo '<input required '.$placetanggalend.' name="tanggalend" class="datepicker form-control form-control-sm" type="text">';
        echo '</td>';
        echo '<td>';
            echo '<input required '.$placejumlah.' name="jumlah" class="form-control form-control-sm" type="number" data-toggle="tooltip" title="Jumlah maksimal penggunaan Kode Kupon.">';
        echo '</td>';
        echo '<td>';
            echo '<select required name="status" class="form-control form-control-sm">';
                echo $placestatus;
                echo '<option value="on" class="form-control form-control-sm" type="text">on</option>';
                echo '<option value="off" class="form-control form-control-sm" type="text">off</option>';
            echo '</select>';
        echo '</td>';
        echo '<td>';
            echo '<button class="tambah btn btn-info" type="submit"><span class="loadingme"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-circle" viewBox="0 0 16 16"> <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/> <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/> </svg> </span> '.$placesubmit.'</button>';
        echo '</td>';
    echo '</tr>';
    echo '</form>';
    foreach($details as $detail){
    $data = json_decode($detail->detail, true);
    echo '<tr '.$opacity.'>';
        echo '<td>';
            echo $data['kode'];
        echo '</td>';
        echo '<td>';
            echo $data['nama'];
        echo '</td>';
        echo '<td>';
            echo $data['potongan'];
        echo '</td>';
        echo '<td>';
            echo $data['jenis'];
        echo '</td>';
        echo '<td>';
            echo $data['minorder'];
        echo '</td>';
        echo '<td>';
            echo $data['tanggalend'];
        echo '</td>';
        echo '<td>';
            echo $data['jumlah'];
        echo '</td>';
        echo '<td>';
            echo $data['status'];
        echo '</td>';
        echo '<td>';
            echo '<a href="?page=kuponmanage&tindakan=edit&id='.$detail->id.'" class="btn btn-secondary text-white mr-1"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16"> <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/> </svg> </a>';
            echo '<a href="#" id="'.$detail->id.'" data-id="'.$detail->id.'" class="formkupon-hapus btn btn-danger" ><span class="loadingme"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16"> <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/> <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/> </svg> </span></a>';
        echo '</td>';
    echo '</tr>';
    }
    echo '</tbody></table>';
