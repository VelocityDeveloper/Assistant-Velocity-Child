jQuery(function($) {    
    $(".tombols").click(function() {
        var id = $(this).attr("id");
          $(".form-"+id).toggle();
          $("#"+id).toggleClass("collapsed");
    });
});