<?php
/**
 * Kumpulan shortcode yang digunakan di theme ini.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
//[resize-thumbnail width="300" height="150" linked="true" class="w-100"]
add_shortcode('resize-thumbnail', 'resize_thumbnail');
function resize_thumbnail($atts) {
    ob_start();
	global $post;
    $atribut = shortcode_atts( array(
        'output'	=> 'image', /// image or url
        'width'    	=> '300', ///width image
        'height'    => '150', ///height image
        'crop'      => 'false',
        'upscale'   	=> 'true',
        'linked'   	=> 'true', ///return link to post	
        'class'   	=> 'w-100', ///return class name to img	
        'attachment' 	=> 'true',
        'post_id' 	=> $post->ID
    ), $atts );

    $post_id		= $atribut['post_id'];
    $output			= $atribut['output'];
    $attach         = $atribut['attachment'];
    $width          = $atribut['width'];
    $height         = $atribut['height'];
    $crop           = $atribut['crop'];
    $upscale        = $atribut['upscale'];
    $linked        	= $atribut['linked'];
    $class        	= $atribut['class']?'class="'.$atribut['class'].'"':'';
	$urlimg			= get_the_post_thumbnail_url($post_id,'full');
	
	if(empty($urlimg) && $attach == 'true'){
          $attachments = get_posts( array(
            'post_type' 		=> 'attachment',
            'posts_per_page' 	=> 1,
            'post_parent' 		=> $post_id,
        	'orderby'          => 'date',
        	'order'            => 'DESC',
          ) );
          if ( $attachments ) {
				$urlimg = wp_get_attachment_url( $attachments[0]->ID, 'full' );
          }
    }

	if($urlimg):
		$urlresize      = aq_resize( $urlimg, $width, $height, $crop, true, $upscale );
		if($output=='image'):
			if($linked=='true'):
				echo '<a href="'.get_the_permalink($post_id).'" title="'.get_the_title($post_id).'">';
			endif;
			echo '<img src="'.$urlresize.'" width="'.$width.'" height="'.$height.'" loading="lazy" '.$class.'>';
			if($linked=='true'):
				echo '</a>';
			endif;
		else:
			echo $urlresize;
		endif;

	else:
		if($linked=='true'):
			echo '<a href="'.get_the_permalink($post_id).'" title="'.get_the_title($post_id).'">';
		endif;
		echo '<svg style="background-color: #ececec;width: 100%;height: auto;" width="'.$width.'" height="'.$height.'"></svg>';
		if($linked=='true'):
			echo '</a>';
		endif;
	endif;

	return ob_get_clean();
}

//[excerpt count="150"]
add_shortcode('excerpt', 'vd_getexcerpt');
function vd_getexcerpt($atts){
    ob_start();
	global $post;
    $atribut = shortcode_atts( array(
        'count'	=> '150', /// count character
    ), $atts );

    $count		= $atribut['count'];
    $excerpt	= get_the_content();
    $excerpt 	= strip_tags($excerpt);
    $excerpt 	= substr($excerpt, 0, $count);
    $excerpt 	= substr($excerpt, 0, strripos($excerpt, " "));
    $excerpt 	= ''.$excerpt.'...';

    echo $excerpt;

	return ob_get_clean();
}

// [vd-breadcrumbs]
add_shortcode('vd-breadcrumbs','vd_breadcrumbs');
function vd_breadcrumbs() {
    ob_start();
    echo justg_breadcrumb();
    return ob_get_clean();
}

//[ratio-thumbnail size="medium" ratio="16:9"]
add_shortcode('ratio-thumbnail', 'ratio_thumbnail');
function ratio_thumbnail($atts) {
    ob_start();
	global $post;

    $atribut = shortcode_atts( array(
        'size'      => 'medium', // thumbnail, medium, large, full
        'ratio'     => '16:9', // 16:9, 8:5, 4:3, 3:2, 1:1
    ), $atts );

    $size       = $atribut['size'];
    $ratio      = $atribut['ratio'];
    $ratio      = $ratio?str_replace(":","-",$ratio):'';
	$urlimg     = get_the_post_thumbnail_url($post->ID,$size);

    echo '<div class="ratio-thumbnail">';
        echo '<a class="ratio-thumbnail-link" href="'.get_the_permalink($post->ID).'" title="'.get_the_title($post->ID).'">';
            echo '<div class="ratio-thumbnail-box ratio-thumbnail-'.$ratio.'" style="background-image: url('.$urlimg.');">';
                echo '<img src="'.$urlimg.'" loading="lazy" class="ratio-thumbnail-image"/>';
            echo '</div>';
        echo '</a>';
    echo '</div>';

	return ob_get_clean();
}


// [cari]
function cariform() {
    $id = rand(9,9999);
    $html = '<div class="vel-cari position-relative d-inline-block">
       <span class="tombols" id="'.$id.'"></span>
       <form action="'.get_home_url().'" method="get" class="form-'.$id.'" id="formsearchvel" style="display: none;">
        <input class="search-input" name="s" placeholder="Search.." type="text" required>
        <button class="search-button" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
       </form>
    </div>';
    return $html;
}
add_shortcode ('cari', 'cariform');




// Menampilkan jumlah pengunjung: [hits]
function hits($atts) {
   global $post;
    $atribut = shortcode_atts( array(
        'post_id'     => $post->ID,
    ), $atts );
    $post_id	    = $atribut['post_id'];
   $view = get_post_meta($post_id,'hit',true);
   if(empty($view)){
	   $jml = '0';
   } else {
	   $jml = $view;
   }
   return $jml;
}
add_shortcode( 'hits', 'hits' );


// [social-share]
function vel_social_buttons($content) {
    global $post,$wp;
    if(is_singular() || is_home()){
        $post_id = $post->ID;
		// Get current URL 
        $sb_url = urlencode(get_permalink($post_id));
		//$sb_url = home_url(add_query_arg(array($_GET), $wp->request));
 
        // Get current web title
        $sb_title = str_replace( ' ', '%20', get_the_title($post_id));
        //$sb_title = wp_title('',false);
         
        // Construct sharing URL without using any script
        $twitterURL = 'https://twitter.com/intent/tweet?text='.$sb_title.'&amp;url='.$sb_url;
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$sb_url;
        $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$sb_url.'&amp;title='.$sb_title;
        $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;description='.$sb_title;
        $whatsappURL ='https://api.whatsapp.com/send?text='.$sb_title.' '.$sb_url;
        $telegramURL ='https://telegram.me/share/url?url='.$sb_url.'';
        $emailURL ='mailto:?subject=I wanted you to see this site&amp;body='.$sb_title.' '.$sb_url.' ';
        
        // Add sharing button at the end of page/page content
        $content .= '<div class="social-box text-white">';
        //$content .= '<div class="btn btn-sm btn-outline-info me-2 mb-1"><span id="datashare" class="font-weight-bold">'.$countshare.'</span> Shares</div>';
        //$content .= '<div class="btn btn-sm btn-outline-secondary me-2 mb-1"><span class="font-weight-bold">'.$countviews.'</span> Views</div>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-twitter postshare-button" href="'.$twitterURL.'" target="_blank" rel="nofollow"><i class="fa fa-twitter text-white" aria-hidden="true"></i></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-facebook postshare-button" href="'.$facebookURL.'" target="_blank" rel="nofollow"><i class="fa fa-facebook-square text-white" aria-hidden="true"></i></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-whatsapp postshare-button" href="'.$whatsappURL.'" target="_blank" rel="nofollow"><i class="fa fa-whatsapp text-white" aria-hidden="true"></i></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-pinterest postshare-button" href="'.$pinterestURL.'" data-pin-custom="true" target="_blank" rel="nofollow"><i class="fa fa-pinterest text-white" aria-hidden="true"></i></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-linkedin postshare-button" href="'.$linkedInURL.'" target="_blank" rel="nofollow"><i class="fa fa-linkedin text-white" aria-hidden="true"></i></a>';
        $content .= '<a class="btn btn-sm btn-info me-2 mb-1 s-telegram postshare-button" href="'.$telegramURL.'" target="_blank" rel="nofollow"><i class="fa fa-telegram text-white" aria-hidden="true"></i></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-email postshare-button" href="'.$emailURL.'" target="_blank" rel="nofollow"><i class="fa fa-envelope-o text-white" aria-hidden="true"></i></a>';
        $content .= '</div>';
        
        return $content;
    } else {
        // if not a post/page then don't include sharing button
        return $content;
    }
};
add_shortcode('social-share','vel_social_buttons');



// Tanggal Umum
function velocity_date() {
	$day = date('N');
	$tgl = date('j');
	$month = date('n');
	$year = date('Y');
	$hari = array(1 => 'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu');			
	$bulan = array(1 => 'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');	
	$html = $hari[$day].', '.$tgl.' '.$bulan[$month].' '.$year;
	return $html;
}
add_shortcode ('velocity-date', 'velocity_date');

// Tanggal Pos
function tglpos($atts) {
	global $post;
	$atribut = shortcode_atts( array(
		'post_id' => $post->ID,
		'hari' => 'yes',
		'waktu' => 'yes',
	), $atts );
	$post_id = $atribut['post_id'];
	$att_hari = $atribut['hari'];
	$att_waktu = $atribut['waktu'];
	$day = get_the_date('N',$post_id);
	$tgl = get_the_date('j',$post_id);
	$month = get_the_date('n',$post_id);
	$year = get_the_date('Y',$post_id);
	$hari = array(1 => 'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu');			
	$bulan = array(1 => 'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');
	  if($att_hari == 'yes'){
		$tampil_hari = $hari[$day].', ';
	  } else {
		$tampil_hari = '';
	  }
	  if($att_waktu == 'yes'){
		$tampil_waktu = ' '.get_the_date('h:i',$post_id).' WIB';
	  } else {
		$tampil_waktu = '';
	  }
  
	$html = $tampil_hari.$tgl.' '.$bulan[$month].' '.$year.$tampil_waktu;
	return $html;
}
add_shortcode ('tanggal-pos', 'tglpos');


// [related-post]
function relatedpost(){
	ob_start();
	$idp = get_the_ID();
	$cats = wp_get_post_terms( get_the_ID(), 'category' ); 
	$cats_ids = array();  
	foreach( $cats as $wpex_related_cat ) {
		$cats_ids[] = $wpex_related_cat->term_id; 
	}
	if ( ! empty( $cats_ids ) ) {
		$args['category__in'] = $cats_ids;
		$args['posts_per_page'] = 3;
		$args['post__not_in'] = array ( $idp );
	}
	$wpex_query = new wp_query( $args );
	if($wpex_query->have_posts ()):
	echo '<div class="velocity-related-posts">';
		while($wpex_query->have_posts()): $wpex_query->the_post(); ?>
		<h4 class="fs-6"><a class="text-dark" href="<?php echo get_the_permalink($post->ID); ?>"><b><?php echo get_the_title($post->ID); ?></b></a></h4>
		<hr>
	<?php endwhile;
	echo '</div>';
	endif;
	wp_reset_postdata();
	return ob_get_clean();
}
add_shortcode('related-posts', 'relatedpost');


function velocity_archive_post() {
ob_start();
$object = get_queried_object();
$args = array(
    'showposts' => 1,
);
if(!empty($object->taxonomy)){
  $args['tax_query'] = array(
      array(
          'taxonomy' => $object->taxonomy,
          'field' => 'slug',
          'terms' => $object->slug,
      ),
  );
}
$posts = get_posts($args); ?>
<div class="frame-luar">
    <?php foreach($posts as $post) { ?>
        	<div class="frame-slide">
        		<div class="image-post">
					<img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?>" />
				</div>
        		<div class="frame-isi">
                      <?php 
                        $post_categories = wp_get_post_categories($post->ID, array( 'fields' => 'all' ) );
                        if( $post_categories ){
                            echo '<span class="velocity-post-categories">';
                            foreach($post_categories as $cat){
                                echo '<a class="py-0 bg-primary btn btn-sm rounded-0 text-white me-2 mb-2 text-uppercase" href="'.get_category_link($cat->term_id).'"><small>'.$cat->name.'</small></a>';
                            }
                            echo '</span>';
                        }
                      ?>
                    <div class="judul mb-3">
                      <a href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post);?></a>
                  	</div>
                  	<small class="text-white"><?php echo do_shortcode('[tanggal-pos post_id="'.$post->ID.'"]');?></small>
                </div>
        	</div>
    <?php } ?>
</div>
<?php 
return ob_get_clean();
}
add_shortcode ('velocity-archive-post', 'velocity_archive_post');