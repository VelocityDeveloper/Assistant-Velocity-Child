
.slide-icon-<?php echo $id; ?> i {
	font-size: 33px;
	cursor: pointer;
	width: auto;
	height: auto;
}
.fl-node-<?php echo $id; ?> .sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
	text-align: left;
	<?php if(!empty($settings->bg_color) && !empty($settings->bg_gradient)){ ?>
		background-image: linear-gradient(to right, #<?php echo $settings->bg_color; ?>, #<?php echo $settings->bg_gradient; ?>);
	<?php } elseif(!empty($settings->bg_color)){ ?>
		background-color: #<?php echo $settings->bg_color; ?>;
	<?php } elseif(!empty($settings->bg_gradient)){ ?>
		background-color: #<?php echo $settings->bg_gradient; ?>;
	<?php } else { ?>
    	background-color: #000;
	<?php } ?>
}
.fl-node-<?php echo $id; ?> .sidenav .closebtn {
    position: absolute;
    color: #fff;
    top: 32px;
    right: 11px;
    font-size: 30px;
    margin-left: 50px;
    text-decoration: none !important;
}
.fl-node-<?php echo $id; ?> .sidenav .closebtn:hover {opacity: 0.8;}
.v-menu-<?php echo $id; ?> {
    padding: 0;
    margin: 0;
}
.v-menu-<?php echo $id; ?> li {position: relative;}
.v-menu-<?php echo $id; ?> li a {
    color: #fff;
    padding: 10px 15px;
    display: block;
    position: relative;
}
.v-menu-<?php echo $id; ?> li a:hover {color: rgba(255,255,255,0.5);}
.v-menu-<?php echo $id; ?> li.menu-item-has-children > a {padding: 10px 35px 10px 15px;}
.v-menu-<?php echo $id; ?> li.menu-item-has-children i {
    color: #fff;
    position: absolute;
    right: 0;
    top: 0;
    cursor: pointer;
    text-align: center;
    padding: 5px 8px;
    font-size: 30px;
}
.v-menu-<?php echo $id; ?> li ul {padding-left: 20px;display:none}
.v-menu-<?php echo $id; ?> li {display:block}


<?php

foreach ( $settings->icons as $i => $icon ) :
	$index = $i + 1;
	?>
	<?php if ( isset( $icon->color ) && ! empty( $icon->color ) ) : ?>
	.fl-node-<?php echo $id; ?> .fl-module-content .fl-icon:nth-child(<?php echo $index; ?>) i,
	.fl-node-<?php echo $id; ?> .fl-module-content .fl-icon:nth-child(<?php echo $index; ?>) i:before {
		color: <?php echo FLBuilderColor::hex_or_rgb( $icon->color ); ?>;
	}
	<?php endif; ?>
	.fl-node-<?php echo $id; ?> .fl-module-content .fl-icon:nth-child(<?php echo $index; ?>) i {
		background: #dddddd;
		border-radius: 100%;
		-moz-border-radius: 100%;
		-webkit-border-radius: 100%;
		text-align: center;
	}
	.fl-node-<?php echo $id; ?> .fl-module-content .fl-icon:nth-child(<?php echo $index; ?>) i:hover,
	.fl-node-<?php echo $id; ?> .fl-module-content .fl-icon:nth-child(<?php echo $index; ?>) i:hover:before,
	.fl-node-<?php echo $id; ?> .fl-module-content .fl-icon:nth-child(<?php echo $index; ?>) a:hover i,
	.fl-node-<?php echo $id; ?> .fl-module-content .fl-icon:nth-child(<?php echo $index; ?>) a:hover i:before {
		color: #111111;
	}

	<?php if ( $icon->duo_color1 && false !== strpos( $icon->icon, 'fad fa' ) ) : ?>
	.fl-node-<?php echo $id; ?> .fl-module-content .fl-icon:nth-child(<?php echo $index; ?>) i:before {
		color: <?php echo FLBuilderColor::hex_or_rgb( $icon->duo_color1 ); ?>;
	}
	<?php endif; ?>

	<?php if ( $icon->duo_color2 && false !== strpos( $icon->icon, 'fad fa' ) ) : ?>
	.fl-node-<?php echo $id; ?> .fl-module-content .fl-icon:nth-child(<?php echo $index; ?>) i:after {
		color: <?php echo FLBuilderColor::hex_or_rgb( $icon->duo_color2 ); ?>;
		opacity: 1;
	}
	<?php endif; ?>

<?php endforeach; ?>

.fl-node-<?php echo $id; ?> .fl-module-content .fl-icon-group .fl-icon {
	display: inline-block;
	margin: 3px;
}

.fl-node-<?php echo $id; ?> .fl-icon i {
	line-height: 28px;
	width: 30px;
}
.fl-node-<?php echo $id; ?> .fl-icon i::before {
	font-size: 18px;
}
.fl-node-<?php echo $id; ?> .velocity-menu-modul {
	text-align: <?php echo $settings->align; ?>;
}

