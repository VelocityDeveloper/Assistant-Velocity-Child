<div class="velocity-menu-modul">

<span class="d-md-none slide-icon-<?php echo $id; ?>" onclick="openNav()"><i class="dashicons dashicons-menu"></i></span>

<div class="d-none d-md-block fl-icon-group">
<?php foreach ( $settings->icons as $icon ) {

	if ( ! is_object( $icon ) ) {
		continue;
	}

	$duo = false;
	if ( false !== strpos( $icon->icon, 'fad fa' ) ) {
		$duo = true;
	}

	$icon_settings = array(
		'bg_color'        => '#eeeeee',
		'bg_hover_color'  => '#dddddd',
		'color'           => ! $icon->color ? $icon->color : '#111111',
		'exclude_wrapper' => true,
		'icon'            => $icon->icon,
		'link'            => $icon->link,
		'link_target'     => isset( $icon->link_target ) ? $icon->link_target : '_blank',
		'link_nofollow'   => isset( $icon->link_nofollow ) ? $icon->link_nofollow : 'nofollow',
		'size'            => '14px',
		'text'            => false,
	);

	FLBuilder::render_module_html( 'icon', $icon_settings );
}

?>
</div>
</div>

<div id="mySidenav-<?php echo $id; ?>" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <?php 
  $defaults = array(
      'menu'			=> $settings->menu,
      'container'		=> false,
      'menu_class'	=> 'v-menu-'.$id,
  );
  wp_nav_menu( $defaults );
  
  echo '<div class="fl-icon-group p-3">';
  foreach ( $settings->icons as $icon ) {

      if ( ! is_object( $icon ) ) {
          continue;
      }

      $duo = false;
      if ( false !== strpos( $icon->icon, 'fad fa' ) ) {
          $duo = true;
      }

      $icon_settings = array(
          'bg_color'        => '#eeeeee',
          'bg_hover_color'  => '#dddddd',
          'color'           => ! $icon->color ? $icon->color : '#111111',
          'exclude_wrapper' => true,
          'icon'            => $icon->icon,
          'link'            => $icon->link,
          'link_target'     => isset( $icon->link_target ) ? $icon->link_target : '_blank',
          'link_nofollow'   => isset( $icon->link_nofollow ) ? $icon->link_nofollow : 'nofollow',
          'size'            => '14px',
          'text'            => false,
      );

      FLBuilder::render_module_html( 'icon', $icon_settings );
  }
  echo '</div>';
  ?>
</div>