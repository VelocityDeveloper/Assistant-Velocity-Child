function openNav() {
    document.getElementById("mySidenav-<?php echo $id; ?>").style.width = "320px";
}

function closeNav() {
    document.getElementById("mySidenav-<?php echo $id; ?>").style.width = "0";
}

jQuery(document).ready(function() {
    jQuery(".v-menu-<?php echo $id;?>").find("li.menu-item-has-children").append('<i class="fa fa-chevron-right" aria-hidden="true"></i>');
    jQuery(".v-menu-<?php echo $id;?> li.menu-item-has-children i").on("click", function() {
        jQuery(this).hasClass("fa-chevron-down") ? jQuery(this).removeClass("fa-chevron-down").parent("li.menu-item-has-children").find("> ul").slideToggle() : jQuery(this).addClass("fa-chevron-down").parent("li.menu-item-has-children").find("> ul").slideToggle()
    })
});
