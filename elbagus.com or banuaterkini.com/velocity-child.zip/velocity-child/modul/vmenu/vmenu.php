<?php

/**
 * @class FLvMenu
 */
class FLvMenu extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __('Velocity Menu', 'fl-builder'),
			'description'   	=> __('Velocity Menu', 'fl-builder'),
			'category'      	=> __('Actions', 'fl-builder'),
			'editor_export' 	=> false,
			'partial_refresh'	=> true
		));
	}
	

	public static function _get_menus() {
		$get_menus = get_terms( 'nav_menu', array(
			'hide_empty' => true,
		) );
		$fields = array(
			'type'          => 'select',
			'label'         => __( 'Select Menu', 'fl-builder' ),
			'helper'		=> __( 'Select a WordPress menu that you created in the admin under Appearance > Menus.', 'fl-builder' ),
		);

		if ( $get_menus ) {

			foreach ( $get_menus as $key => $menu ) {

				if ( 0 == $key ) {
					$fields['default'] = $menu->name;
				}

				$menus[ $menu->slug ] = $menu->name;
			}

			$fields['options'] = $menus;

		} else {
			$fields['options'] = array(
				'' => __( 'No Menus Found', 'fl-builder' ),
			);
		}

		return $fields;

	}
	public static function _left_menus() {
		$get_menus = get_terms( 'nav_menu', array(
			'hide_empty' => true,
		) );
		$fields = array(
			'type'          => 'select',
			'label'         => __( 'Left Menu', 'fl-builder' ),
			'helper'		=> __( 'Select a WordPress menu that you created in the admin under Appearance > Menus.', 'fl-builder' ),
		);

		if ( $get_menus ) {

			foreach ( $get_menus as $key => $menu ) {

				if ( 0 == $key ) {
					$fields['default'] = $menu->name;
				}

				$menus[ $menu->slug ] = $menu->name;
			}

			$fields['options'] = $menus;

		} else {
			$fields['options'] = array(
				'' => __( 'No Menus Found', 'fl-builder' ),
			);
		}

		return $fields;

	}
	
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvMenu', array(
	'slider'      => array(
		'title'         => __('General', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => 'Basic',
				'fields'        => array(
					'align'     => array(
						'type'    => 'select',
						'label'   => __( 'Align', 'fl-builder' ),
						'default' => 'left',
						'options' => array(
							'left' => 'Left',
							'center' => 'Center',
							'right' => 'Right',
						),
					),
					'menu' => FLvMenu::_get_menus(),
					'bg_color'          => array(
						'type'        => 'color',
						'connections' => array( 'color' ),
						'label'       => __( 'Background Color', 'fl-builder' ),
						'default'     => '',
						'show_reset'  => true,
						'show_alpha'  => true,
						'preview'     => array(
							'type' => 'none',
						),
					),
					'bg_gradient'          => array(
						'type'        => 'color',
						'connections' => array( 'color' ),
						'label'       => __( 'Background Gradient Color', 'fl-builder' ),
						'default'     => '',
						'show_reset'  => true,
						'show_alpha'  => true,
						'preview'     => array(
							'type' => 'none',
						),
					),
				)
			),
			'general2'       => array(
				'title'         => 'Icon',
				'fields'        => array(
					'icons' => array(
						'type'         => 'form',
						'label'        => __( 'Icon', 'fl-builder' ),
						'form'         => 'vd_icon_group_form', // ID from registered form below
						'preview_text' => 'icon', // Name of a field to use for the preview text
						'multiple'     => true,
					),
				)
			),

		)
	),
));




FLBuilder::register_settings_form('vd_icon_group_form', array(
	'title' => __( 'Add Icon', 'fl-builder' ),
	'tabs'  => array(
		'general' => array( // Tab
			'title'    => __( 'General', 'fl-builder' ), // Tab title
			'sections' => array( // Tab Sections
				'general' => array( // Section
					'title'  => '', // Section Title
					'fields' => array( // Section Fields
						'icon'    => array(
							'type'  => 'icon',
							'label' => __( 'Icon', 'fl-builder' ),
						),
						'link'    => array(
							'type'          => 'link',
							'label'         => __( 'Link', 'fl-builder' ),
							'show_target'   => true,
							'show_nofollow' => true,
						),
						'color'          => array(
							'type'        => 'color',
							'connections' => array( 'color' ),
							'label'       => __( 'Color', 'fl-builder' ),
							'show_reset'  => true,
							'show_alpha'  => true,
						),
					),
				),
			),
		),
	),
));

