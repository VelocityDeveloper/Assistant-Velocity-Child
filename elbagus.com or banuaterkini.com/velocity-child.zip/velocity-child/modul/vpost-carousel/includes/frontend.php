<?php 
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="vpost-carousel">
<div class="slider-bottom-<?php echo $id; ?>">
  <?php foreach($posts as $post) { ?>
    <div class="post-list-module m-2">
      <div class="p-1 pb-2">
      	<?php echo do_shortcode('[resize-thumbnail width="300" height="200" linked="true" class="w-100" post_id="'.$post->ID.'"]');?>
        <?php $post_categories = wp_get_post_categories($post->ID, array( 'fields' => 'all' ) );
        if( $post_categories ){
            echo '<div class="velocity-post-categories mt-2">';
            foreach($post_categories as $cat){
                echo '<a class="me-2 mb-2 text-uppercase" href="'.get_category_link($cat->term_id).'"><small>'.$cat->name.'</small></a>';
            }
            echo '</div>';
         }
        ?>
        <div class="second-post-title my-2">
          <a href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post);?></a>
        </div>
        <small class="text-white tanggal"><?php echo do_shortcode('[tanggal-pos post_id="'.$post->ID.'"]');?></small>
      </div>
    </div>
  <?php } ?>
</div>
</div>
