<?php
class postslidehome extends FLBuilderModule {
    public function __construct() {
        parent::__construct(array(
            'name'          => __('Post Slide Home', 'fl-builder'),
            'description'   => __('Modul Post Slide Home', 'fl-builder'),
            'category'		=> __('Posts', 'fl-builder'),
            'editor_export' => true, // Defaults to true and can be omitted.
            'enabled'       => true, // Defaults to true and can be omitted.
        ));
    }
}

FLBuilder::register_module('postslidehome', array(
    'general'       => array( // Tab
        'title'         => __('Dasar', 'fl-builder'), // Tab title
        'sections'      => array( // Tab Sections
            'general'       => array( // Section
                'title'         => __('Velocity option', 'fl-builder'), // Section Title
                'fields'        => array( // Section Fields
					'posts_per_page' => array(
						'type'          => 'text',
						'label'         => __( 'Posts Slider Total', 'fl-builder' ),
						'default'       => '10',
						'size'          => '4',
					),
                )
            )
        )
    ),
	'content'   => array(
		'title'         => __( 'Content', 'fl-builder' ),
		'file'          => FL_BUILDER_DIR . 'includes/loop-settings.php',
	),
 
));