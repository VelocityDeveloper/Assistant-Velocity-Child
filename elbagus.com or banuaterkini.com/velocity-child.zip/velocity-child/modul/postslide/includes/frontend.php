<?php 
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;
 ?>
<div class="frame-luar">
    <div class="slider-panah"></div>
    <div class="slider-frame-img">
        <?php foreach($posts as $post) { ?>
        	<div class="frame-slide">
        		<div class="image-post">
					<img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?>" />
				</div>
        		<div class="frame-isi">
                      <?php 
                        $post_categories = wp_get_post_categories($post->ID, array( 'fields' => 'all' ) );
                        if( $post_categories ){
                            echo '<span class="velocity-post-categories">';
                            foreach($post_categories as $cat){
                                echo '<a class="py-0 bg-primary btn btn-sm rounded-0 text-white me-2 mb-2 text-uppercase" href="'.get_category_link($cat->term_id).'"><small>'.$cat->name.'</small></a>';
                            }
                            echo '</span>';
                        }
                      ?>
                    <div class="judul mb-3">
                      <a href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post);?></a>
                  	</div>
                  	<small class="text-white"><?php echo do_shortcode('[tanggal-pos post_id="'.$post->ID.'"]');?></small>
                </div>
        	</div>
        <?php } ?>
    </div>
</div>
<div class="frame-kecil">
<div class="slider-frame-navi">
    <?php foreach($posts as $post) { ?>
  		<div class="velocity-nav-img position-relative">
        	<img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?>" />
            <div class="mt-2 fw-bold text-dark"><?php echo get_the_title($post->ID);?></div>
		</div>
    <?php } ?>
</div>
</div>