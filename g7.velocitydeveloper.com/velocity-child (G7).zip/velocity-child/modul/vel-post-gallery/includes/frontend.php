<?php global $post;
$post_id = $post->ID;
$images = rwmb_meta( 'gallery', array( 'size' => 'full' ) );
	if($images){
        echo '<div id="parent-container-'.$id.'">';
        echo '<div id="carousel-'.$id.$post_id.'" class="carousel slide" data-bs-ride="carousel">';
            echo '<div class="carousel-inner">';
                $i = 0;
                foreach ( $images as $image ) {
                    $no = ++$i;
                    if($no == '1'){
                        $class = 'active';
                    } else {
                         $class = '';
                    }
                    $urlbesar = $image['full_url'];
                    echo '<div class="carousel-item '.$class.' text-center">';
                    echo '<a href="'.$urlbesar.'">';
                    echo '<img class="d-inline-block" src="'.$urlbesar.'">';
                    echo '</a></div>';
                }
            echo '</div>';
            echo '<button class="carousel-control-prev" type="button" data-bs-target="#carousel-'.$id.$post_id.'" data-bs-slide="prev">';
                echo '<span class="carousel-control-prev-icon" aria-hidden="true"></span>';
                echo '<span class="visually-hidden">Previous</span>';
            echo '</button>';
            echo '<button class="carousel-control-next" type="button" data-bs-target="#carousel-'.$id.$post_id.'" data-bs-slide="next">';
                echo '<span class="carousel-control-next-icon" aria-hidden="true"></span>';
                echo '<span class="visually-hidden">Next</span>';
            echo '</button>';
        echo '</div>';
        echo '</div>';
    } else if(has_post_thumbnail($post->ID)){
        $thumb_url = get_the_post_thumbnail_url($post->ID,'full');
        echo '<div class="text-center" id="parent-container-'.$id.'">';
            echo '<a href="'.$thumb_url.'"><img class="d-inline-block" src="'.$thumb_url.'"></a>';
        echo '</div>';
    }
	
?>