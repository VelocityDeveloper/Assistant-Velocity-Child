jQuery(function($) {
    function scrollcontent() {
        let ww = $(window).width();
      let hw = $( window ).height();
      let hf = $( '#page > footer' ).height();
      let hh = $( '#page > header' ).height();
      let ab = $( '#wpadminbar' ).length?$( '#wpadminbar' ).height():0;
      let hc 	= hw-(hf+hh+ab);
      let hic = hc-40;
      
        $( '#wrapper-content > .fl-builder-content > .fl-row-bg-embed .fl-row-content-wrap' ).css("min-height", hc+'px');
        
        //if (ww < 400){
            let hct = $( '#wrapper-content' ).height();
            hc = hct;
        //} 
        
      $( '#carouselbgcarousel .ratio-thumbnail-box' ).css("padding-bottom", hc+'px');
      $('.f1-content').slimScroll({
        height: hic+'px',
        color: '#dddddd',
      });
    }
    scrollcontent();
    $( window ).resize(function() {
      scrollcontent();
    });
  });