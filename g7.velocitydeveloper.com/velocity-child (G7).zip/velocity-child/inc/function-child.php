<?php
/**
 * Fuction yang digunakan di theme ini.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

add_action( 'after_setup_theme', 'velocitychild_theme_setup', 9 );

function velocitychild_theme_setup() {
	
	
	if (class_exists('Kirki')):
		
		/**
		* Customizer control in child themes
		* Sample Panel
		* 
		*/ 
		Kirki::add_panel('panel_slider', [
			'priority'    => 10,
			'title'       => esc_html__('Slider', 'justg'),
			'description' => esc_html__('', 'justg'),
		]);

		/**
		* Sample section
		* 
		*/ 
		Kirki::add_section('vd_slider', [
			'panel'    => 'panel_slider',
			'title'    => __('Slider', 'justg'),
			'priority' => 10,
		]);
		Kirki::add_section('vd_nomor_telepon', [
			'panel'    => 'floating_panel',
			'title'    => __('Phone', 'justg'),
			'priority' => 10,
		]);

		/**
		* Sample Field
		* 
		*/ 
		Kirki::add_field( 'justg_config', [
			'type'        => 'repeater',
			'label'       => esc_html__( 'Background Slider', 'justg' ),
			'section'     => 'vd_slider',
			'priority'    => 10,
			'row_label' => [
				'type'  => 'text',
				'value' => esc_html__( 'Slide', 'justg' ),
			],
			'button_label' => esc_html__('Tambah Slide', 'justg' ),
			'settings'     => 'velocity_slider',
			'fields' => [
				'image' => [
					'type'        => 'image',
					'label'       => esc_html__( 'Gambar', 'justg' ),
					'description' => esc_html__( '', 'justg' ),
					'default'     => '',
				],
			]
		] );
		Kirki::add_field( 'justg_config', [
			'type'        => 'text',
			'label'       => esc_html__( 'Phone Number', 'justg' ),
			'description' => esc_html__( 'Enter your phone number', 'justg' ),
			'section'     => 'vd_nomor_telepon',
			'priority'    => 10,
			'settings'     => 'velocity_phone',
		] );
		
	endif;
}



add_filter( 'rwmb_meta_boxes', 'vel_metabox' );
function vel_metabox( $meta_boxes ){
	$textdomain = 'justg';
	$meta_boxes[] = array(
		'id'         => 'standard',
		'title'      => __( 'Velocity Fields', $textdomain ),
		'post_types' => array( 'post' ),
		'context'    => 'normal',
		'priority'   => 'high',
		'autosave'   => true,
		'fields'     => array(
			array(
				'name'             => __( 'Foto Tambahan', $textdomain ),
				'id'               => "gallery",
				'type'             => 'image_advanced',
			),
		)
	);

	return $meta_boxes;
}


function velocity_footer_script() {
	$phone_number        = velocitytheme_option('velocity_phone', '');
    if (!empty($phone_number)){
        $phone = preg_replace('/[^0-9]/',' ', $phone_number); 
        echo '<div class="phone-float">';
			echo '<a target="_blank" href="tel:'.$phone.'">';
				echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone" viewBox="0 0 16 16">
				<path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122l-2.19.547a1.745 1.745 0 0 1-1.657-.459L5.482 8.062a1.745 1.745 0 0 1-.46-1.657l.548-2.19a.678.678 0 0 0-.122-.58L3.654 1.328zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/>
			  </svg>';
			echo '</a>';
        echo '</div>';
    }
}
add_action( 'wp_footer', 'velocity_footer_script' );