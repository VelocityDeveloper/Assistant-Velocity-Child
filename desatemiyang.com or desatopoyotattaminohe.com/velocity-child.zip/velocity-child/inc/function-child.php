<?php
/**
 * Fuction yang digunakan di theme ini.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

function vsstem_modul() {
	if ( class_exists( 'FLBuilder' ) ) {
	    get_template_part('modul/vel-gallery/vel-gallery');
	    get_template_part('modul/velocity-progress/velocity-progress');
	    get_template_part('modul/gallery-carousel/gallery-carousel');
	    get_template_part('modul/velocity-chart/velocity-chart');
	}
}
add_action( 'init', 'vsstem_modul' );

// Tanggal Umum
function velocity_date() {
ob_start();
	$day = wp_date('N');
	$tgl = wp_date('j');
	$month = wp_date('n');
	$year = wp_date('Y');
	$hari = array ( 1 =>    'Senin',
				'Selasa',
				'Rabu',
				'Kamis',
				'Jumat',
				'Sabtu',
				'Minggu'
			);
			
	$bulan = array (1 =>   'Januari',
				'Februari',
				'Maret',
				'April',
				'Mei',
				'Juni',
				'Juli',
				'Agustus',
				'September',
				'Oktober',
				'November',
				'Desember'
			);
	
	echo $hari[$day].', '.$tgl.' '.$bulan[$month].' '.$year;
return ob_get_clean();
}
add_shortcode ('velocity-date', 'velocity_date');


function velocity_login_logo() {
$custom_logo_id = get_theme_mod('custom_logo');
if(!empty($custom_logo_id)){ ?>
    <style type="text/css">
        #login h1 a, .login h1 a {
            background-image: url(<?php echo esc_url( wp_get_attachment_url($custom_logo_id)); ?>);
            height: 65px;
            width: 320px;
            background-size: contain;
            background-repeat: no-repeat;
            padding-bottom: 30px;
        }
    </style>
<?php }
}
add_action( 'login_enqueue_scripts', 'velocity_login_logo' );
