<?php
/**
 * The template for displaying search forms
 *
 * @package justg
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>

<form method="get" class="velocity-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input class="velocity-control rounded-0" id="s" name="s" type="text"
			placeholder="<?php esc_attr_e( 'Cari artikel', 'justg' ); ?>" value="<?php the_search_query(); ?>" required>
        <button type="submit" class="velocity-button btn btn-lg bg-transaprent">
          <i class="fa fa-search" aria-hidden="true"></i>
        </button>
</form>
