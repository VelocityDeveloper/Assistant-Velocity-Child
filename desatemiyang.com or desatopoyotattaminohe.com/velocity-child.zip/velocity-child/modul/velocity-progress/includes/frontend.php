<?php $progress = $settings->progress;
echo '<div class="velocity-progress-'.$id.'">';
foreach($progress as $data){
    $percent = $data->percent;
    echo '<div class="mb-3">';
      echo '<div class="text-secondary">'.$data->title.'</div>';
      echo '<div class="progress">';
          echo '<div class="progress-bar '.$data->color.'" role="progressbar" style="width: '.$percent.'%" aria-valuenow="'.$percent.'" aria-valuemin="0" aria-valuemax="100">'.$data->value.'</div>';
      echo '</div>';
    echo '</div>';
}
echo '</div>';?>
