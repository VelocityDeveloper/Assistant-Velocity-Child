<?php

/**
 * @class vFLProgress
 */
class vFLProgress extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __( 'Velocity Progress', 'fl-builder' ),
			'description'   	=> __( 'By Velocity Developer', 'fl-builder' ),
			'category'      	=> __( 'Info', 'fl-builder' ),
			'editor_export' 	=> false,
			'partial_refresh'	=> true,
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('vFLProgress', array(
	'layout'        => array(
		'title'         => __( 'Progress', 'fl-builder' ),
		'sections'      => array(
			'content'       => array(
				'title'         => __( 'Progress', 'fl-builder' ),
				'fields'        => array(
					'progress'     => array(
						'type'         => 'form',
						'label'        => __('Progress Box', 'fl-builder'),
						'form'         => 'progress_form',
						'preview_text' => 'title',
						'multiple'     => true
					),
				),
			),
		),
	),
));

FLBuilder::register_settings_form('progress_form', array(
	'title' => __( 'Add Progress', 'fl-builder' ),
	'tabs'  => array(
		'general'      => array(
			'title'         => __('General', 'fl-builder'),
			'sections'      => array(
				'title'       => array(
					'title'         => __( 'Progress', 'fl-builder' ),
					'fields'        => array(
						'title'          => array(
							'type'          => 'text',
							'label'         => __('Title', 'fl-builder'),
						),
                        'color'   => array(
                            'type'    => 'select',
                            'label'   => __( 'Color', 'fl-builder' ),
                            'default' => 'progress-default',
                            'options' => array(
                                'progress-default' => __( 'Default', 'fl-builder' ),
                                'bg-secondary' => __( 'Gray', 'fl-builder' ),
                                'bg-success' => __( 'Green', 'fl-builder' ),
                                'bg-danger' => __( 'Red', 'fl-builder' ),
                                'bg-warning' => __( 'Yellow', 'fl-builder' ),
                                'bg-info' => __( 'Blue', 'fl-builder' ),
                                'bg-dark' => __( 'Black', 'fl-builder' ),
                            ),
                        ),
						'value'          => array(
							'type'          => 'text',
							'label'         => __('Value', 'fl-builder'),
                           'default' => 'Rp 100.000.000',
						),
						'percent'          => array(
							'type'          => 'text',
							'label'         => __('Percent Complete', 'fl-builder'),
                           'default' => '100',
						),
					),
				),
			)
		),
	)
));
