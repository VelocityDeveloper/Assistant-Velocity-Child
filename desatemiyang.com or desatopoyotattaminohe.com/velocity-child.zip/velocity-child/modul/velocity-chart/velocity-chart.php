<?php

/**
 * @class vFChart
 */
class vFChart extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __( 'Velocity Chart', 'fl-builder' ),
			'description'   	=> __( 'By Velocity Developer.', 'fl-builder' ),
			'category'      	=> __( 'Media', 'fl-builder' ),
			'editor_export' 	=> false,
			'partial_refresh'	=> true,
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('vFChart', array(
	'layout'        => array(
		'title'         => __( 'Chart', 'fl-builder' ),
		'sections'      => array(
			'content'       => array(
				'title'         => __( 'Chart', 'fl-builder' ),
				'fields'        => array(
					'charts'     => array(
						'type'         => 'form',
						'label'        => __('Chart Box', 'fl-builder'),
						'form'         => 'charts_column_form',
						'preview_text' => 'title',
						'multiple'     => true
					),
				),
			),
		),
	),
	'layout2'        => array(
		'title'         => __( 'Style', 'fl-builder' ),
		'sections'      => array(
			'content2'       => array(
				'title'         => __( 'Style', 'fl-builder' ),
				'fields'        => array(
					'width'     => array(
						'type'         => 'text',
						'label'        => __('Width', 'fl-builder'),
						'default'         => '450',
					),
				),
			),
		),
	),
));

FLBuilder::register_settings_form('charts_column_form', array(
	'title' => __( 'Add Chart', 'fl-builder' ),
	'tabs'  => array(
		'general'      => array(
			'title'         => __('Chart', 'fl-builder'),
			'sections'      => array(
				'title'       => array(
					'title'         => __( 'Chart', 'fl-builder' ),
					'fields'        => array(
						'title'          => array(
							'type'          => 'text',
							'label'         => __('Title', 'fl-builder'),
						),
						'value'          => array(
							'type'          => 'text',
							'label'         => __('Value', 'fl-builder'),
						),
					),
				),
			)
		),
	)
));
