<?php $width = $settings->width;
echo '<div class="mx-auto" style="max-width: '.$width.'px;">';
echo '<canvas id="velocity-chart-'.$id.'" width="400" height="400"></canvas>';
echo '</div>';?>