<?php $images = $settings->gallery;
$style = $settings->style;
$width = !empty($settings->width) ? $settings->width : '300';
$height = !empty($settings->height) ? $settings->height : '300';
echo '<div id="image-carousel" class="images-'.$id.'">';
if ($images) {
foreach($images as $image){
	$img_url = wp_get_attachment_url($image);
  	$urlresize = aq_resize($img_url, $width, $height, true, true, true);
    echo '<div class="p-0"><div class="image-list"><a href="'.$img_url.'">';
	echo '<img class="imm-thumb w-100" src="'.$urlresize.'" />';
    echo '</a></div></div>';
}
}
echo '</div>';?>
