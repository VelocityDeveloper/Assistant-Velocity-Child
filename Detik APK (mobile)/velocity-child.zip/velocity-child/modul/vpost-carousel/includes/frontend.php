<?php 

$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="second-post slider-bottom-<?php echo $id; ?> mb-0 pb-4">
<?php foreach($posts as $post) { ?>
<div class="post-list-module bg-white rounded m-1">
<div class="p-1 pb-2">
<a href="<?php echo get_the_permalink($post->ID);?>">
<div class="thumb-second" style="background-image:url('<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?> ');"></div>
</a>
<div class="second-post-title"><a class="text-dark fw-bold" href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post);?></a></div>
</div>
</div>
<?php } ?>
</div>
