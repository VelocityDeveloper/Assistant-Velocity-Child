jQuery(function($) {
$('.slider-bottom-<?php echo $id; ?>').slick({
  slidesToShow: 2,
  slidesToScroll: 1,
  dots: true,
arrows: false,
  centerMode: true,
  focusOnSelect: true,
});
});