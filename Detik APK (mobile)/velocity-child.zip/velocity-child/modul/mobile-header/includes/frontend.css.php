
.menu-logo img {
	max-height: 33px;
	width: auto;
}
.menu-frame {
	position: relative;
	z-index: 1;
}
.vel-mobile-menu {
	position: fixed;
	top: 0;
	left: 0;
	z-index: 9;
	width: 100%;
	background-color: #fff;
	box-shadow: 0px 0px 7px 0px rgba(0,0,0,0.2);
}
.admin-bar .vel-mobile-menu {
	top: 32px;
}
.fl-builder-edit .vel-mobile-menu {
	top: 0 !important;
}
.fl-builder-edit .vel-mobile-height {
	height: 0 !important;
}
.single-fl-theme-layout .vel-mobile-menu,
.fl-builder-edit .vel-mobile-menu {
	position: relative !important;
}
.vel-menu-<?php echo $id; ?> {
	position:relative;
}
.slide-icon-<?php echo $id; ?> {
    color: #333333;    
    cursor: pointer;
}
.slide-icon-<?php echo $id; ?> i {
    font-size: 27px;
    width: 32px;
    height: 28px;
}
#web-body {
    transition: margin-left .5s;
}
.sidenav {
	height: 100%;
	width: 0;
	position: fixed;
	z-index: 9999;
	top: 90px;
	left: 0;
	background-color: #fff;
	overflow-x: hidden;
	transition: 0.5s;
	padding-top: 40px;
	box-shadow: 0px 0px 8px 0px rgba(0,0,0,0.1);
}
.sidenav .closebtn {
	position: absolute;
	color: #333;
	top: 5px;
	right: 11px;
	font-size: 30px;
	text-decoration: none !important;
	line-height: 1;
}
.sidenav .closebtn:hover {opacity: 0.8;}
.left-menu-<?php echo $id; ?> {
    padding: 0;
    margin: 0;
	list-style: none;
	display: flex;
	flex-flow: row wrap;
	align-content: flex-start;
	justify-content: space-between;
}
.left-menu-<?php echo $id; ?> > li {
	width: 50%;
	list-style: none;
	padding: 0;
	margin: 0 0 0px 0;
}
.left-menu-<?php echo $id; ?> li {position: relative;}
.left-menu-<?php echo $id; ?> li a {
    color: #000;
    padding: 4px 15px;
    display: block;
    position: relative;
    font-weight: bold;
    font-size: 13px;
    line-height: 19px;
}
.left-menu-<?php echo $id; ?> li a:hover {color: #444;}
.left-menu-<?php echo $id; ?> li.menu-item-has-children > a {padding: 10px 35px 10px 15px;}
.left-menu-<?php echo $id; ?> li.menu-item-has-children i {
    color: #333;
    position: absolute;
    right: 0;
    top: 0;
    cursor: pointer;
    text-align: center;
    padding: 5px 8px;
    font-size: 30px;
}
.left-menu-<?php echo $id; ?> li ul {padding-left: 20px;display:none}
.left-menu-<?php echo $id; ?> li {display:block}
.top-menu {
	padding: 0 0 10px;
	margin: 10px 0 0;
	display: flex;
	white-space: nowrap;
	width: 100%;
	overflow-x: scroll;
}
.top-menu li {
	display: inline-block;
}
.top-menu li a {
	padding: 5px 10px;
	display: block;
	font-weight: bold;
	color: #000;
}
.top-menu li ul {
	display: none !important;
}
.vel-cari, .caribaru {
    position: relative;
}
.vel-cari .tombols,  .caribaru .tombolsbaru{
    padding: 4px 15px;
    display: inline-block;
    cursor: pointer;
}
.caribaru .tombolsbaru{
    color: #fff;
}
.vel-cari .tombols:after, .caribaru .tombolsbaru:after {
    content: '\f002';
    font-family: fontawesome;
}
.vel-cari .tombols.collapsed:after, .caribaru .tombolsbaru.collapsed:after {
    content: '\f00d';
}
.vel-cari #formsearchvel, .caribaru #formsearchvelbaru {
	position: absolute;
	right: 10px;
	z-index: 9999999999;
	background: #fff;
	padding: 10px;
	box-shadow: 0px 0px 10px -2px rgba(0, 0, 0, 0.34);
	top: 125%;
	display: none;
	width: 230px;
}
#formsearchvel .search-input, #formsearchvelbaru .search-input {
    width: 85%;
    float: left;
    border: 1px solid #ddd;
    padding: 4px 10px;
    box-shadow: inset 0 0 15px 0 rgba(0,0,0,.08);
    border-right: 0;
}
#formsearchvel .search-button, #formsearchvelbaru .search-button {
    float: left;
    width: 15%;
    background: transparent;
    border: 0;
    padding: 4px;
    cursor: pointer;
    color: #888;
    border: 1px solid #ddd;
    border-left: 0;
    box-shadow: inset 0 0 15px 0 rgba(0,0,0,.08);
}
#formsearchvel:after, #formsearchvelbaru:after {
    content: '\f0d8';
    font-family: fontawesome;
    position: absolute;
    top: -15px;
    right: 10px;
    font-size: 25px;
    color: #fff;
}

@media only screen and (min-width: 768px) {
  .vel-mobile-menu-container {
	max-width: 600px;
    width: 100%;
    margin: 0 auto;
  }
}
