
jQuery(function($) {
$( ".tombols" ).click(function() {
      $("#formsearchvel").toggle();
      $(".tombols").toggleClass( "collapsed" );
    });
$( ".tombolsbaru" ).click(function() {
      $("#formsearchvelbaru").toggle();
      $(".tombolsbaru").toggleClass( "collapsed" );
    });
});

jQuery(document).ready(function() {
    jQuery(".same-menu #li-menu").hover(function(){
        document.getElementById("top-menu").style.display = "none";
        }, function(){
        document.getElementById("top-menu").style.display = "block";
    });
});

jQuery(document).ready(function ($) {
	var fixHeight = $('.vel-mobile-height').css({height: $('.vel-mobile-menu').outerHeight(true),});
	fixHeight;
});
