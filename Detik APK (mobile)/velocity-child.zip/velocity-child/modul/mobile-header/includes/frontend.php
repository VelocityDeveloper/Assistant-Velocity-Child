<?php $photo = $settings->photo; ?>



<div class="vel-mobile-menu" id="mobile-nav">
  
  <div class="vel-mobile-menu-container">

  <div class="vel-menu-<?php echo $id; ?>">
  <div class="row align-items-center pt-2 m-0">
  <div class="col-9 text-start">
      <?php if ($photo){ ?>
          <div class="menu-logo"><a href="<?php echo home_url(); ?>"><img src="<?php echo wp_get_attachment_url($photo); ?>" /></a></div>
      <?php } ?>
  </div>
  <div class="col-3 px-0 text-end">
  <div class="vel-cari">
     <span class="tombols"></span>
     <form action="<?php echo get_home_url();?>" method="get" id="formsearchvel">
      <input class="search-input" name="s" placeholder="Cari berita.." type="text">
      <button class="search-button" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
     </form>
  </div>
  </div>
  </div>

  </div>

  <div class="menu-frame">
  <?php $defaults = array(
      'menu'			=> $settings->menu,
      'container'		=> false,
      'menu_id'	=> 'top-menu',
      'menu_class'	=> 'top-menu same-menu',
  );
  wp_nav_menu( $defaults ); ?>
  </div>

  </div>
</div>

<div class="vel-mobile-height"></div>

