<?php $images = $settings->image_columns;
echo '<div id="image-carousel" class="row">';
foreach($images as $image){
    echo '<div class="text-center col-3 mb-3"><a href="'.$image->link.'" target="_blank">';
  	if(!empty($image->image)){
      $url = wp_get_attachment_url($image->image);
      $urlimg = aq_resize($url, 50, 50, false, true, true);
      echo '<div class="gambar-kategori"><img src="'.$urlimg.'" /></div>';
    }
    if(!empty($image->title)){
      echo '<div class="py-2 text-dark">'.$image->title.'</div>';
    }
    echo '</a></div>';
}
echo '</div>';?>
