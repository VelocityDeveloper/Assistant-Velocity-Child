<?php
/**
 * Fuction yang digunakan di theme ini.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

function vsstem_modul() {
	if ( class_exists( 'FLBuilder' ) ) {
	    get_template_part('modul/vel-gallery/vel-gallery');
	    get_template_part('modul/gallery-carousel/gallery-carousel');
	    get_template_part('modul/vpost-carousel/vpost-carousel');
	    get_template_part('modul/vel-post-gallery/vel-post-gallery');
	}
}
add_action( 'init', 'vsstem_modul' );



add_action('init', 'velocity_admin_init');
function velocity_admin_init() {
    register_post_type('produk', array(
        'labels' => array(
            'name' => 'Produk',
            'singular_name' => 'produk',
            'add_new' => 'Tambah Produk Baru',
            'add_new_item' => 'Tambah Produk Baru',
            'edit_item' => 'Edit Produk',
            'view_item' => 'Lihat Produk',
            'search_items' => 'Cari Produk',
            'not_found' => 'Tidak ditemukan',
            'not_found_in_trash' => 'Tidak ada Produk di kotak sampah'
        ),
        'menu_icon' => 'dashicons-screenoptions',
        'public' => true,
        'has_archive' => true,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
        ),
    ));
}


add_filter( 'rwmb_meta_boxes', 'vel_metabox' );
function vel_metabox( $meta_boxes ){
	$textdomain = 'justg';
	$meta_boxes[] = array(
		'id'         => 'standard',
		'title'      => __( 'Velocity Fields', $textdomain ),
		'post_types' => array( 'produk' ),
		'context'    => 'normal',
		'priority'   => 'high',
		'autosave'   => true,
		'fields'     => array(
			array(
				'name'  => __( 'Harga', $textdomain ),
				'id'    => "harga",
				'type'  => 'number',
				'desc'  => __( 'Isi dengan angka saja, contoh: 230000000', $textdomain ),
			),
			array(
				'name'             => __( 'Foto Tambahan', $textdomain ),
				'id'               => "gallery",
				'type'             => 'image_advanced',
			),
			array(
				'name'    => 'Fitur',
				'id'      => 'fitur',
				'type'    => 'wysiwyg',
				'raw'     => true,
				'options' => [
					'textarea_rows' => 7,
					'teeny'         => false,
					'tinymce'         => true,
				],
			),
			array(
				'name'    => 'Spesifikasi',
				'id'      => 'spesifikasi',
				'type'    => 'wysiwyg',
				'raw'     => true,
				'options' => [
					'textarea_rows' => 7,
					'teeny'         => false,
					'tinymce'         => true,
				],
			),
		)
	);

	return $meta_boxes;
}

