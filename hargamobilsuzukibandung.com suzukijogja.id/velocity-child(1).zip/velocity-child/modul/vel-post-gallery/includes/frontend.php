<?php global $post;
$images = rwmb_meta( 'gallery', array( 'size' => 'thumbnail' ) );
    $width      = 400;
    $height     = 400;
    $crop       = true;
    $upscale    = true;
	if($images){
        echo '<div class="slider-produk text-center">';
            echo '<div class="p-2 mb-1 id-'.$id.'" id="parent-container">';
                foreach ( $images as $image ) {
                    $urlbesar = $image['full_url'];
                    echo '<div class="p-1">';
                    echo '<a href="'.$image['full_url'].'">';
                    echo '<img class="lazy d-inline-block" src="'.$urlbesar.'" alt="" data-src="'.$urlbesar.'">';
                    echo '</a></div>';
				}
            echo '</div>';
            echo '<div class="navigasi navid-'.$id.'">';
                foreach ( $images as $image ) {
                    $urlbesar = $image['full_url'];
                    echo '<div class="p-2">';
                    echo '<img class="lazy d-inline-block" src="'.$urlbesar.'" alt="" data-src="'.$urlbesar.'">';
                    echo '</div>';
                }
            echo '</div>';
        echo '</div>';
    }
	
?>