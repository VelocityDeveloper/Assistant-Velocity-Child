<?php 
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="vd-post-carousel">
    <div class="vd-carousel-<?php echo $id; ?>">
        <?php foreach($posts as $post) { ?>
            <div class="post-list-module bg-white rounded m-2">
                <div class="p-1 pb-2 position-relative vd-carousel-list">
                <a href="<?php echo get_the_permalink($post->ID);?>">
                <div class="vd-carousel-thumb" style="background-image:url('<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?> ');"></div>
                </a>
                <div class="vd-carousel-detail text-center text-white">
                    <div class="vd-carousel-content">
                        <a class="text-white d-block fw-bold z-index" href="<?php echo get_the_permalink($post->ID);?>">
                            <?php echo get_the_title($post);?>
                        </a>
                        <i class="z-index">Mulai dari</i>
                        <div class="fw-bold fst-italic z-index">
                            <?php echo do_shortcode('[harga post_id="'.$post->ID.'"]');?>
                        </div>
                        <div class="vd-carousel-button">                            
                            <a href="<?php echo get_the_permalink($post->ID);?>">
                                JELAJAH
                            </a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
