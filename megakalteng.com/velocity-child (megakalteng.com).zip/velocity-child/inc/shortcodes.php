<?php
/**
 * Kumpulan shortcode yang digunakan di theme ini.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
//[resize-thumbnail width="300" height="150" linked="true" class="w-100"]
add_shortcode('resize-thumbnail', 'resize_thumbnail');
function resize_thumbnail($atts) {
    ob_start();
	global $post;
    $atribut = shortcode_atts( array(
        'output'	=> 'image', /// image or url
        'width'    	=> '300', ///width image
        'height'    => '150', ///height image
        'crop'      => 'false',
        'upscale'   	=> 'true',
        'linked'   	=> 'true', ///return link to post	
        'class'   	=> 'w-100', ///return class name to img	
        'attachment' 	=> 'true'
    ), $atts );

    $output			= $atribut['output'];
    $attach         = $atribut['attachment'];
    $width          = $atribut['width'];
    $height         = $atribut['height'];
    $crop           = $atribut['crop'];
    $upscale        = $atribut['upscale'];
    $linked        	= $atribut['linked'];
    $class        	= $atribut['class']?'class="'.$atribut['class'].'"':'';
	$urlimg			= get_the_post_thumbnail_url($post->ID,'full');
	
	if(empty($urlimg) && $attach == 'true'){
          $attachments = get_posts( array(
            'post_type' 		=> 'attachment',
            'posts_per_page' 	=> 1,
            'post_parent' 		=> $post->ID,
        	'orderby'          => 'date',
        	'order'            => 'DESC',
          ) );
          if ( $attachments ) {
				$urlimg = wp_get_attachment_url( $attachments[0]->ID, 'full' );
          }
    }

	if($urlimg):
		$urlresize      = aq_resize( $urlimg, $width, $height, $crop, true, $upscale );
		if($output=='image'):
			if($linked=='true'):
				echo '<a href="'.get_the_permalink($post->ID).'" title="'.get_the_title($post->ID).'">';
			endif;
			echo '<img src="'.$urlresize.'" width="'.$width.'" height="'.$height.'" loading="lazy" '.$class.'>';
			if($linked=='true'):
				echo '</a>';
			endif;
		else:
			echo $urlresize;
		endif;

	else:
		if($linked=='true'):
			echo '<a href="'.get_the_permalink($post->ID).'" title="'.get_the_title($post->ID).'">';
		endif;
		echo '<svg style="background-color: #ececec;width: 100%;height: auto;" width="'.$width.'" height="'.$height.'"></svg>';
		if($linked=='true'):
			echo '</a>';
		endif;
	endif;

	return ob_get_clean();
}

//[excerpt count="150"]
add_shortcode('excerpt', 'vd_getexcerpt');
function vd_getexcerpt($atts){
    ob_start();
	global $post;
    $atribut = shortcode_atts( array(
        'count'	=> '150', /// count character
    ), $atts );

    $count		= $atribut['count'];
    $excerpt	= get_the_content();
    $excerpt 	= strip_tags($excerpt);
    $excerpt 	= substr($excerpt, 0, $count);
    $excerpt 	= substr($excerpt, 0, strripos($excerpt, " "));
    $excerpt 	= ''.$excerpt.'...';

    echo $excerpt;

	return ob_get_clean();
}

// [vd-breadcrumbs]
add_shortcode('vd-breadcrumbs','vd_breadcrumbs');
function vd_breadcrumbs() {
    ob_start();
    echo justg_breadcrumb();
    return ob_get_clean();
}

//[ratio-thumbnail size="medium" ratio="16:9"]
add_shortcode('ratio-thumbnail', 'ratio_thumbnail');
function ratio_thumbnail($atts) {
    ob_start();
	global $post;

    $atribut = shortcode_atts( array(
        'size'      => 'medium', // thumbnail, medium, large, full
        'ratio'     => '16:9', // 16:9, 8:5, 4:3, 3:2, 1:1
    ), $atts );

    $size       = $atribut['size'];
    $ratio      = $atribut['ratio'];
    $ratio      = $ratio?str_replace(":","-",$ratio):'';
	$urlimg     = get_the_post_thumbnail_url($post->ID,$size);

    echo '<div class="ratio-thumbnail">';
        echo '<a class="ratio-thumbnail-link" href="'.get_the_permalink($post->ID).'" title="'.get_the_title($post->ID).'">';
            echo '<div class="ratio-thumbnail-box ratio-thumbnail-'.$ratio.'" style="background-image: url('.$urlimg.');">';
                echo '<img src="'.$urlimg.'" loading="lazy" class="ratio-thumbnail-image"/>';
            echo '</div>';
        echo '</a>';
    echo '</div>';

	return ob_get_clean();
}




// [velocity-post-tabs]
function velocity_post_tabs() {
    ob_start();
    $jumlah = 3; ?>

<ul class="nav nav-tabs velocity-post-tabs" role="tablist">
  <li class="nav-item pb-0 border-0">
    <a class="nav-link active secondary-font" id="kategori1-tab" data-bs-toggle="tab" href="#kategori1" role="tab" aria-controls="kategori1" aria-selected="true">
	Popular</a>
  </li>
  <li class="nav-item pb-0 border-0">
    <a class="nav-link secondary-font" id="kategori2-tab" data-bs-toggle="tab" href="#kategori2" role="tab" aria-controls="kategori2" aria-selected="false">
	Recent</a>
  </li>
  <li class="nav-item pb-0 border-0">
    <a class="nav-link secondary-font" id="kategori3-tab" data-bs-toggle="tab" href="#kategori3" role="tab" aria-controls="kategori3" aria-selected="false">
	Comment</a>
  </li>
</ul>
<div class="tab-content py-2 border-left border-right border-bottom" id="myTabContent">
<div class="tab-pane fade show active" id="kategori1" role="tabpanel" aria-labelledby="kategori1-tab">
<?php $args = array(
	'posts_per_page' => $jumlah,
	'showposts' => $jumlah,
	'meta_key' => 'hit',
	'orderby' => 'meta_value_num',
	'order' => 'DESC',
);

$wp_query = new WP_Query($args); 
if($wp_query->have_posts ()): ?>
<div class="frame-kategori">
<?php while($wp_query->have_posts()): $wp_query->the_post();
        echo '<div class="row m-0 py-2">';
        echo '<div class="col-4 col-sm-3 p-0">';
        if ( has_post_thumbnail() ){
          echo '<a href="'.get_the_permalink().'">';
            echo do_shortcode('[resize-thumbnail width="200" height="200" linked="true" class="w-100"]');
          echo '</a>';
        }
		echo '</div>';
		echo '<div class="col-8 col-sm-9 py-1">';
		$vtitle= get_the_title();
		echo '<div class="vtitle"><a class="text-dark secondary-font" href="'.get_the_permalink().'">'.substr($vtitle, 0, 60) . ' ...'.'</a></div>';
		echo '<div class="text-muted"><small><i class="fa fa-calendar" aria-hidden="true"></i> '.get_the_date('j F Y',get_the_ID()).'</small></div>';
		echo '</div>';
		echo '</div>';
?>
<?php endwhile; ?>
</div>
<?php else :
_e( '<p>Belum ada post.</p>' );
endif;
wp_reset_query (); ?>
</div>
<div class="tab-pane fade" id="kategori2" role="tabpanel" aria-labelledby="kategori2-tab">
<?php $args2 = array(
	'posts_per_page' => $jumlah,
	'showposts' => $jumlah, 
);

$wp_query2 = new WP_Query($args2); 
if($wp_query2->have_posts ()): ?>
<div class="frame-kategori">
<?php while($wp_query2->have_posts()): $wp_query2->the_post();
        echo '<div class="row m-0 py-2 px-1">';
        echo '<div class="col-4 col-sm-3 p-0">';
        if ( has_post_thumbnail() ){
          echo '<a href="'.get_the_permalink().'">';
            echo do_shortcode('[resize-thumbnail width="200" height="200" linked="true" class="w-100"]');
          echo '</a>';
        }
		echo '</div>';
		echo '<div class="col-8 col-sm-9 py-1">';
		$vtitle= get_the_title();
		echo '<div class="vtitle"><a class="text-dark secondary-font" href="'.get_the_permalink().'">'.substr($vtitle, 0, 60) . ' ...'.'</a></div>';
		echo '<div class="text-muted"><small><i class="fa fa-calendar" aria-hidden="true"></i> '.get_the_date('j F Y',get_the_ID()).'</small></div>';
		echo '</div>';
		echo '</div>';
?>
<?php endwhile; ?>
</div>
<?php else :
_e( '<p>Belum ada post.</p>' );
endif;
wp_reset_query (); ?>
</div>
  
<div class="tab-pane fade" id="kategori3" role="tabpanel" aria-labelledby="kategori3-tab">
<?php $args3 = array(
	'posts_per_page' => $jumlah,
	'showposts' => $jumlah,
	'orderby' => 'comment_count',
	'order' => 'DESC',
);

$wp_query3 = new WP_Query($args3); 
if($wp_query3->have_posts ()): ?>
<div class="frame-kategori">
<?php while($wp_query3->have_posts()): $wp_query3->the_post();
        echo '<div class="row m-0 py-2 px-1">';
        echo '<div class="col-4 col-sm-3 p-0">';
        if ( has_post_thumbnail() ){
          echo '<a href="'.get_the_permalink().'">';
			echo do_shortcode('[resize-thumbnail width="200" height="200" linked="true" class="w-100"]');
          echo '</a>';
        }
		echo '</div>';
		echo '<div class="col-8 col-sm-9 py-1">';
		$vtitle= get_the_title();
		echo '<div class="vtitle"><a class="text-dark secondary-font" href="'.get_the_permalink().'">'.substr($vtitle, 0, 60) . ' ...'.'</a></div>';
		echo '<div class="text-muted"><small><i class="fa fa-calendar" aria-hidden="true"></i> '.get_the_date('j F Y',get_the_ID()).'</small></div>';
		echo '</div>';
		echo '</div>';
?>
<?php endwhile; ?>
</div>
<?php else :
_e( '<p>Belum ada post.</p>' );
endif;
wp_reset_query (); ?>
</div>
</div>
    <?php
    return ob_get_clean();
}
add_shortcode ('velocity-post-tabs', 'velocity_post_tabs');



// [social-share]
function vel_social_buttons($content) {
    global $post,$wp;
    if(is_singular() || is_home()){
        $post_id = $post->ID;
		// Get current URL 
        $sb_url = urlencode(get_permalink($post_id));
		//$sb_url = home_url(add_query_arg(array($_GET), $wp->request));
 
        // Get current web title
        $sb_title = str_replace( ' ', '%20', get_the_title($post_id));
        //$sb_title = wp_title('',false);
         
        // Construct sharing URL without using any script
        $twitterURL = 'https://twitter.com/intent/tweet?text='.$sb_title.'&amp;url='.$sb_url;
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$sb_url;
        $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$sb_url.'&amp;title='.$sb_title;
        $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;description='.$sb_title;
        $whatsappURL ='https://api.whatsapp.com/send?text='.$sb_title.' '.$sb_url;
        $telegramURL ='https://telegram.me/share/url?url='.$sb_url.'';
        $emailURL ='mailto:?subject=I wanted you to see this site&amp;body='.$sb_title.' '.$sb_url.' ';
        
        //get views and get shares
        //$countviews = get_post_meta($post_id, 'hit', true)?get_post_meta($post_id, 'hit', true):0;
        //$countshare = get_post_meta($post_id, 'post_share_count', true)?get_post_meta($post_id, 'post_share_count', true):0;
 
        // Add sharing button at the end of page/page content
        $content .= '<div class="social-box"><div class="mb-2">Bagikan ini:</div>';
        //$content .= '<div class="btn btn-sm btn-outline-info me-2 mb-1"><span id="datashare" class="font-weight-bold">'.$countshare.'</span> Shares</div>';
        //$content .= '<div class="btn btn-sm btn-outline-secondary me-2 mb-1"><span class="font-weight-bold">'.$countviews.'</span> Views</div>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-twitter postshare-button" href="'.$twitterURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-twitter" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-facebook postshare-button" href="'.$facebookURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-facebook-square" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-whatsapp postshare-button" href="'.$whatsappURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-whatsapp" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-pinterest postshare-button" href="'.$pinterestURL.'" data-pin-custom="true" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-pinterest" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-linkedin postshare-button" href="'.$linkedInURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-linkedin" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-info me-2 mb-1 s-telegram postshare-button" href="'.$telegramURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-telegram" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-email postshare-button" href="'.$emailURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-envelope-o" aria-hidden="true"></i></span></a>';
        $content .= '</div>';
        
        return $content;
    } else {
        // if not a post/page then don't include sharing button
        return $content;
    }
};
add_shortcode('social-share','vel_social_buttons');


// [related-post]
function relatedpost(){
	ob_start();
	$idp = get_the_ID();
	$cats = wp_get_post_terms( get_the_ID(), 'category' ); 
	$cats_ids = array();  
	foreach( $cats as $wpex_related_cat ) {
		$cats_ids[] = $wpex_related_cat->term_id; 
	}
	if ( ! empty( $cats_ids ) ) {
		$args['category__in'] = $cats_ids;
		$args['posts_per_page'] = 3;
		$args['post__not_in'] = array ( $idp );
	}
	$wpex_query = new wp_query( $args );
	if($wpex_query->have_posts ()):
	echo '<div class="row">';
		while($wpex_query->have_posts()): $wpex_query->the_post(); ?>
		<div class="col-md-4 col-sm-6 mb-3">
			<?php echo do_shortcode('[resize-thumbnail width="300" height="250" linked="true" class="w-100 mb-2"]'); ?>
			<div class="fs-6"><a class="text-dark" href="<?php echo get_the_permalink($post->ID); ?>"><?php echo get_the_title($post->ID); ?></a></div>
			<div class="text-secondary"><small><?php echo get_the_date('d/m/Y',$post->ID);?></small></div>
		</div>
	<?php endwhile;
	echo '</div>';
	endif;
	wp_reset_postdata();
	return ob_get_clean();
}
add_shortcode('related-post', 'relatedpost');

