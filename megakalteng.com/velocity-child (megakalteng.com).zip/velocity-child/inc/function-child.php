<?php
/**
 * Fuction yang digunakan di theme ini.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
  
function vsstem_modul() {
	if ( class_exists( 'FLBuilder' ) ) {
	    get_template_part('inc/modul/vrunning-post/vrunning-post');
	    get_template_part('inc/modul/vpost-slider/vpost-slider');
	    get_template_part('inc/modul/vpost-carousel/vpost-carousel');
	}
}
add_action( 'init', 'vsstem_modul' );


// Update jumlah pengunjung dengan plugin WP-Statistics
function velocity_allpage() {
    global $wpdb,$post;
    $postID = $post->ID;
    $count_key = 'hit';
    if(empty($post))
    return false;
    $table_name = $wpdb->prefix . "statistics_pages";
    $results    = $wpdb->get_results("SELECT sum(count) as result_value FROM $table_name WHERE id = $postID");
    $count = $results?$results[0]->result_value:'0';
    if($count=='') {
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    } else {
        update_post_meta($postID, $count_key, $count);
    }
}
add_action( 'wp', 'velocity_allpage' );

// Menampilkan jumlah pengunjung: [hits]
function hits($atts) {
   global $post;
    $atribut = shortcode_atts( array(
        'post_id'     => $post->ID,
    ), $atts );
    $post_id	    = $atribut['post_id'];
   $view = get_post_meta($post_id,'hit',true);
   if(empty($view)){
	   $jml = '0';
   } else {
	   $jml = $view;
   }
   return $jml;
}
add_shortcode( 'hits', 'hits' );



// [cari]
function velocity_search(){
$html = '<form method="get" id="searchform" action="'.get_home_url().'" role="search">
	<label class="sr-only" for="s">Search</label>
	<div class="input-group">
		<input class="field form-control form-control-sm rounded-0" id="s" name="s" type="text" placeholder="Search…" value="" required>
		<span class="input-group-append">
            <button type="submit" class="btn btn-dark btn-sm rounded-0">
              <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
              </svg>
            </button>
		</span>
	</div>
</form>';
return $html;
}
add_shortcode('cari', 'velocity_search');
