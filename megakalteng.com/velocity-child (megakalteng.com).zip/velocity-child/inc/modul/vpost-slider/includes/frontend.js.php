jQuery(function($) {
$('.slider-bottom-<?php echo $id; ?>').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: false,
});
});