<?php 

$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="mb-0 second-post slider-bottom-<?php echo $id; ?>">
<?php foreach($posts as $post) {
$author_id = $post->post_author; 
$authord = get_the_author_meta( 'display_name', $author_id);?>  
<div class="vpostslider-list">
  <div class="vpostslider-thumbnail" style="background-image: url(
  <?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?>
  );">
  <div class="vpostslider-content">
    <div class="vpostslider-title mb-3"><a class="text-white" href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post->ID);?></a></div>
    <div class="vpostslider-time text-white">
      <small>By <?php echo $authord; ?>  |  <?php echo get_the_date( 'j F Y', $post->ID );?></small>
    </div>
  </div>
</div>
</div>
<?php } ?>
</div>
