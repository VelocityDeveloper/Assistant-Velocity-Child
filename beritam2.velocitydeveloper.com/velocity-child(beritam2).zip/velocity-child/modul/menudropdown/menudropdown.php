<?php
/**
 * This is an example module with only the basic
 * setup necessary to get it working.
 *
 * @class menudropdown
 */
class menudropdown extends FLBuilderModule {

    /** 
     * Constructor function for the module. You must pass the
     * name, description, dir and url in an array to the parent class.
     *
     * @method __construct
     */  
    public function __construct()
    {
        parent::__construct(array(
            'name'          => __('Menu Dropdown', 'fl-builder'),
            'description'   => __('Modul Menu Dropdown', 'fl-builder'),
            'category'		=> __('Velocity Modules', 'fl-builder'),
            'editor_export' => true, // Defaults to true and can be omitted.
            'enabled'       => true, // Defaults to true and can be omitted.
        ));
    }
    public static function _left_menus() {
		$get_menus = get_terms( 'nav_menu', array(
			'hide_empty' => true,
		) );
		$fields = array(
			'type'          => 'select',
			'label'         => __( 'Menu', 'fl-builder' ),
			'helper'		=> __( 'Select a WordPress menu that you created in the admin under Appearance > Menus.', 'fl-builder' ),
		);

		if ( $get_menus ) {

			foreach ( $get_menus as $key => $menu ) {

				if ( 0 == $key ) {
					$fields['default'] = $menu->name;
				}

				$menus[ $menu->slug ] = $menu->name;
			}

			$fields['options'] = $menus;

		} else {
			$fields['options'] = array(
				'' => __( 'No Menus Found', 'fl-builder' ),
			);
		}

		return $fields;

	}

        // Register and enqueue your own
        //$this->add_css('example-lib', $this->url . 'css/frontend.css');
        //$this->add_js('example-lib', $this->url . 'js/example-lib.js', array(), '', true);
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('menudropdown', array(
    'general'       => array( // Tab
        'title'         => __('Dasar', 'fl-builder'), // Tab title
        'sections'      => array( // Tab Sections
            'general'       => array( // Section
                'title'         => '', // Section Title
                'fields'        => array( // Section Fields
				    'menu_left' => menudropdown::_left_menus(),
				    'photo'         => array(
						'type'          => 'photo',
						'label'         => __( 'Logo Menu', 'fl-builder' ),
						'show_remove'   => true,
					),
                
                )
            )
        )
    ),
 
));
