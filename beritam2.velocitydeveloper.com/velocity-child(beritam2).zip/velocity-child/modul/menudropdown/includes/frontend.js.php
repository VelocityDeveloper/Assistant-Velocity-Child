jQuery(document).ready(function($){

	$('.head-cat45').hide();
    $('.tomb-hcat').click(function(){
        $('.head-cat45').toggle();
        // alert('pesan');
    });

});