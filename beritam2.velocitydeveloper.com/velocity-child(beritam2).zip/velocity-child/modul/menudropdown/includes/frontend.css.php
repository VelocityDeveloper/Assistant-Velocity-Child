

.head-cat45 {   
    position: absolute;
    z-index: 999;
    top: 100%;
    overflow-y: scroll;
	max-width: 300px;
	background-color: #fff;
    border: 1px solid #ececec;
	-webkit-box-shadow: 0 0 10px 0 rgba(0,0,0,.2);
	-moz-box-shadow: 0 0 10px 0 rgba(0,0,0,.2);
	box-shadow: 0 0 10px 0 rgba(0,0,0,.2);
}
.tomb-hcat img {
    max-height: 30px;
    width: auto;
    margin-bottom:0 !important;
}
.tomb-hcat {
	display: inline-block;
	position: relative;
	cursor: pointer;
}
.left-menu-<?php echo $id;?> {
    padding:0;
    margin:0;
}
.left-menu-<?php echo $id;?> li {
    display: block;
}
.left-menu-<?php echo $id;?> li a {
  display: block;
  padding: 7px 15px;
  border-bottom: 1px dashed rgba(0,0,0,0.07);
  font-size: 13px;
  color: #626262;
}


