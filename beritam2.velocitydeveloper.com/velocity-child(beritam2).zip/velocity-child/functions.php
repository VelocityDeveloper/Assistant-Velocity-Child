<?php
/**
 * Child theme functions
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development
 * and http://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions would be used.
 *
 * Text Domain: justg
 * @link http://codex.wordpress.org/Plugin_API
 *
 */

/**
 * Load other required files
 *
 */

 $inc = get_stylesheet_directory() . '/inc';
 $includes = [
	'enqueue.php',
	'function-child.php',
	'shortcodes.php'
 ];

 foreach( $includes as $include ) {
	 require_once( $inc . '/' . $include );
 }


function vsstem_modul() {
	if ( class_exists( 'FLBuilder' ) ) {
	    get_template_part('modul/menudropdown/menudropdown');
	}
}
add_action( 'init', 'vsstem_modul' );


function catsatu(){
    $category = get_the_category();
    $html = '<a href="'.get_category_link($category[0]->cat_ID).'">' . $category[0]->cat_name . '</a>';
    return $html;
}
add_shortcode('catsatu', 'catsatu');

function velocity_related(){
    global $post;
    $related = get_posts( array( 'category__in' => wp_get_post_categories($post->ID), 'numberposts' => 2, 'post__not_in' => array($post->ID) ) );
    $html ='';
    $html .='<ul>';
    if( $related ) foreach( $related as $post ) {
        setup_postdata($post);
            $html .='<li>';
                $html .='<a href="'.get_the_permalink().'" rel="bookmark" title="'.get_the_title().'">'.get_the_title().'</a>';
            $html .='</li>';        
    }
    $html .='</ul>';
    $html .= wp_reset_postdata();
    return $html;
}
add_shortcode('related', 'velocity_related');

// [cari]
function velocity_search(){
    $html = '<form class="vel-search" method="get" name="searchform" action="'.get_home_url().'">
        <input class="search-input" placeholder="Cari berita.." name="s" value="" type="text" required>
        <button class="search-button" type="submit">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
            </svg>
        </button>
    </form>';
    return $html;
}
add_shortcode('cari', 'velocity_search');

//video

add_action('init', 'video_post_type');
function video_post_type() {
    register_post_type('video', array(
        'labels' => array(
            'name' => 'Video',
            'singular_name' => 'video',
            'add_new' => 'Tambah Video Baru',
            'add_new_item' => 'Tambah Video Baru',
            'edit_item' => 'Edit Video',
            'view_item' => 'Lihat Video',
            'search_items' => 'Cari Video',
            'not_found' => 'Tidak ditemukan',
            'not_found_in_trash' => 'Tidak ada video di kotak sampah'
        ),
        'menu_icon' => 'dashicons-media-document',
        'public' => true,
        'has_archive' => true,
        'taxonomies' => array('kategori-video'),
        'supports' => array(
            'title',
            'editor',
			'thumbnail',
			'post-formats',
        ),
   ));
}

add_action( 'init', 'ad_add_taxo1' );
function ad_add_taxo1() {
	register_taxonomy(
	'kategori-video',
	'video',
	array(
		'label' => __( 'Kategori Video' ),
		'rewrite' => array( 'slug' => 'kategori-video' ),
		'hierarchical' => true,
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_nav_menus' => true,
	)
	);
	function blogger_query_vars_filter( $vars ) {
  $vars[] = "blogger";
  return $vars;
}
 
add_filter('query_vars', 'blogger_query_vars_filter');
 
function blogger_template_redirect() {
  global $wp_query;
  $blogger = $wp_query->query_vars['blogger'];
  if ( isset ( $blogger ) ) {
    wp_redirect( get_wordpress_url ( $blogger ) , 301 );
    exit;
  }
}
 
add_action( 'template_redirect', 'blogger_template_redirect' );
 
function get_wordpress_url($blogger) {
  if ( preg_match('@^(?:https?://)?([^/]+)(.*)@i', $blogger, $url_parts) ) {
    $query = new WP_Query ( 
      array ( "meta_key" => "blogger_permalink", "meta_value" => $url_parts[2] ) );
    if ($query->have_posts()) { 
      $query->the_post();
      $url = get_permalink(); 
    } 
    wp_reset_postdata(); 
  } 
  return $url ? $url : home_url();
}
	function mycustom_embed_defaults($embed_size){
    $embed_size['width'] = 586; // Adjust values to your needs
    $embed_size['height'] = 500;

    return $embed_size;
}

add_filter('embed_defaults', 'mycustom_embed_defaults');
}


// Update jumlah pengunjung dengan plugin WP-Statistics
function velocity_allpage() {
    global $wpdb,$post;
    $postID = $post->ID;
    $count_key = 'hit';
    if(empty($post))
    return false;
    $table_name = $wpdb->prefix . "statistics_pages";
    $results    = $wpdb->get_results("SELECT sum(count) as result_value FROM $table_name WHERE id = $postID");
    $count = $results?$results[0]->result_value:'0';
    if($count=='') {
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    } else {
        update_post_meta($postID, $count_key, $count);
    }
}
add_action( 'wp', 'velocity_allpage' );

// Menampilkan jumlah pengunjung: [hits]
function hits($atts) {
   global $post;
    $atribut = shortcode_atts( array(
        'post_id'     => $post->ID,
    ), $atts );
    $post_id	    = $atribut['post_id'];
   $view = get_post_meta($post_id,'hit',true);
   if(empty($view)){
	   $jml = '0';
   } else {
	   $jml = $view;
   }
   $html = 'Dilihat '.$jml.' kali';
   return $html;
}
add_shortcode( 'hits', 'hits' );


// [social-share]
function vel_social_buttons($content) {
    global $post,$wp;
    if(is_singular() || is_home()){
        $post_id = $post->ID;
		// Get current URL 
        $sb_url = urlencode(get_permalink($post_id));
		//$sb_url = home_url(add_query_arg(array($_GET), $wp->request));
 
        // Get current web title
        $sb_title = str_replace( ' ', '%20', get_the_title($post_id));
        //$sb_title = wp_title('',false);
         
        // Construct sharing URL without using any script
        $twitterURL = 'https://twitter.com/intent/tweet?text='.$sb_title.'&amp;url='.$sb_url;
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$sb_url;
        $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$sb_url.'&amp;title='.$sb_title;
        $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;description='.$sb_title;
        $whatsappURL ='https://api.whatsapp.com/send?text='.$sb_title.' '.$sb_url;
        $telegramURL ='https://telegram.me/share/url?url='.$sb_url.'';
        $emailURL ='mailto:?subject=I wanted you to see this site&amp;body='.$sb_title.' '.$sb_url.' ';
        
        //get views and get shares
        //$countviews = get_post_meta($post_id, 'hit', true)?get_post_meta($post_id, 'hit', true):0;
        //$countshare = get_post_meta($post_id, 'post_share_count', true)?get_post_meta($post_id, 'post_share_count', true):0;
 
        // Add sharing button at the end of page/page content
        $content .= '<div class="social-box">';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-twitter postshare-button" href="'.$twitterURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-twitter" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-facebook postshare-button" href="'.$facebookURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-facebook-square" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-whatsapp postshare-button" href="'.$whatsappURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-whatsapp" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-pinterest postshare-button" href="'.$pinterestURL.'" data-pin-custom="true" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-pinterest" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-linkedin postshare-button" href="'.$linkedInURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-linkedin" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-info me-2 mb-1 s-telegram postshare-button" href="'.$telegramURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-telegram" aria-hidden="true"></i></span></a>';
        $content .= '<a class="btn btn-sm btn-secondary me-2 mb-1 s-email postshare-button" href="'.$emailURL.'" target="_blank" rel="nofollow" data-id="'.$post_id.'"><span><i class="fa fa-envelope-o" aria-hidden="true"></i></span></a>';
        $content .= '</div>';
        
        return $content;
    } else {
        // if not a post/page then don't include sharing button
        return $content;
    }
};
add_shortcode('social-share','vel_social_buttons');
