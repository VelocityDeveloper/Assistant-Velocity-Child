jQuery(function($) {
    $('.slider-utama .fl-post-feed').slick({
        dots: false,
        slidesToShow: 3,
        slidesToScroll: 3,
        appendArrows:$('.utamanav'),
        speed: 500
    });

  jQuery(document).ready(function ($) {
      if ($(window).width() > 768){
          const HeaderHeight = $('.header-sticky').height();
          const stickyHeaderTop = $('.header-sticky');
          $(window).scroll(function(){
              if( $(window).scrollTop() > HeaderHeight ) {
                  stickyHeaderTop.addClass('header-sticky-scrolled');
              } else {
                  stickyHeaderTop.removeClass('header-sticky-scrolled');
              }
          });
      }
  });
    function startTime() {
      const today = new Date();
      let h = today.getHours();
      let m = today.getMinutes();
      let s = today.getSeconds();

      const month = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Ags","Sep","Okt","Nov","Des"];
        let day = today.getDate();
        let nMonth = month[today.getMonth()];
        let year = today.getFullYear();

      m = checkTime(m);
      s = checkTime(s);
      document.getElementById('timenow').innerHTML = day +" / "+ nMonth +" / "+ year +" "+ h + ":" + m + ":" + s;
      setTimeout(startTime, 1000);
    }
  
    startTime();
    function checkTime(i) {
      if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
      return i;
    }
});