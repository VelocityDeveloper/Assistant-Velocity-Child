.image-carousel-thumbnail {
    height: <?php echo !empty($settings->height) ? $settings->height : '300';?>px;
    width: 100%;
    background-color: #ffffff;
    background-position: center;
    background-size: cover;
}
.fl-module-image-carousel .slick-prev, .fl-module-image-carousel .slick-next {
	top: 170px !important;
}
.fl-module-image-carousel .slick-prev::before, .fl-module-image-carousel .slick-next::before {
	font-family: 'fontAwesome' !important;
	color: #333333 !important;
}
.fl-module-image-carousel .slick-next::before {
	content: "\f054" !important;
}
.fl-module-image-carousel .slick-prev::before {
	content: "\f053" !important;
}