<?php $post_id = $settings->anggota;
if ($post_id){
$urlresize = aq_resize(wp_get_attachment_url($image), 300, 380, true, true, true );
echo '<div class="profil-anggota position-relative text-center">';
	$link = get_the_permalink($post_id);
	$jabatan = get_post_meta($post_id,'jabatan',true);
	if (has_post_thumbnail($post_id)) {
		$urlimg = get_the_post_thumbnail_url($post_id,'large');
	} else {
		$urlimg = get_stylesheet_directory_uri().'/img/no-profile.jpg';
	}
	echo '<a href="'.$link.'">';
		echo '<div class="profil-anggota-thumb" style="background-image:url('.$urlimg.');"></div>';
	echo '</a>';
	echo '<div class="mt-2">';
	echo '<div class="h6 font-weight-bold mb-2"><a href="'.$link.'">'.get_the_title($post_id).'</a></div>';
	echo '<div class="jabatan-anggota">'.$jabatan.'</div>';
	echo '</div>';
echo '</div>';
} ?>