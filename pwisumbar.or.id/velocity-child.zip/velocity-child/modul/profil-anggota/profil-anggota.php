<?php



class vFLprofilanggota extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __( 'Profil Anggota', 'fl-builder' ),
			'category'      	=> __( 'Info', 'fl-builder' ),
			'editor_export' 	=> false,
			'partial_refresh'	=> true,
		));
	}


	public static function get_anggota() {
		$anggota = get_posts(array(
			'showposts' => -1,
			'post_type' => array('anggota'),
			'orderby' => 'title',
			'order'   => 'DESC',
		));  
		$fields = array(
			'type'          => 'select',
			'label'         => __( 'Pilih Anggota', 'fl-builder' ),
		);

		if ( $anggota ) {

			$anggota_options = array(
				'' => 'Pilih Anggota'
			);
			foreach ($anggota as $mypost) {
				$anggota_options[$mypost->ID] = $mypost->post_title;   
			}

			$fields['options'] = $anggota_options;

		} else {
			$fields['options'] = array(
				'' => __( 'Tidak Ada Anggota', 'fl-builder' ),
			);
		}

		return $fields;

	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('vFLprofilanggota', array(
	'layout'        => array(
		'title'         => __( 'Profile', 'fl-builder' ),
		'sections'      => array(
			'content'       => array(
				'title'         => __( 'Profile', 'fl-builder' ),
				'fields'        => array(
                    'anggota' => vFLprofilanggota::get_anggota(),
				),
			),
		),
	),
));
