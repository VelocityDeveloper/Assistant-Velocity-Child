			
<?php 
$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
$paged = isset($_GET['hal'])? $_GET['hal'] : 1;
$posts_per_page = -1;
$object = get_queried_object();
//echo '<pre>'.print_r($object,1).'</pre>'; 

$args = array(
   // 'paged' => $paged,
    'posts_per_page' => $posts_per_page,
);
if (!empty($object->taxonomy)) {
    $args['tax_query'] = array(
        array(
            'taxonomy' => $object->taxonomy,
            'field'    => 'slug',
            'terms'    => $object->slug,
        ),
    );
} if ( is_post_type_archive() ) {
    $args['post_type'] = $object->labels->singular_name;
}


$wp_query = new WP_Query($args); 
if($wp_query->have_posts ()): ?>

<div class="table-responsive">
<table id="data-<?php echo $id;?>" class="table table-striped">
  <thead>
    <tr class="text-uppercase">
      <th scope="col" class="p-2">No</th>
      <th scope="col" class="p-2">Nama</th>
      <th scope="col" class="p-2">Media</th>
      <th scope="col" class="p-2">Kompetensi</th>
      <th scope="col" class="p-2">Detail</th>
    </tr>
  </thead>
  <tbody>
<?php $i = 0;
while($wp_query->have_posts()): $wp_query->the_post();
    $no = ++$i;
    $media = get_post_meta( get_the_ID(), 'media', true );
    $kompetensi = get_post_meta( get_the_ID(), 'kompetensi', true );
    $jabatan = get_post_meta( get_the_ID(), 'jabatan', true ); ?>
    <tr>
      <th scope="row"><?php echo $no;?></th>
      <td><?php the_title(); ?></td>
      <td><?php echo !empty($media) ? $media : '-'; ?></td>
      <td><?php echo !empty($kompetensi) ? $kompetensi : '-'; ?></td>
      <td><a class="btn btn-sm btn-primary px-4" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">Lihat Detail</a></td>
    </tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
<?php else : ?>
<div class="alert alert-warning">Pencarian tidak ditemukan.</div>
<?php endif; ?>
<?php wp_reset_query(); ?>

