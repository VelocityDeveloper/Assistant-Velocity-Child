jQuery(function($){
    $('#data-<?php echo $id;?>').DataTable({
        responsive: true
    });
});