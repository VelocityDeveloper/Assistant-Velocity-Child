<?php

/**
 * @class FLvSearchResult
 */
class FLvSearchResult extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __('Search Result', 'fl-builder'),
			'description'   	=> __('Search Result Archive by Velocity Developer.', 'fl-builder'),
			'category'      	=> __('Posts', 'fl-builder'),
			'editor_export' 	=> false,
			'partial_refresh'	=> true
		));
	}

}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvSearchResult', array(
	'slider'      => array(
		'title'         => __('No Setting', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
				)
			),

		)
	),
));