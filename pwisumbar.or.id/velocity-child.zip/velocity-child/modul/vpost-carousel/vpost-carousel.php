<?php

class vFLPostCarousel extends FLBuilderModule {

	public function __construct() {
		parent::__construct(array(
			'name'          	=> __( 'Vel Posts Carousel', 'fl-builder' ),
			'description'   	=> __( 'By Velocity', 'fl-builder' ),
			'category'      	=> __( 'Posts', 'fl-builder' ),
			'editor_export' 	=> false,
			'partial_refresh'	=> true,
			'icon'				=> 'schedule.svg',
		));
	}

}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('vFLPostCarousel', array(
	'layout'        => array(
		'title'         => __( 'General', 'fl-builder' ),
		'sections'      => array(
			'content'       => array(
				'title'         => __( 'Post', 'fl-builder' ),
				'fields'        => array(
					'posts_per_page' => array(
						'type'          => 'text',
						'label'         => __( 'Posts Slider Total', 'fl-builder' ),
						'default'       => '10',
						'size'          => '4',
					),
				),
			),
		),
	),
	'content'   => array(
		'title'         => __( 'Content', 'fl-builder' ),
		'file'          => FL_BUILDER_DIR . 'includes/loop-settings.php',
	),
));
