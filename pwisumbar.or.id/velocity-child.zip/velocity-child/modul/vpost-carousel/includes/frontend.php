<?php 

$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="velocity-post-carousel velocity-carousel-<?php echo $id; ?>">
<?php foreach($posts as $post) {
    $link = get_the_permalink($post->ID);
    $jabatan = get_post_meta($post->ID,'jabatan',true);
    if (has_post_thumbnail($post->ID)) {
        $urlimg = get_the_post_thumbnail_url($post->ID,'large');
    } else {
        $urlimg = get_stylesheet_directory_uri().'/img/no-profile.jpg';
    }
    echo '<div class="text-center p-3">';
    echo '<a href="'.$link.'">';
        echo '<div class="velocity-post-carousel-thumbnail" style="background-image:url('.$urlimg.');"></div>';
    echo '</a>';
    echo '<div class="mt-2">';
    echo '<div class="h6 font-weight-bold mb-0">'.get_the_title($post->ID).'</div>';
    echo '<div class="people-position mb-2">'.$jabatan.'</div>';
    echo '<a href="'.$link.'">View Profile</a>';
    echo '</div>';
    echo '</div>';
} ?>
</div>
