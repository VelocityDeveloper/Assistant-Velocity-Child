<?php 

$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="row align-items-center">
<div class="col-sm-2 d-sm-block d-none text-center py-2 px-0"><?php echo $settings->title; ?></div>
<div class="col-sm-10 py-2">
<marquee behavior="scroll" scrollamount="5" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
<?php foreach($posts as $post) { ?>
<a href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post);?></a>
<span class="px-3"></span>
<?php } ?>
</marquee>
</div>
</div>