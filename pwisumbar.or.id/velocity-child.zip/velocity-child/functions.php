<?php
/**
 * Child theme functions
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development
 * and http://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions would be used.
 *
 * Text Domain: justg
 * @link http://codex.wordpress.org/Plugin_API
 *
 */

/**
 * Load other required files
 *
 */

 $inc = get_stylesheet_directory() . '/inc';
 $includes = [
	'enqueue.php',
	'function-child.php',
	'shortcodes.php'
 ];

 foreach( $includes as $include ) {
	 require_once( $inc . '/' . $include );
 }

function vsstem_modul() {
	if ( class_exists( 'FLBuilder' ) ) {
	    get_template_part('modul/vrunning-post/vrunning-post');
	    get_template_part('modul/vel-gallery/vel-gallery');
	    get_template_part('modul/gallery-carousel/gallery-carousel');
	    get_template_part('modul/vpost-carousel/vpost-carousel');
	    get_template_part('modul/profil-anggota/profil-anggota');
	    get_template_part('modul/search-result/search-result');
	}
}
add_action( 'init', 'vsstem_modul' );





add_action('init', 'velocity_admin_init');
function velocity_admin_init() {
    register_post_type('anggota', array(
        'labels' => array(
            'name' => 'Anggota',
            'singular_name' => 'anggota',
            'add_new' => 'Tambah Anggota',
            'add_new_item' => 'Tambah Anggota',
            'edit_item' => 'Edit Anggota',
            'view_item' => 'Lihat Anggota',
            'search_items' => 'Cari Anggota',
            'not_found' => 'Tidak ditemukan',
            'not_found_in_trash' => 'Tidak ada anggota di kotak sampah'
        ),
        'menu_icon' => 'dashicons-groups',
        'public' => true,
        'has_archive' => true,
        'taxonomies' => array('kategori'),
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
        ),
    ));
	register_taxonomy(
	'kategori',
	'anggota',
	array(
		'label' => __( 'Kategori Anggota' ),
		'rewrite' => array( 'slug' => 'kategori' ),
		'hierarchical' => true,
		'show_admin_column' => true,
	));
}

function pippin_add_taxonomy_filters() {
	global $typenow; 
	// an array of all the taxonomyies you want to display. Use the taxonomy name or slug
	$taxonomies = array('kategori'); 
	// must set this to the post type you want the filter(s) displayed on
	if( $typenow == 'anggota' ){ 
		foreach ($taxonomies as $tax_slug) {
			$tax_obj = get_taxonomy($tax_slug);
			$tax_name = $tax_obj->labels->name;
			$terms = get_terms($tax_slug);
			if(count($terms) > 0) {
				echo "<select name='$tax_slug' id='$tax_slug' class='postform'>";
				echo "<option value=''>Semua $tax_name</option>";
				foreach ($terms as $term) { 
					echo '<option value='. $term->slug, $_GET[$tax_slug] == $term->slug ? ' selected="selected"' : '','>' . $term->name .' (' . $term->count .')</option>'; 
				}
				echo "</select>";
			}
		}
	}
}
add_action( 'restrict_manage_posts', 'pippin_add_taxonomy_filters' );




/******* ADD CUSTOM META BOX ******* */

function add_custom_meta_box() {
	$screens = array( 'anggota' );
	foreach ( $screens as $screen ) {
		add_meta_box(
			'detailanggota_section',
			__( 'Detail Anggota', 'detailanggota' ),
			'vel_meta_box_callback',
			$screen
		);
	}
}
add_action( 'add_meta_boxes', 'add_custom_meta_box' );


function vel_meta_box_callback( $post ) {
	wp_nonce_field( 'vel_metabox', 'detailanggota_nonce' );

	$media = get_post_meta( $post->ID, 'media', true );
	$kompetensi = get_post_meta( $post->ID, 'kompetensi', true );
	$jabatan = get_post_meta( $post->ID, 'jabatan', true );
	
	echo '<table class="form-table" role="presentation">';
	echo '<tbody>';

	echo '<tr>';
	echo '<th><label for="vel_jabatan">';
	_e( 'Jabatan', 'detailanggota' );
	echo '</label></th>';
	echo '<td><input type="text" id="vel_jabatan" name="vel_jabatan" value="' . esc_attr( $jabatan ) . '" size="25" /></td>';
	echo '</tr>';

	echo '<tr>';
	echo '<th><label for="vel_media">';
	_e( 'Media', 'detailanggota' );
	echo '</label></th>';
	echo '<td><input type="text" id="vel_media" name="vel_media" value="' . esc_attr( $media ) . '" size="25" /></td>';
	echo '</tr>';

	echo '<tr>';
	echo '<th><label for="vel_kompetensi">';
	_e( 'Kompetensi', 'detailanggota' );
	echo '</label></th>';
	echo '<td><input type="text" id="vel_kompetensi" name="vel_kompetensi" value="' . esc_attr( $kompetensi ) . '" size="25" /></td>';
	echo '</tr>';

	echo '</tbody></table>';
}


function vel_metabox( $post_id ) {

	if ( ! isset( $_POST['detailanggota_nonce'] ) ) {
		return;
	}

	if ( ! wp_verify_nonce( $_POST['detailanggota_nonce'], 'vel_metabox' ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( isset( $_POST['post_type'] ) && 'anggota' == $_POST['post_type'] ) {

		if ( ! current_user_can( 'edit_page', $post_id ) ) {
			return;
		}

	} else {

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
	}


	if ( ! isset( $_POST['vel_media'] ) ) {
		return;
	}
	if ( ! isset( $_POST['vel_kompetensi'] ) ) {
		return;
	}
	if ( ! isset( $_POST['vel_jabatan'] ) ) {
		return;
	}

	$media = sanitize_text_field( $_POST['vel_media'] );
	$kompetensi = sanitize_text_field( $_POST['vel_kompetensi'] );
	$jabatan = sanitize_text_field( $_POST['vel_jabatan'] );

	// Update the meta field in the database.
	update_post_meta( $post_id, 'media', $media );
	update_post_meta( $post_id, 'kompetensi', $kompetensi );
	update_post_meta( $post_id, 'jabatan', $jabatan );
}
add_action( 'save_post', 'vel_metabox' );



//Displaying category-product Columns
add_filter( 'manage_taxonomies_for_product_columns', 'category_product_columns' );
function category_product_columns( $taxonomies ) {
    $taxonomies[] = 'category-product';
    return $taxonomies;
}

// manage column anggota list
function anggota_custom_columns($defaults,$post_id='') {
    $screen = get_current_screen();
	if($screen->post_type == 'anggota'){
        $columns = array(
            'cb'                            => '<input type="checkbox" />',
            'featured_image'                => 'Image',
            'title'                         => 'Title',
            'taxonomy-kategori'     		=> 'Kategori',
            'date'                          => 'Tanggal',
            'jabatan'                       => 'Jabatan',
         );
        return $columns;
	} else {
		return $defaults;
	}
}
add_filter('manage_anggota_posts_columns' , 'anggota_custom_columns');

function custom_columns_data( $column, $post_id ) {
    switch ( $column ) {
    case 'featured_image':
        echo '<img style="width: 75px;height: auto;" src="'.get_the_post_thumbnail_url($post_id ,'thumbnail').'" alt="" />';
        break;
    case 'jabatan' :
        echo get_post_meta( $post_id , 'jabatan' , true ); 
        break;
    }
}
add_action( 'manage_posts_custom_column' , 'custom_columns_data', 10, 2 ); 

/* END CUSTOM META BOX */



function velocity_sub_page($atts){
    global $post;
    $atribut = shortcode_atts( array(
        'post_id'   => $post->ID,
    ), $atts );
	$post_id        = $atribut['post_id'];
  	$args = array(
      'title_li' => '',
      'child_of' => $post_id,
      'echo' => 0,
    );
    $children = wp_list_pages($args);
    $html = '';
    if ($children) {
      $html .= '<ul class="row p-0 velocity-sub-page">';
      $html .= $children;
      $html .= '</ul>';
    }
    return $html;
}
add_shortcode('velocity-sub-page', 'velocity_sub_page');
