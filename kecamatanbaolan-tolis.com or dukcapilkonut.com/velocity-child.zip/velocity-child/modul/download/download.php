<?php

/**
 * @class FLvDownload
 */
class FLvDownload extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct()
	{
		parent::__construct(array(
			'name'          	=> __('Download', 'fl-builder'),
			'description'   	=> __('', 'fl-builder'),
			'category'      	=> __('Basic', 'fl-builder'),
			'partial_refresh'	=> true
		));
	}

}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvDownload', array(
	'columns'      => array(
		'title'         => __('Download Boxes', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
						'titlebox'          => array(
							'type'          => 'text',
							'label'         => __('Text if not login', 'fl-builder'),
							'default'       => 'Silahkan mendaftar atau login dahulu untuk dapat mengakses.',
						),
					'pricing_columns'     => array(
						'type'         => 'form',
						'label'        => __('Download Box', 'fl-builder'),
						'form'         => 'pricing_column_form',
						'preview_text' => 'title',
						'multiple'     => true
					),
				)
			)
		)
	),
));

FLBuilder::register_settings_form('pricing_column_form', array(
	'title' => __( 'Add Pricing Box', 'fl-builder' ),
	'tabs'  => array(
		'general'      => array(
			'title'         => __('General', 'fl-builder'),
			'sections'      => array(
				'title'       => array(
					'title'         => __( 'Title', 'fl-builder' ),
					'fields'        => array(
						'title'          => array(
							'type'          => 'text',
							'label'         => __('Title', 'fl-builder'),
						),
						'link'          => array(
							'type'          => 'link',
							'label'         => __('Download Link', 'fl-builder'),
							'connections'   => array( 'url' ),
							'description'   => '<p>Untuk upload file, <a class="text-info" href="'.get_home_url().'/wp-admin/upload.php" target="_blank">klik disini</a> lalu copy link filenya ke kolom diatas.</p>',
						),
					),
				),
			)
		),
	)
));