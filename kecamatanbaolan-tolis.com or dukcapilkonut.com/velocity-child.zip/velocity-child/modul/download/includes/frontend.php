<?php $columns = $settings->pricing_columns; ?>

<?php if ( is_user_logged_in() ) { ?>
<div class="download-boxes">
<table class="table table-sm table-dark">
<thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama File</th>
      <th scope="col">Download Link</th>
    </tr>
</thead>
<tbody>
<?php $i = 0;
foreach ($columns as $data) {
$no = ++$i; ?>
<tr>
<td><?php echo $no.'.'; ?></td>
<td class="download-title"><?php echo $data->title; ?></td>
<td class="download-width-td download-link">
<a class="btn btn-sm btn-info py-0" title="Download <?php echo $data->title; ?>" href="<?php echo $data->link; ?>" target="_blank" download>Download <i class="fa fa-cloud-download" aria-hidden="true"></i></a>
</td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
<?php } else { ?>
<?php echo $settings->titlebox; ?>
<?php } ?>
