<?php $members = $settings->members;
echo '<div class="row team-members-list members-'.$id.'">';
foreach($members as $member){
	$whatsapp_number = $member->wa;
	$whatsapp_number = $whatsapp_number ? preg_replace('/[^0-9]/', '', $whatsapp_number) : $whatsapp_number;
    if (substr($whatsapp_number, 0, 1) == 0) {
        $whatsapp_number = substr_replace($whatsapp_number, '62', 0, 1);
    }
    echo '<div class="col-sm-6 col-md-3 mb-4">';
    echo '<div class="card shadow-sm h-100">';
    echo '<div class="member-img">';
		if(!empty($member->photo)){
			$urlimg = wp_get_attachment_url($member->photo);
			$urlresize = aq_resize( $urlimg, 350, 400, true, true, true );
			echo '<img class="w-100" src="'.$urlresize.'" />';
		}
    echo '</div>';
    echo '<div class="card-body text-center border-top">
		<div class="fs-6 fw-bold">'.$member->nama.'</div>
		<p>'.$member->posisi.'</p>
		<div class="member-social">
			<a class="s-twitter" href="'.$member->twitter.'" target="_blank"><i class="fa fa-twitter"></i></a>
			<a class="s-facebook" href="'.$member->facebook.'" target="_blank"><i class="fa fa-facebook"></i></a>
			<a class="s-email" href="mailto:'.$member->email.'" target="_blank"><i class="fa fa-envelope-o"></i></a>
			<a class="s-instagram" href="'.$member->instagram.'" target="_blank"><i class="fa fa-instagram"></i></a>
			<a class="s-whatsapp" href="https://wa.me/'.$whatsapp_number.'" target="_blank"><i class="fa fa-whatsapp"></i></a>
		</div>
	</div>';
    echo '</div>';
    echo '</div>';
}
echo '</div>'; ?>
