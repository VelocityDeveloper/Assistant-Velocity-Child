<?php

/**
 * @class vFLMembers
 */
class vFLMembers extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __( 'Members', 'fl-builder' ),
			'description'   	=> __( 'Members by Velocity Developer.', 'fl-builder' ),
			'category'      	=> __( 'Media', 'fl-builder' ),
			'editor_export' 	=> false,
			'partial_refresh'	=> true,
			'icon'				=> 'format-video.svg',
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('vFLMembers', array(
	'layout'        => array(
		'title'         => __( 'Member', 'fl-builder' ),
		'sections'      => array(
			'content'       => array(
				'title'         => __( 'Members', 'fl-builder' ),
				'fields'        => array(
					'members'     => array(
						'type'         => 'form',
						'label'        => __('Member Box', 'fl-builder'),
						'form'         => 'member_column_form',
						'preview_text' => 'title',
						'multiple'     => true
					),
				),
			),
		),
	),
));

FLBuilder::register_settings_form('member_column_form', array(
	'title' => __( 'Add Member', 'fl-builder' ),
	'tabs'  => array(
		'general'      => array(
			'title'         => __('General', 'fl-builder'),
			'sections'      => array(
				'title'       => array(
					'title'         => __( 'Title', 'fl-builder' ),
					'fields'        => array(
						'photo'          => array(
							'type' => 'photo',
							'label' => __('Photo', 'fl-builder'),
						),
						'nama'          => array(
							'type' => 'text',
							'label' => __('Nama', 'fl-builder'),
						),
						'posisi'          => array(
							'type' => 'text',
							'label' => __('Posisi', 'fl-builder'),
						),
						'facebook'          => array(
							'type'          => 'link',
							'label'         => __('Facebook', 'fl-builder'),
						),
						'twitter'          => array(
							'type'          => 'link',
							'label'         => __('Twitter', 'fl-builder'),
						),
						'instagram'          => array(
							'type'          => 'link',
							'label'         => __('Instagram', 'fl-builder'),
						),
						'email'          => array(
							'type'          => 'text',
							'label'         => __('Email', 'fl-builder'),
						),
						'wa'          => array(
							'type'          => 'text',
							'label'         => __('Whatsapp', 'fl-builder'),
						),
					),
				),
			)
		),
	)
));
