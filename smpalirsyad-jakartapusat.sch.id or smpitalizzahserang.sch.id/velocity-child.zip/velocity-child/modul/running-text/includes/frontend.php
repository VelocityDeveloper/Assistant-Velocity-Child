<div class="velocitymarquee">
  <div>
    <span><?php echo $settings->isi; ?></span>
    <span><?php echo $settings->isi; ?></span>
  </div>
</div>