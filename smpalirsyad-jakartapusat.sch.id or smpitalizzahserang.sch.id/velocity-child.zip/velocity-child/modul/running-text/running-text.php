<?php

/**
 * @class FLvRunningText
 */
class FLvRunningText extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __('Running Text', 'fl-builder'),
			'description'   	=> __('Running Text', 'fl-builder'),
			'category'      	=> __('Velocity Modules', 'fl-builder'),
			'editor_export' 	=> false,
			'partial_refresh'	=> true
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvRunningText', array(
	'slider'      => array(
		'title'         => __('Basic Module', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
                    'isi' => array(
                        'type'          => 'text',
                        'label'         => __('Isi', 'fl-builder'),
                        'default'       => 'Running Text',
                    ),
				),
			),

		)
	),
));