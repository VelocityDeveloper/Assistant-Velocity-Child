<?php $settings->posts_per_page = 5;
$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;
 ?>
<div class="frame-luar">
    <div class="slider-panah"></div>
    <div class="slider-frame-img">
        <?php foreach($posts as $post) { ?>
        		    <div class="frame-slide">
        		        <div class="image-post">
						<img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?>" />
						</div>
        		        <div class="frame-isi">
                            <div class="judul mb-md-3"><a href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post);?></a></div>
                            <div class="isipost text-white d-none d-md-block">
                                <?php $content = get_the_content('',false,$post->ID);
                                $trimmed_content = wp_trim_words( $content, 50 );
                                echo $trimmed_content; ?>
                            </div>
                        </div>
        		    </div>
        <?php } ?>
    </div>
</div>
<div class="frame-kecil">
<div class="slider-frame-navi">
    <?php foreach($posts as $post) { ?>
        <div class="small-nav">
            <?php echo get_the_title($post->ID);?>
        </div>
    <?php } ?>
</div>
</div>