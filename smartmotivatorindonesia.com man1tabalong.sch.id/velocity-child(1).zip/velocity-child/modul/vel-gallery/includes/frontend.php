<?php $photos = $module->get_photos();
$jml = $settings->jumlah;
$page = isset($_GET[$id])?intval($_GET[$id]-1):0;
$number_of_pages = ceil(count($photos)/$jml)+1;
rsort($photos); ?>
<?php if ( 'collage' == $settings->layout ) : ?>
<div class="fl-mosaicflow m-0" id="<?php echo $id ?>">
	<div class="fl-mosaicflow-content">
	<div class="row m-0">
		<?php foreach (array_slice($photos, $page*$jml, $jml) as $photo) : ?>
		<div class="col-6 col-sm-4 p-2">
		<?php

		$url = 'none' == $settings->click_action ? '' : $photo->link;

		if ( 'lightbox' == $settings->click_action && isset( $settings->lightbox_image_size ) ) {
			if ( '' !== $settings->lightbox_image_size ) {
				$size = $settings->lightbox_image_size;
				$data = FLBuilderPhoto::get_attachment_data( $photo->id );
				if ( isset( $data->sizes->{$size} ) ) {
					$url = $data->sizes->{$size}->url;
				}
			}
		}

		FLBuilder::render_module_html('photo', array(
			'crop'          => true,
			'link_target'   => '_self',
			'link_type'     => 'none' == $settings->click_action ? '' : 'url',
			'link_url'      => $url,
			'photo'         => $photo,
			'photo_src'     => $photo->src,
			'show_caption'  => $settings->show_captions,
		));

		?>
		</div>
		<?php endforeach; ?>
		</div>
	</div>
	<div class="fl-clear"></div>
</div>
<?php else : ?>
<div class="fl-gallery" id="<?php echo $id ?>">
	<?php foreach (array_slice($photos, $page*$jml, $jml) as $photo) : ?>
	<div class="fl-gallery-item">
	<?php

	$url = 'none' == $settings->click_action ? '' : $photo->link;

	if ( 'lightbox' == $settings->click_action && isset( $settings->lightbox_image_size ) ) {
		if ( '' !== $settings->lightbox_image_size ) {
			$size = $settings->lightbox_image_size;
			$data = FLBuilderPhoto::get_attachment_data( $photo->id );
			if ( isset( $data->sizes->{$size} ) ) {
				$url = $data->sizes->{$size}->url;
			}
		}
	}

	FLBuilder::render_module_html('photo', array(
		'crop'          => false,
		'link_target'   => '_self',
		'link_type'     => 'none' == $settings->click_action ? '' : 'url',
		'link_url'      => $url,
		'photo'         => $photo,
		'photo_src'     => $photo->src,
		'show_caption'  => $settings->show_captions,
	));

	?>
	</div>
	<?php endforeach; ?>
</div>
<?php endif; ?>

<ul class="pagination m-2 d-block">
<?php
if($number_of_pages>=3){
$actual_link = strtok($_SERVER["REQUEST_URI"],'?');
for($i=1;$i<$number_of_pages;$i++){
if(isset($_GET[$id])){
	$idsementara = $_GET[$id];
} else {
	$idsementara = '1';
}
if($idsementara==$i){
$cls = ' active';
}else{
$cls = '';
} ?>
<li class="d-inline-block align-top page-item<? echo $cls;?>"><a class="page-link" href='<?php echo $actual_link ?>?<?php echo $id; ?>=<?=$i?>#<?php echo $id; ?>'><?=$i?></a></li>
<?php } } ?>
</ul>
