<?php 

$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="row align-items-center bg-white m-0">
    <div class="col-sm-2 d-sm-block d-none bg-warning text-white text-center py-2 px-0">HIGHLIGHT</div>
    <div class="col-sm-10 py-2">
        <marquee behavior="scroll" scrollamount="5" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
            <?php foreach($posts as $post) { ?>
                <a class="text-dark" href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post);?></a>
                <span class="px-3">|</span>
            <?php } ?>
        </marquee>
    </div>
</div>