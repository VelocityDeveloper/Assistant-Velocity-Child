<div class="col-md-4 col-6 mb-4 text-center">
    <?php echo do_shortcode("[resize-thumbnail width='300' height='300' crop='false' upscale='true']"); ?>
    <div class="mt-3">
        <a class="text-dark" href="<?php echo get_the_permalink($post->ID); ?>"><?php echo get_the_title($post->ID); ?></a>
    </div>
</div>