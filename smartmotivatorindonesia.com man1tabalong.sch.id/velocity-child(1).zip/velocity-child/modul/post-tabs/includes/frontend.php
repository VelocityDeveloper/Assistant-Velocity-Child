<?php 
$jumlah = $settings->jumlah;
$cat1 = $settings->kategori;
$cat2 = $settings->kategori2;
$cat3 = $settings->kategori3;
$term = get_term_by('slug', $cat1, 'category');
$name1 = $term->name;
$term2 = get_term_by('slug', $cat2, 'category');
$name2 = $term2->name;
$term3 = get_term_by('slug', $cat3, 'category');
$name3 = $term3->name;
?>
<nav>
  <div class="nav nav-tabs row m-0" id="nav-tab" role="tablist">
    <button class="col-12 col-md-4 rounded-0 fw-bold border nav-link active" id="nav-cat1-tab" data-bs-toggle="tab" data-bs-target="#nav-cat1" type="button" role="tab" aria-controls="nav-cat1" aria-selected="true"><?php echo $name1; ?></button>
    <button class="col-12 col-md-4 rounded-0 fw-bold border nav-link" id="nav-cat2-tab" data-bs-toggle="tab" data-bs-target="#nav-cat2" type="button" role="tab" aria-controls="nav-cat2" aria-selected="false"><?php echo $name2 ?></button>
    <button class="col-12 col-md-4 rounded-0 fw-bold border nav-link" id="nav-cat3-tab" data-bs-toggle="tab" data-bs-target="#nav-cat3" type="button" role="tab" aria-controls="nav-cat3" aria-selected="false"><?php echo $name3 ?></button>
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id="nav-cat1" role="tabpanel" aria-labelledby="nav-cat1-tab">
  <?php $args = array(
	'posts_per_page' => $jumlah,
	'showposts' => $jumlah,
	'category_name' => $cat1,  
);

$wp_query = new WP_Query($args); 
if($wp_query->have_posts ()): ?>
<div class="row m-0 py-3 border-start border-bottom border-end">
<?php while($wp_query->have_posts()): $wp_query->the_post(); ?>
<?php include apply_filters( 'fl_builder_vpost_tabs_layout_path', $module->dir . 'includes/loop-post.php' );?>  
<?php endwhile; ?>
</div>
<?php else :
_e( '<p>Belum ada post.</p>' );
endif;
wp_reset_query (); ?>
  </div>
  <div class="tab-pane fade" id="nav-cat2" role="tabpanel" aria-labelledby="nav-cat2-tab">
  <?php $args2 = array(
	'posts_per_page' => $jumlah,
	'showposts' => $jumlah,
	'category_name' => $cat2,  
);

$wp_query2 = new WP_Query($args2); 
if($wp_query2->have_posts ()): ?>
<div class="row m-0 py-3 border-start border-bottom border-end">
<?php while($wp_query2->have_posts()): $wp_query2->the_post(); ?>
<?php include apply_filters( 'fl_builder_vpost_tabs_layout_path', $module->dir . 'includes/loop-post.php' );?>  
<?php endwhile; ?>
</div>
<?php else :
_e( '<p>Belum ada post.</p>' );
endif;
wp_reset_query (); ?>
  </div>
  <div class="tab-pane fade" id="nav-cat3" role="tabpanel" aria-labelledby="nav-cat3-tab">
	<?php $args3 = array(
	'posts_per_page' => $jumlah,
	'showposts' => $jumlah,
	'category_name' => $cat3,  
);

$wp_query3 = new WP_Query($args3); 
if($wp_query3->have_posts ()): ?>
<div class="row m-0 py-3 border-start border-bottom border-end">
<?php while($wp_query3->have_posts()): $wp_query3->the_post(); ?>
<?php include apply_filters( 'fl_builder_vpost_tabs_layout_path', $module->dir . 'includes/loop-post.php' );?>  
<?php endwhile; ?>
</div>
<?php else :
_e( '<p>Belum ada post.</p>' );
endif;
wp_reset_query (); ?>
</div>
</div>

