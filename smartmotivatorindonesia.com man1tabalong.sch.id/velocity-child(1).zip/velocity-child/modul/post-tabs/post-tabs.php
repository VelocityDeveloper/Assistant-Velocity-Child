<?php

/**
 * @class FLvposttabs
 */
class FLvposttabs extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct()
	{
		parent::__construct(array(
			'name'          	=> __('Post Tabs', 'fl-builder'),
			'description'   	=> __('Post Tabs by Velocity Developer.', 'fl-builder'),
			'category'      	=> __('Posts', 'fl-builder'),
			'editor_export' 	=> false,
			'partial_refresh'	=> true
		));

		$this->add_css('jquery-bxslider');
		$this->add_js('jquery-bxslider');
	}
  

	public static function vel_get_kategori() {      
      $args = array(
          //'taxonomy' => 'kategori',
          'orderby' => 'name',
      );        
      $cat_options = array(
          '' => 'Show All'
          );
      $categories = get_categories( $args );        
      foreach ( $categories as $category ) {            
          $cat_options[$category->slug] = $category->name;            
      }
      return $cat_options; 
	}

}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLvposttabs', array(
	'slider'      => array(
		'title'         => __('Recent Posts', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
                    'kategori' => array(
                        'type'          => 'select',
                        'label'         => __('Pilih Kategori 1', 'fl-builder'),
                        'options'       => FLvposttabs::vel_get_kategori(),
                    ),
                    'kategori2' => array(
                        'type'          => 'select',
                        'label'         => __('Pilih Kategori 2', 'fl-builder'),
                        'options'       => FLvposttabs::vel_get_kategori(),
                    ),
                    'kategori3' => array(
                        'type'          => 'select',
                        'label'         => __('Pilih Kategori 3', 'fl-builder'),
                        'options'       => FLvposttabs::vel_get_kategori(),
                    ),
					'jumlah' => array(
						'type'          => 'text',
						'label'         => __('Jumlah Pos', 'fl-builder'),
						'default'       => '6',
					),
				)
			),

		)
	),
));