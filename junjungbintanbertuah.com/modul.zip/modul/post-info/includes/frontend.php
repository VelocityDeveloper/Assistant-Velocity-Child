<?php global $post;
$images = rwmb_meta( 'gallery', array( 'size' => 'thumbnail' ) );
$location = get_post_meta( $post->ID, 'location', true );
$price = get_post_meta( $post->ID, 'price', true );
$facilities = get_post_meta( $post->ID, 'facilities', true );
$itinerary = get_post_meta( $post->ID, 'itinerary', true );
$post_content = get_the_content($post->ID);
    $width      = 400;
    $height     = 400;
    $crop       = true;
    $upscale    = true;
if($price || $location){
  echo '<div class="border bg-light p-3 mb-4">';
  	if(!empty($location)){
 	 echo '<div class="mb-2"><b><i class="fa fa-map-marker me-2" aria-hidden="true"></i> Location:</b> '.$location.'</div>';
    } if(!empty($price)){
 	 echo '<div class="mb-0"><b><i class="fa fa-tag me-1" aria-hidden="true"></i> Price:</b> '.$price.'</div>';
    }
  echo '</div>';
}
	if($images){
        echo '<div class="slider-produk mb-3 text-center">';
            echo '<div class="bg-white border p-2 mb-1 id-'.$id.'" id="parent-container">';
			if(has_post_thumbnail($post->ID)){
				$urlt = get_the_post_thumbnail_url($post->ID,'full');
				echo '<div class="p-1 text-center"><a href="'.$urlt.'"><img class="lazy" src="'.$urlt.'" alt="" data-src="'.$urlt.'"></a></div>';
			}
                foreach ( $images as $image ) {
                    $urlbesar = $image['full_url'];
                    echo '<div class="p-1">';
                    echo '<a href="'.$image['full_url'].'">';
                    echo '<img class="lazy" src="'.$urlbesar.'" alt="" data-src="'.$urlbesar.'">';
                    echo '</a></div>';
				}
            echo '</div>';
            echo '<div class="navigasi navid-'.$id.'">';
			if(has_post_thumbnail($post->ID)){
				$urlkecilt       = aq_resize( $urlt, 165, 165, $crop, true, $upscale );
				$urlbesart       = aq_resize( $urlt, $width, $height, $crop, true, $upscale );
				echo '<div class="p-1"><div class="border"><img class="lazy img-float w-100" src="'.$urlkecilt.'" alt="" data-src="'.$urlbesart.'"></div></div>';
			}
                foreach ( $images as $image ) {
                    $urlkecil = aq_resize( $image['full_url'], 165, 165, $crop, true, $upscale );
                    $urlbesar = aq_resize( $image['full_url'], $width, $height, $crop, true, $upscale );
                    echo '<div class="p-1"><div class="border">';
                    echo '<img class="lazy w-100" src="'.$urlkecil.'" alt="" data-src="'.$urlbesar.'">';
                    echo '</div>';
                    echo '</div>';
                }
            echo '</div>';
        echo '</div>';
    } 
	

	
if($itinerary || $facilities){
echo '<div class="card p-3 mb-3 rounded-0">';
  echo '<ul class="nav nav-tabs" id="myTab" role="tablist">';
    echo '<li class="nav-item" role="presentation">';
      echo '<button class="nav-link active" id="tab1-tab" data-bs-toggle="tab" data-bs-target="#tab1" type="button" role="tab" aria-controls="tab1" aria-selected="true">Detail</button>';
    echo '</li>';
    echo '<li class="nav-item" role="presentation">';
      echo '<button class="nav-link" id="tab2-tab" data-bs-toggle="tab" data-bs-target="#tab2" type="button" role="tab" aria-controls="tab2" aria-selected="false">Facilities</button>';
    echo '</li>';
    echo '<li class="nav-item" role="presentation">';
      echo '<button class="nav-link" id="tab3-tab" data-bs-toggle="tab" data-bs-target="#tab3" type="button" role="tab" aria-controls="tab3" aria-selected="false">Itinerary</button>';
    echo '</li>';
  echo '</ul>';
  echo '<div class="tab-content" id="myTabContent">';
    echo '<div class="tab-pane fade pt-3 show active" id="tab1" role="tabpanel" aria-labelledby="tab1-tab">'.$post_content.'</div>';
    echo '<div class="tab-pane fade pt-3" id="tab2" role="tabpanel" aria-labelledby="tab2-tab">'.$facilities.'</div>';
    echo '<div class="tab-pane fade pt-3" id="tab3" role="tabpanel" aria-labelledby="tab3-tab">'.$itinerary.'</div>';
  echo '</div>';
echo '</div>';
} elseif($post_content){
	echo '<div class="card p-3 mb-4 rounded-0">';
		echo $post_content;
	echo '</div>';
}


		$sb_url = urlencode(get_permalink($post->ID));
        $sb_title = str_replace( ' ', '%20', get_the_title($post->ID));
         
        $twitterURL = 'https://twitter.com/intent/tweet?text='.$sb_title.'&amp;url='.$sb_url;
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$sb_url;
        $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$sb_url.'&amp;title='.$sb_title;
        $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;description='.$sb_title;
        $whatsappURL ='https://api.whatsapp.com/send?text='.$sb_url.'';
        $telegramURL ='https://telegram.me/share/url?url='.$sb_url.'';
        $emailURL ='mailto:?subject=I wanted you to see this site&amp;body='.$sb_title.' '.$sb_url.' ';
        
 
        echo '<div class="social-box"><div class="share-title">Social Share:</div>';
        //echo '<div class="btn btn-sm btn-outline-info mr-2 mb-1"><span id="datashare" class="font-weight-bold">'.$countshare.'</span> Shares</div>';
        //echo '<div class="btn btn-sm btn-outline-secondary mr-2 mb-1"><span class="font-weight-bold">'.$countviews.'</span> Views</div>';
        echo '<a class="btn btn-sm btn-secondary mr-2 mb-1 s-twitter postshare-button" href="'.$twitterURL.'" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-twitter" aria-hidden="true"></i></span></a>';
        echo '<a class="btn btn-sm btn-secondary mr-2 mb-1 s-facebook postshare-button" href="'.$facebookURL.'" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-facebook-square" aria-hidden="true"></i></span></a>';
        echo '<a class="btn btn-sm btn-secondary mr-2 mb-1 s-whatsapp postshare-button" href="'.$whatsappURL.'" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-whatsapp" aria-hidden="true"></i></span></a>';
        echo '<a class="btn btn-sm btn-secondary mr-2 mb-1 s-pinterest postshare-button" href="'.$pinterestURL.'" data-pin-custom="true" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-pinterest" aria-hidden="true"></i></span></a>';
        echo '<a class="btn btn-sm btn-secondary mr-2 mb-1 s-linkedin postshare-button" href="'.$linkedInURL.'" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-linkedin" aria-hidden="true"></i></span></a>';
        echo '<a class="btn btn-sm btn-info mr-2 mb-1 s-telegram postshare-button" href="'.$telegramURL.'" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-telegram" aria-hidden="true"></i></span></a>';
        echo '<a class="btn btn-sm btn-secondary mr-2 mb-1 s-email postshare-button" href="'.$emailURL.'" target="_blank" rel="nofollow" data-id="'.$post->ID.'"><span><i class="fa fa-envelope-o" aria-hidden="true"></i></span></a>';
        echo '</div>';

?>