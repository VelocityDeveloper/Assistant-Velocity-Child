    jQuery(function ($) {
        $('.id-<?php echo $id;?>').slick({
          slidesToShow: 1,
          slidesToScroll: 1,
          asNavFor: '.navid-<?php echo $id;?>',
          autoplay: false,
        });
        $('.navid-<?php echo $id;?>').slick({
          slidesToShow: 5,
          slidesToScroll: 1,
          asNavFor: '.id-<?php echo $id;?>',
          focusOnSelect: true,
          arrows: true,
          autoplay: false,
        });
		$('#parent-container').magnificPopup({
		  delegate: 'a', // child items selector, by clicking on it popup will open
		  type: 'image',
      gallery:{
        enabled:true
      }
		  // other options
		});
    });