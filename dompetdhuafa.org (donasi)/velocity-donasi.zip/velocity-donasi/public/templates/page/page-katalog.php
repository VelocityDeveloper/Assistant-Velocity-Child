<?php
/**
 * Template Name: Katalog
 *
 * @package velocity-toko
 */

get_header();
$container		= get_theme_mod( 'justg_container_type','container' );
$search_query 	= new WP_Query( array(
    'post_type'         => 'donasi',
    'post_status'       => 'publish',
    'order'             => 'asc',
    'orderby'           => 'title',
    'posts_per_page'    => -1
) );
?>

<div class="wrapper" id="page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

		<div class="row">

			<?php do_action('justg_before_content'); ?>

			<div class="content-area col order-2 px-md-0" id="primary">

        		<?php echo do_shortcode('[print targetid="main"]');?>

				<main class="site-main mt-3" id="main">
						<?php if ( $search_query->have_posts() ) : ?>
							<div class="row">
								<?php while ( $search_query->have_posts() ) : $search_query->the_post(); ?>

									<?php echo apply_filters( 'velocitytoko_content_loop_archive', $post ); ?>

								<?php endwhile; ?>
							</div>
						<?php else : ?>
							<div class="container text-center">
								<span style="font-size: 60px">
									<i  class="fa fa-shopping-cart" aria-hidden="true"></i>
								</span>
								<h3 class="mt-4 mb-3"> Tidak Ditemukan! :(</h3>
								Coba gunakan filter lain.
							</div>
						<?php endif; ?>

					</main><!-- #main -->

				</div><!-- #primary -->

				<?php do_action('justg_after_content'); ?>

			</div>

		</div><!-- #content -->

	</div><!-- #page-wrapper -->

<?php
get_footer();

