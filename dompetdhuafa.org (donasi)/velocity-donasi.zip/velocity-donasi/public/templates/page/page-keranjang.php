<?php
/* Template Name: Page Keranjang
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
$container	= get_theme_mod( 'justg_container_type','container' );
?>

<div class="wrapper" id="page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

		<div class="row">

			<div class="col-md">

			<div class="content-area col order-2 px-md-0" id="primary">

				<main class="site-main" id="main" role="main">

					<?php					 
						///get data Keranjang
						$Cart   = new Vsstemmart\Keranjang;
						$carts  = $Cart->count();

						if($carts > 0) {
							if(isset($_GET['action']) && $_GET['action'] == 'checkout'){
								get_velocitytoko_part( 'inc/store/checkout');
							} else if (isset($_GET['action']) && $_GET['action'] == 'finish'){
								get_velocitytoko_part( 'inc/store/finish');
							} else {
								get_velocitytoko_part( 'inc/store/keranjang');
							}
						} else {
							echo '<div class="text-center">';
								echo '<i style="font-size: 60px" class="fa fa-shopping-cart" aria-hidden="true"></i>';
								echo '<h3 class="mt-4 mb-3">Belum ada donasi! :(</h3>';
								echo 'Tidak ditemukan donasi di keranjang.';
							echo '</div>';
						}
					?>

				</main><!-- #main -->

			</div><!-- #primary -->

			</div>

		</div>

	</div><!-- #content -->

</div><!-- #page-wrapper -->

<?php
get_footer();
