<?php
/**
 * The template for displaying all single posts
 *
 * @package justg
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
$container = get_theme_mod( 'justg_container_type','container' );
?>

<div class="wrapper py-5 my-5" id="single-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content" tabindex="-1">

		<div class="row">

			<div class="col-md">

				<main class="site-main col order-2 px-md-0" id="main">

					<?php
					
					while ( have_posts() ) {
						the_post();

						echo apply_filters( 'velocitytoko_content_single_product', $post );

						//START related donasi
							$idp            = get_the_ID();
							$argsrelated    = [
								'post_type'         => 'donasi',
								'post__not_in'      => [$idp],
								'posts_per_page'    => 4,
							];

							$cats       = wp_get_post_terms( get_the_ID(), 'category-product' ); 
							$cats_ids   = array();  
							foreach( $cats as $wpex_related_cat ) {
								$cats_ids[] = $wpex_related_cat->term_id; 
							}
							if ( ! empty( $cats_ids ) ) {
								$argsrelated['tax_query'] = [
									[
										'taxonomy' => 'kategori-donasi',
										'field'    => 'id',
										'terms'    => $cats_ids,
									]
								];
							}
							
							$related_query = new wp_query( $argsrelated );
							// The Loop
							if ( $related_query->have_posts() ) {
								echo '<div class="related-post-product block-primary">';
									echo '<h3 class="title-single-part">Produk Terkait</h3>';
									echo '<div class="row">';
									while ( $related_query->have_posts() ) { $related_query->the_post();
										echo apply_filters( 'velocitytoko_content_loop_related', $post );
									}
									echo '</div>';
								echo '</div>';
							}
							wp_reset_postdata();
						//END related product

						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) {

							do_action('justg_before_comments');
							comments_template();
							do_action('justg_after_comments');

						}
					}
					?>

				</main><!-- #main -->

			</div>

		</div><!-- .row -->

	</div><!-- #content -->

</div><!-- #single-wrapper -->

<?php
get_footer();