jQuery(function ($) {
    $('.modalsambutan').modal('show');
    $('[data-toggle="tooltip"]').tooltip();
    $('#data-keranjang').cardtable();


    // Perform AJAX login on form submit
    $('form#login').on('submit', function (e) {
        var idunik = $('form#login #idunik').val();
        var redirect = $('form#login #redirect').val();
        var kodecaptcha = $('form#login #kodecaptcha').val();
        var isreCAPTCHA = $('form#login #isreCAPTCHA').val();
        var grecaptchares = $('form#login #g-recaptcha-response').val();

        if (kodecaptcha == '') {
            alert('Captcha Harus Diisi');
            return false;
        } else if (kodecaptcha != idunik) {
            alert('Captcha Salah');
            location.reload();
            return false;
        }

        if (isreCAPTCHA == '1' && grecaptchares == '') {
            alert('Captcha Harus Diisi');
            return false;
        }

        $('form#login p.status').show().text('Sending user info, please wait...');
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: ajaxurl,
            data: {
                'action': 'ajaxlogin', //calls wp_ajax_nopriv_ajaxlogin
                'username': $('form#login #username').val(),
                'password': $('form#login #password').val(),
                'security': $('form#login #security').val()
            },
            success: function (data) {
                console.log(data);
                $('form#login p.status').html(data.message);
                if (data.loggedin == true) {
                    document.location.href = redirect;
                }
            }
        });

        e.preventDefault();
    });


    function convertToRupiah(angka) {
        var rupiah = '';
        var angkarev = angka.toString().split('').reverse().join('');
        for (var i = 0; i < angkarev.length; i++) if (i % 3 == 0) rupiah += angkarev.substr(i, 3) + '.';
        return 'Rp ' + rupiah.split('', rupiah.length - 1).reverse().join('');
    }
    var max = $('#hargarange').attr("max");
    var datamax = $('#hargarange').attr("data-max");
    var datamin = $('#hargarange').attr("data-min");
    $("#hargarange").slider({
        range: true,
        min: 0,
        max: max,
        values: [datamin, datamax],
        slide: function (event, ui) {
            $("#price").val(convertToRupiah(ui.values[0]) + " - " + convertToRupiah(ui.values[1]));
        }
    });
    $("#price").val(convertToRupiah($("#hargarange").slider("values", 0)) + " - " + convertToRupiah($("#hargarange").slider("values", 1)));

    checkCaptcha = function (response) {
        if (response.length !== 0) {
            $('#msgCaptcha').html('<span class="text-success"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16"> <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/> <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/> </svg> Captcha Success</span>');
        }
    };
    expiredCaptcha = function (response) {
        if (response.length !== 0) {
            $('#msgCaptcha').html('<span class="text-danger"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16"> <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/> </svg> Captcha Kadaluarsa, silahkan refresh halaman</span>');
        }
    };
    $('#btn-validate').click(function () {
        var $captcha = $('#recaptcha'),
            response = grecaptcha.getResponse();
        if (response.length === 0) {
            $('#msgCaptcha').html('<span class="text-danger"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16"> <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/> </svg> Captcha error</span>');
            return false;
        }
    });

    $('.fl-builder-pagination-load-more .fl-button-text').click(function () {
        setTimeout(function () {
            $('.lazy').lazy({
                // your configuration goes here
                effect: "fadeIn",
                effectTime: 2000,
                threshold: 0,
                onError: function (element) {
                    console.log('error loading ' + element.data('src'));
                }
            });
            $('[data-countdown]').each(function () {
                var $this = $(this), finalDate = $(this).data('countdown');
                $this.countdown(finalDate, function (event) {
                    $this.html(event.strftime('%D %H:%M:%S'));
                });
            });
        }, 3000);
    });
    $('[data-countdown]').each(function () {
        var $this = $(this), finalDate = $(this).data('countdown');
        $this.countdown(finalDate, function (event) {
            $this.html(event.strftime('%D %H:%M:%S'));
        });
    });

    $(function () {
        $('.lazy').lazy({
            // your configuration goes here
            effect: "fadeIn",
            effectTime: 2000,
            threshold: 0,
            onError: function (element) {
                console.log('error loading ' + element.data('src'));
            }
        });
    });

    $("#city-destination").chained("#prov-destination");
    $('input[name=pengiriman]').attr('checked', false);

    deleteOrder = function (elem, callback) {
        $('.perbarui .icon').html('<i class="fa fa-pulse fa-refresh"></i>');
        $('.perbarui').removeClass('bg-colortheme');
        $('.perbarui').addClass('bg-dark');
        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: { action: 'deleteorder', id: elem },
            success: function (data) {
                $('.perbarui .icon').html('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16"> <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/> <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/> </svg>');
                $("#content").load(window.location.href + " #main");
                $('#row-' + elem).remove();
                loadTableCart();
            },
        });
        if (callback) callback();
    }
    hapusSemua = function () {
        $('#hapussemua').html('<i class="fa fa-spinner fa-pulse"></i>');
        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: { action: 'kosongkankeranjang' },
            success: function (data) {
                $('#hapussemua-').html('<i class="fa fa-check-circle text-success"></i>');
                location.reload(false);
            },
        });
    }
    love = function (elem) {
        var id = elem;
        if ($('.love-' + id).hasClass("text")) {
            var pesan = '<i class="fa fa-check" aria-hidden="true"></i> Berhasil';
        } else {
            var pesan = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart-fill" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z"/> </svg>';
        }
        $('.love-' + id).html('<i class="fa fa-spinner fa-pulse"></i>');
        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: { action: 'love', idproduk: id },
            success: function (data) {
                $('.love-' + id).toggleClass('unlove');
                $('.love-' + id).html(pesan);
            },
        });
    };

    beli = function (elem) {
        var id = elem;
        var pesan1;
        var pesan2;
		var redirect = $('#redirect-'+id).val();
		var jml = $('#jumlah-'+id).val();
        var txt = $('.beli-' + id).data('text');
        if ($('.beli-' + id).hasClass("text")) {
            pesan1 = '<i class="fa fa-check" aria-hidden="true"></i> Berhasil';
            pesan2 = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-fill" viewBox="0 0 16 16"> <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/> </svg> ' + txt;
        } else {
            pesan1 = '<i class="fa fa-check" aria-hidden="true"></i>';
            pesan2 = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-fill" viewBox="0 0 16 16"> <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/> </svg> ';
        }
        $('.beli-' + id).html('<i class="fa fa-spinner fa-pulse"></i>');
            jQuery.ajax({
                type: "POST",
                url: ajaxurl,
                data: { action: 'tambahkeranjang', idproduk: id, idasli: id, jumlah: jml },
                success: function (data) {
                    $('.beli-' + id).html(pesan1);
                    setTimeout(function () {
                        $('.beli-' + id).html(pesan2);
                    }, 2000);
                    var total = Number($('.totalpembeli').text()) + 1;
                    total = data ? data : total;
                    $('.totalpembeli').html(total);
                    //loadTableCart();
                    setTimeout(function() {
                        location.href = redirect;
                    }, 1000);
                },
            });
    };

    opsistandart = function (elem) {
        var id = elem;
        var text = $('.beli-opsi-' + id).data('text');
        $('.beli-opsi-' + id).html('<i class="fa fa-spinner fa-pulse"></i>');
        var opsia = $('.opsistandart-' + id).val()
        var opsib = $('.opsiadvance-' + id).val()
        var opsi = id + opsia + opsib;
        var stok = $('#stok-' + id).val();
        if (Number(stok) < 1) {
            alert('Stok terbatas.');
            $('.beli-' + id).html('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-fill" viewBox="0 0 16 16"> <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/> </svg> ');
        } else {
            jQuery.ajax({
                type: "POST",
                url: ajaxurl,
                data: { action: 'tambahkeranjang', idproduk: opsi, onopsia: opsia, onopsib: opsib, idasli: id },
                success: function (data) {
                    $('#stok-' + id).val(Number($('#stok-' + id).val()) - 1);
                    $('.beli-opsi-' + id).html('<i class="fa fa-check-circle text-success"></i>');
                    setTimeout(function () {
                        $('.beli-opsi-' + id).html('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-fill" viewBox="0 0 16 16"> <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/> </svg> ' + text);
                    }, 2000);
                    $('.totalpembeli').html(Number($('.totalpembeli').text()) + 1);
                    loadTableCart();
                },
            });
        }
    };

    belix = function (elem) {
        var id = elem;
        if ($('.beli-x-' + id).hasClass("text")) {
            var pesan1 = '<span class="text-danger"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16"> <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/> </svg></span> Gagal';
            var pesan2 = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-fill" viewBox="0 0 16 16"> <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/> </svg> Beli';
        } else {
            var pesan1 = '<span class="text-danger"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16"> <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/> </svg></span>';
            var pesan2 = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-fill" viewBox="0 0 16 16"> <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/> </svg> ';
        }
        $('.beli-x-' + id).html('<i class="fa fa-spinner fa-pulse"></i>');
        setTimeout(function () {
            $('.beli-x-' + id).html(pesan1);
        }, 1000);
        setTimeout(function () {
            $('.beli-x-' + id).html(pesan2);
        }, 4000);
    };

    function rupiah(total) {
        var bilangan = total;

        var number_string = bilangan.toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{1,3}/gi);

        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return rupiah
    }

    function city(callback) {
        $('.ongkir').html('<span class="text-danger">Loading <i class="fa fa-spinner fa-pulse"></i></span>');
        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: { action: 'kecamatan', city_destination: $("#city-destination").val() },
            success: function (data) {
                $('.ongkir').html('Tentukan Alamat');
                $('#subdistrict-destination').html(data);
            },
        });
        if (callback) callback();
    }

    function cekOngkirval() {
        if ($('.pilihongkir').val() == 'COD -  - 0') {
            $('.tf-bayar').hide();
            $('.cod-bayar').show();
        } else {
            $('.tf-bayar').show();
            $('.cod-bayar').hide();
        }
    }
    cekOngkirval();
    $(document).on('change', '.pilihongkir', function () {
        cekOngkirval();
    });

    function ongkir(callback) {
        if ($('.ongkir').length !== 0) {
            $('.ongkir').html('<span class="text-danger">Loading <i class="fa fa-spinner fa-pulse"></i></span>');
            var potongkir = $(".potonganongkir").val();
            var brtotal = $(".totalberat").text();
            jQuery.ajax({
                type: "POST",
                url: ajaxurl,
                data: { action: 'ongkir', destination: $("#subdistrict-destination").val(), berattotal: brtotal, potongongkir: potongkir },
                success: function (data) {
                    $('.ongkir').html(data);
                    var pilongkir = $(".pilihongkir").val();
                    var ongkir = Number(pilongkir.split('-')[2]);
                    var harga = Number($(".subhargatotal").val());
                    var total = ongkir + harga;

                    $('.nilaiongkir').val(ongkir);
                    $('.total').html(rupiah(total));
                    $('.hargatotal').val(total);
                    if ($('.pilihongkir').val() == 'COD -  - 0') {
                        $('.tf-bayar').hide();
                        $('.cod-bayar').show();
                    } else {
                        $('.tf-bayar').show();
                        $('.cod-bayar').hide();
                    }
                },
            });
        }
        if (callback) callback();
    }
    function ongkiradmin(callback) {
        $('.ongkir').html('<span class="text-danger">Loading <i class="fa fa-spinner fa-pulse"></i></span>');
        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: { action: 'ongkir', berattotal: $(".totalberat").text(), potongongkir: $(".potonganongkir").val() },
            success: function (data) {
                $('.ongkir').html(data);
                var ongkir = Number($(".pilihongkir").val().split('-')[2]);
                var harga = Number($(".subhargatotal").val());
                var total = ongkir + harga;
                $('.total').html(rupiah(total));
                $('.hargatotal').val(total);
                $('.nilaiongkir').val(ongkir);
            },
        });
        if (callback) callback();
    }
    $(document).on('change', '#opsistandart', function () {
        var opsi = $(this).val();
    });

    $(document).on('change', '.jumlah', function () {
        var id = $(this).attr("id");
        var min = $(this).attr("min");
        var jumlah = $(this).val();
        // alert('jumlah:'+jumlah +'>= minimal:'+ min);
        if (Number(jumlah) < Number(min)) {
            jumlah = min;
            // alert(jumlah);
        }
        $('.perbarui .icon').html('<i class="fa fa-pulse fa-refresh"></i>');
        $('.perbarui').removeClass('bg-colortheme');
        $('.perbarui').addClass('bg-dark');
        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: { action: 'modifkeranjang', id: id, jumlah: jumlah },
            success: function (data) {
                // alert(min);
                $('.perbarui .icon').html('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16"> <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/> <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/> </svg>');
                $("#content").load(window.location.href + " #main");
                $('.totalpembeli').html(data);
                loadTableCart();
            },
        });
    });

    $('#toggleyes').click(function () {
        $(".ifno").css("display", "none");
        $("input[type=submit]").removeAttr('disabled');
        $('.opsitoggle').removeClass("toogleaktif");
        $(this).addClass("toogleaktif");
        $('.datapengiriman').removeAttr('required');
        ongkiradmin();
    });
    $('#toggleno').click(function () {
        $(".ifno").css("display", "block");
        $("input[type=submit]").removeAttr('disabled');
        $('.opsitoggle').removeClass("toogleaktif");
        $(this).addClass("toogleaktif");
        $(".datapengiriman").attr('required', '');
    });
    $('#city-destination').on('change', function () {
        city();
    });
    $('#subdistrict-destination').on('change', function () {
        ongkir();
    });
    $(document).on('change', '.pilihongkir', function () {
        var ongkir = Number($(this).val().split('-')[2]);
        // alert($(this).val().split('-')[2]);
        var harga = Number($(".subhargatotal").val());
        var total = ongkir + harga;
        $('.total').html(rupiah(total));
        $('.hargatotal').val(total);
        $('.nilaiongkir').val(ongkir);
    });

    $(document).on('click', '#hapus-kupon', function () {
        $('#hapus-kupon').tooltip('hide');
        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: { action: 'hapuskupon' },
            success: function (data) {
                $("#content").load(window.location.href + " #main");
            },
        });
    });
    $(document).on('click', '#apply-kupon', function () {
        var kupon = $('#kodekupon').val();
        var dibayar = $('#dibayar').val();
        if (kupon == '') {
            $('#pesankupon').html('<span class="alert alert-danger alert-dismissible fade show">Maaf, Kode Promo Belum Dimasukkan!</span>');
        } else {
            jQuery.ajax({
                type: "POST",
                url: ajaxurl,
                data: { action: 'pakaikupon', kode: kupon, bayar: dibayar },
                success: function (data) {
                    $('#pesankupon').html(data);
                },
            });
        }
    });

    printArea = function (elem) {
        $("#" + elem).printArea({
            mode: "iframe"
        });
    }

    /* Cek Ongkir */

    $(document).on('click', '#cek-ongkir', function () {
        var msg = [];
        var checked = 0;
        var grespon = $('.table-cekongkir .g-recaptcha #g-recaptcha-response').val();
        var destin = $('#subdistrict-destination').val();
        var berat = $('#totalberat').val();
        if ($('.table-cekongkir .g-recaptcha').length !== 0) {
            if (grespon) {
                checked = 1;
            } else {
                msg.push('Silahkan konfirmasi captcha');
            }
        } else {
            checked = 1;
        }
        if (checked > 0) {
            $('.hasilongkir').html('<span class="text-success">Loading <i class="fa fa-spinner fa-pulse"></i></span>');
            jQuery.ajax({
                type: "POST",
                url: ajaxurl,
                data: {
                    action: 'cekongkir',
                    destination: destin,
                    berattotal: berat,
                    potongongkir: $(".potonganongkir").val()
                },
                success: function (data) {
                    $('.hasilongkir').html(data);
                },
            });
        } else {
            $('.hasilongkir').html('<div class="alert alert-warning">' + msg.join(" and ") + '</div>');
        }
    });

    /* End Cek Ongkir */

    $(document).on('click', '.toggle-tablecart', function () {
        $("#cart .table-cart").toggle(500);
    });

    function loadTableCart() {
        if ($("#cart .table-cart .card-table-cart").length !== 0) {
            $(".card-table-cart").addClass('refreshtable');
            jQuery.ajax({
                type: "POST",
                url: ajaxurl,
                data: { action: 'displaytablecart' },
                success: function (data) {
                    $("#cart .table-cart").html(data);
                    $(".card-table-cart").removeClass('refreshtable');
                },
            });
        }
    }

});
