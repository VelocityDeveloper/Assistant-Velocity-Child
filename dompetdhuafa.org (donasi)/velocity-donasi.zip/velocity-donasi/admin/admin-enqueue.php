<?php
/**
 * Velocity Toko
 */
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Register admin css.
 */
function vsstemmart_addon_admin_scripts($hook) {
    $page = isset($_GET['page']) ? $_GET['page'] : '';    
    if ($page == 'dataorder' || $page == 'kuponmanage' || $page == 'laporan' || $page == 'import-produk' || $page == 'fiturtoko' || $page == 'ongkir') {
        wp_enqueue_style( 'bootstrap-styles', VELOCITY_TOKO_PLUGIN_URL. 'public/css/theme.min.css');

        wp_enqueue_script( array( 'jquery','jquery-ui-datepicker','jquery-ui-tooltip' ) );
        wp_enqueue_script( 'velocitytoko-admin-script', VELOCITY_TOKO_PLUGIN_URL . 'admin/js/admin.js');
    
        wp_enqueue_style( 'jquery-ui-styles', VELOCITY_TOKO_PLUGIN_URL . 'admin/css/jquery-ui.min.css');
    }
    wp_enqueue_style( 'velocitytoko-admin-styles', VELOCITY_TOKO_PLUGIN_URL . 'admin/css/admin.css');
}
add_action( 'admin_enqueue_scripts', 'vsstemmart_addon_admin_scripts' );