<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
global $wpdb;
global $post;
$table_kupon    = $wpdb->prefix . "order"; 
$details        = $wpdb->get_results("SELECT * FROM $table_kupon ORDER BY id DESC");
$namatoko       = get_bloginfo('name');
$alamattoko     = velocitytoko_option('city_origin');
$hptoko         = velocitytoko_option('notlp_velocitytoko');
$alamattoko     = getSingleCity($alamattoko)[0]['city_name'];
$pilihanstatus  = array('Donasi Baru', 'Sukses', 'Gagal', 'Refund');
$pilihankurir   = list_velocitytoko_courier();
$getorder       = isset($_GET['order'])?$_GET['order']:'';

echo '<div class="container mt-3 pl-0 ">';
echo '<div class="card-header bg-gradient2 text-white">';
    echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-graph-up" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M0 0h1v15h15v1H0V0Zm14.817 3.113a.5.5 0 0 1 .07.704l-4.5 5.5a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61 4.15-5.073a.5.5 0 0 1 .704-.07Z"/> </svg>  Manajemen Donasi';
echo '</div>';
if($details){
	echo '<table class="table"><tbody>';
	echo '<thead class="thead-light">';
    echo '<tr><th >Invoice</th><th >Tanggal</th><th >Total</th><th >Status</th><th >Tindakan</th></tr>';
    echo '</thead>';
    
    foreach($details as $detail){
        $user_id        = $detail->id_pembeli;
        $user_info      = get_userdata($user_id);
		$gethp          = get_user_meta( $user_id, 'nohp', true );
        $produk         = json_decode($detail->detail,true);
        $status         = $detail->status;
        $kurir          = $detail->kurir;
        $prininvoiceid  = "'printinvoice-$detail->id'";
        $idbeli         = "'$detail->id'";
        $hp             = isset($produk['hp'])? $produk['hp'] : '';
        $nama           = isset($produk['nama'])? $produk['nama'] : '';
        $email          = isset($produk['email'])? $produk['email'] : '';
        $alamat         = isset($produk['alamat'])? $produk['alamat'] : '';
        $kodepos        = isset($produk['kodepos'])? $produk['kodepos'] : '';
        $catatan        = isset($produk['catatan'])? $produk['catatan'] : '';
        $invoice        = isset($produk['invoice'])? $produk['invoice'] : '';
        $pembayaran     = isset($produk['pembayaran'])?$produk['pembayaran'] : '';
        $dropship       = isset($produk['dropship'])?$produk['dropship'] : '';
        $hargatotal     = isset($produk['produk']['hargatotal'])? $produk['produk']['hargatotal'] : '';
        $kodekupon      = isset($produk['produk']['kupon']['kode'])? $produk['produk']['kupon']['kode'] : '';
        $potongankupon  = isset($produk['produk']['kupon']['potongan'])? $produk['produk']['kupon']['potongan'] : '';
        $jeniskupon     = isset($produk['produk']['kupon']['jenis'])? $produk['produk']['kupon']['jenis'] : '';
        
        
        if($user_id){
            $hp             = get_user_meta( $user_id, 'hp',true );
            $nama           = get_user_meta( $user_id, 'nama',true );
            $alamat         = get_user_meta( $user_id, 'alamat',true );
            $kodepos        = get_user_meta( $user_id, 'kodepos',true );
            $email          = isset($user_info->user_email)?$user_info->user_email:'';
        }
        
        require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/profile-part-penerima.php';
        require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/profile-part-produk.php';
        
        $hapusorder      = '<strong>Hapus Order</strong>';
        $hapusorder     .= '<p>Anda yakin ingin menghapus Order ini?</p>';
        $hapusorder     .= '<a title="Hapus Order" id="'.$detail->id.'" class="btn-sm mx-1 lanjuthapus btn btn-danger text-white"><span class="loadinghapus-'.$detail->id.'"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16"> <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/> <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/> </svg></span> Hapus</a>';
        
        $printpenerima = '<p><table class="table-sm table table-borderless">';
        $printpenerima .= '<tr><td>Nama</td><td>: '.$nama.'</td></tr>';
        $printpenerima .= '<tr><td>HP</td><td>: '.$hp.'</td></tr>';
        if(!empty($alamat)){
            $printpenerima .= '<tr><td>Alamat</td><td>: '.$alamat.'</td></tr>';
        }
        $printpenerima .= '</table></p>';
        
        $printpengirim = '<p><table class="table-sm table table-borderless">';
        $printpengirim .= '<tr><td>'.$namatoko.'</td></tr>';
        $printpengirim .= '<tr><td>'.$hptoko.'</td></tr>';
        $printpengirim .= '</table></p>';
        
        $detailkontak  = '<strong>Detail Kontak</strong>';
        $detailkontak .= '<p><table class="table-sm table table-borderless">';
        $detailkontak .= '<tr><td>No HP</td><td>: '.$hp.'</td></tr>';
        if(!empty($email)){
            $detailkontak .= '<tr><td>Email</td><td>: '.$email.'</td></tr>';
        } if(!empty($catatan)){
            $detailkontak .= '<tr><td>Catatan</td><td>: '.$catatan.'</td></tr>';
        }
        $detailkontak .= '</table></p>';
        
        $updatedata      = '<div class="container p-0">';
            $updatedata     .= '<p><b>Tindakan <span id="info-'.$detail->id.'"></span></b></p>';
            $updatedata     .= '<div class="input-group input-group-sm mb-3">';
            $updatedata     .= '<div class="input-group-prepend">';
            $updatedata     .= '<span class="input-group-text" id="inputGroup-sizing-sm">Ganti Status</span>';
            $updatedata     .= '</div>';
            $updatedata     .= '<select id="status-'.$detail->id.'" name="status" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">';
            foreach ($pilihanstatus as $pilihstatus){
                if($pilihstatus == $status){
                    $selected = 'selected';
                } else {
                    $selected = '';
                }
                $updatedata     .= '<option '.$selected.' value="'.$pilihstatus.'">'.$pilihstatus.'</option>';
            }
            $updatedata     .= '<select></div>';
            
    		$updatedata     .= '<div class="input-group input-group-sm mb-3">';
            $updatedata     .= '<div class="input-group-prepend">';
            $updatedata     .= '<span class="input-group-text" id="inputGroup-sizing-sm">Kirim Email</span>';
            $updatedata     .= '</div>';
            $updatedata     .= '<select id="kirim-'.$detail->id.'" name="kirim" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">';
            $updatedata     .= '<option value="yes">Yes</option>';
            $updatedata     .= '<option value="no">No</option>';
            $updatedata     .= '<select>';
            $updatedata     .= '</div>';
            
            $updatedata     .= '<a class="btn-sm btn btn-primary text-light" onclick="saveData('.$idbeli.')"><i class="fa fa-floppy-o" aria-hidden="true"></i> Simpan</a>';
        $updatedata     .= '</div>';

        echo '<tr class="row-'.$detail->id.'">';
            echo '<td><strong>#'.$detail->invoice.'</strong></td>';
            echo '<td>'.$detail->date.'</td>';
            echo '<td>'.vsstemmart_number_money($hargatotal).'</td>';
            echo '<td><span class="btn-sm btn btn-secondary">'.$status.'</span>'.$dropship.'</td>';
            echo '<td>';
                echo '<a title="Lihat Detail" id="'.$detail->id.'" class="btn-sm mx-1 detail btn btn bg-gradient text-light"><svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16"> <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/> <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/> </svg> </a>';
                echo '<a title="Tindakan" id="'.$detail->id.'" class="btn-sm mx-1 tindakan btn btn bg-gradient text-light"><i class="fa fa-cog" aria-hidden="true"></i></a>';
                echo '<a title="Hapus Order" id="'.$detail->id.'" class="btn-sm mx-1 hapus btn bg-gradient2 text-light"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16"> <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/> <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/> </svg></a>';
            echo '</td>';
        echo '</tr>';
        
        echo '<tr class="row-'.$detail->id.' hapus open hapus-'.$detail->id.'">';
            echo '<td colspan="5">';
                echo $hapusorder;
            echo '</td>';
        echo '</tr>';

        echo '<tr class="row-'.$detail->id.' tindakan open tindakan-'.$detail->id.'">';
            echo '<td colspan="5">';
                echo $updatedata;
            echo '</td>';
        echo '</tr>';
        
        echo '<tr class="row-'.$detail->id.' datail-order open expand-'.$detail->id.'">';
            echo '<td colspan="5">';
                echo '<div class="row">';
                    echo '<div class="col-md-6">';
                        echo '<div class="row">';
                            echo '<div class="col-md-5">'.$detailpenerima.'</div>';
                            echo '<div class="col-md-7">'.$detailkontak.'</div>';
                    echo '</div>';
                        echo '<a class="btn-sm btn bg-gradient text-light" onclick="printArea('.$prininvoiceid.')"><i class="fa fa-print" aria-hidden="true"></i> Print Invoice</a>';
                    echo '</div>';
                    echo '<div class="col-md-6">'.$detailproduk.'</div>';
                echo '</div>';
                
                echo '<div class="print-none" id="printinvoice-'.$detail->id.'">';
                    echo '<table class="table" style="border:2px solid #333; padding:15px; width:100%;"><tbody>';
                        echo '<tr >';
                            echo '<td colspan="2" style="border-bottom:2px solid #333;padding:20px 0 20px 0;"><b>Invoice: #'.$invoice.'</b></td>';
                        echo '</tr>';
                        echo '<tr>';
                            echo '<td style="padding-top:20px" valign="top">'.$printpenerima.'</td>';
                            echo '<td style="padding-top:20px" valign="top">'.$printpengirim.'</td>';
                        echo '</tr>';
                        echo '<tr>';
                            echo '<td colspan="2" style="padding-top:30px">';
                                echo $detailproduk;
                            echo '</td>';
                        echo '</tr>';
                        echo '<tr>';
                            echo '<td colspan="2" style="padding-top:30px">';
                                echo '<h3>Pembayaran</h3>';
                                echo do_shortcode('[bank]');
                            echo '</td>';
                        echo '</tr>';
                    echo '</tbody></table>';
                echo '</div>';

                //echo '<pre>'.print_r($produk,1).'</pre>';
            echo '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
}
echo '</div>';