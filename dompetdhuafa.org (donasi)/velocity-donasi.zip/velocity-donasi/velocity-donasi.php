<?php
/**
 * The plugin Donasi for Velocity Developer
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://github.com/velocitydeveloper/velocity_toko
 * @since             1.1.5
 * @package           velocity_donasi
 *
 * @wordpress-plugin
 * Plugin Name:       Velocity Donasi
 * Plugin URI:        https://velocitydeveloper.com/
 * Description:       Plugin Donasi by Velocity Developer
 * Version:           1.1.5
 * Author:            Velocity Developer
 * Author URI:        https://velocitydeveloper.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       velocity-donasi
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define constants
 *
 * @since 1.1.3
 */
if ( ! defined( 'VELOCITY_TOKO_VERSION' ) )		define( 'VELOCITY_TOKO_VERSION'		, '1.1.5' ); // Plugin version constant
if ( ! defined( 'VELOCITY_TOKO_PLUGIN' ) )		define( 'VELOCITY_TOKO_PLUGIN'		, trim( dirname( plugin_basename( __FILE__ ) ), '/' ) ); // Name of the plugin folder eg - 'velocity-toko'
if ( ! defined( 'VELOCITY_TOKO_PLUGIN_DIR' ) )	define( 'VELOCITY_TOKO_PLUGIN_DIR'	, plugin_dir_path( __FILE__ ) ); // Plugin directory absolute path with the trailing slash. Useful for using with includes eg - /var/www/html/wp-content/plugins/velocity-toko/
if ( ! defined( 'VELOCITY_TOKO_PLUGIN_URL' ) )	define( 'VELOCITY_TOKO_PLUGIN_URL'	, plugin_dir_url( __FILE__ ) ); // URL to the plugin folder with the trailing slash. Useful for referencing src eg - http://localhost/wp/wp-content/plugins/velocity-toko/

// Load everything
$includes = [
    'inc/donasi.php',                                                    				// Function tambahan untuk sistem donasi
    'inc/lib/CMB2/init.php',                                                    		// Libary Custom Meta Box 
    'inc/lib/aq-resize/aq-resize.php',                                                  // Libary Aq_resize
    'inc/classes/Lokasi.php',				                                            // Class Lokasi
	'inc/classes/Keranjang.php',				                                            // Class Cart
	'inc/post-product.php',				                                           		// Post Product
	'inc/post-product-metabox.php',				                                        // Post Product metabox
	'inc/ongkir.php',				                                                    // Ongkir function
	'inc/lokasi.php',				                                                    // get Lokasi function
	'inc/kirki.php',				                                                    // Kirki customizer for options
	'inc/velocitytoko-option.php',				                                        // velocitytoko_option function
	'inc/store.php',				                                                    // Store function
	'inc/shortcode.php',				                                                // Shortcode function
	'inc/ajax.php',				                                                		// Ajax function
	'admin/admin-page.php',				                                                // Admin Page Register
    'admin/admin-enqueue.php',                                                          // Admin Register enqueue
    'admin/register-page.php',                                                          // Admin Register page default
	'inc/enqueue.php',				                                                	// enqueue function
	'inc/product-templates.php',				                                        // product-templates function
	'inc/pagination.php',				                                        		// pagination function
	'inc/templates-hooks.php',				                                        	// templates-hooks function
	'inc/filter-query.php',				                                        		// filter query function
	'custom/functions.php',				                                        		// custom functions
 ];
foreach( $includes as $include ) {
    require_once( VELOCITY_TOKO_PLUGIN_DIR . $include );
}

function get_velocitytoko_part($path=null){

	if(empty($path))
	return false;

	include ( VELOCITY_TOKO_PLUGIN_DIR . $path.'.php' );
}

/**
 * The code that runs during plugin activation.
 * This action is documented in inc/classes/class-velocity-toko-activator.php
 */
function activate_velocity_toko() {
	require_once VELOCITY_TOKO_PLUGIN_DIR . 'inc/classes/class-velocity-toko-activator.php';
	Velocity_Toko_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in inc/classes/class-velocity-toko-deactivator.php
 */
function deactivate_velocity_toko() {
	require_once VELOCITY_TOKO_PLUGIN_DIR . 'inc/classes/class-velocity-toko-deactivator.php';
	Velocity_Toko_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_velocity_toko' );
register_deactivation_hook( __FILE__, 'deactivate_velocity_toko' );



function vsstemmart_modul() {
	if ( class_exists( 'FLBuilder' ) ) {
	  //get_template_part('inc/modul/categories-carousel/categories-carousel');
      require_once( VELOCITY_TOKO_PLUGIN_DIR . 'inc/modul/image-carousel/image-carousel.php' );
	}
}
add_action( 'init', 'vsstemmart_modul' );
