<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
global $wpdb;

$date                       = date("d-m-Y h:i:s");
$data                       = json_encode($_POST);
$table_order                = $wpdb->prefix . "order";  
$table_cart                 = $wpdb->prefix . "keranjang";  
$user_id                    = get_current_user_id();
$user_info                  = get_userdata($user_id);
$namatoko                   = get_bloginfo('name');

$emailtoko                  = velocitytoko_option('emailadmin',get_bloginfo('admin_email')); 
$paypalopt                  = velocitytoko_option('paypalopt');
$paypalmode                 = velocitytoko_option('paypaltype');
$paypalclientid             = velocitytoko_option('paypal');
$sitekey                    = velocitytoko_option('sitekey_recaptcha_velocitytoko');
$secret                     = velocitytoko_option('secret_recaptcha_velocitytoko');
$smspembeli                 = velocitytoko_option('smspembeli','off');
$smspenjual                 = velocitytoko_option('smspenjual','off');
$nosms                      = velocitytoko_option('nosms_velocitytoko');

$hp                         = isset($_POST['hp'])? $_POST['hp'] : '';
$nama                       = isset($_POST['nama'])? $_POST['nama'] : '';
$token                      = isset($_POST['token'])? $_POST['token'] : '';
$email                      = isset($_POST['email'])? $_POST['email'] : '';
$alamat                     = isset($_POST['alamat'])? $_POST['alamat'] : '';
$invoice                    = isset($_POST['invoice'])? $_POST['invoice'] : '';
$pembayaran                 = isset($_POST['pembayaran'])? $_POST['pembayaran'] : '';
$jeniskupon                 = isset($_POST['produk']['kupon']['jenis'])? $_POST['produk']['kupon']['jenis'] : '';
$kodekupon                  = isset($_POST['produk']['kupon']['kode'])? $_POST['produk']['kupon']['kode'] : '';
$potongankupon              = isset($_POST['produk']['kupon']['potongan'])? $_POST['produk']['kupon']['potongan'] : '';
$hargatotal                 = isset($_POST['produk']['hargatotal'])? vsstemmart_number_money($_POST['produk']['hargatotal']) : '';
$hargatotaldolar            = isset($_POST['produk']['hargatotal'])? $_POST['produk']['hargatotal'] : '';
$norek                      = do_shortcode('[bank]');
$secretKey                  = $secret;
$captcha                    = isset($_POST['g-recaptcha-response'])? $_POST['g-recaptcha-response'] : '';
$ip                         = $_SERVER['REMOTE_ADDR'];
$response                   = wp_remote_get("https://www.google.com/recaptcha/api/siteverify?secret=".$secretKey."&response=".$captcha."&remoteip=".$ip);
if($response){
    $responseKeys           = json_decode($response['body'],true);
}
if($sitekey && $secret && $responseKeys){
    if(intval($responseKeys["success"]) === 1){
        $antispam = 'true';
    } else {
        $antispam = 'false';
    }
} else if($token == $_SESSION['token']){
    $antispam = 'true';
} else {
    $antispam = 'false';
}
    
if(is_user_logged_in()){
    update_user_meta( $user_id, 'nama', $nama );
    update_user_meta( $user_id, 'hp', $hp );
    update_user_meta( $user_id, 'alamat', $alamat );
    $nama       = get_user_meta( $user_id, 'nama',true );
    $alamat     = get_user_meta( $user_id, 'alamat',true );
    $email      = $user_info->user_email;
}


if( $antispam == 'true' && isset($_POST['pembayaran']) ){
    
    $wpdb->insert($table_order, array(
        'id_pembeli'            => $user_id,
        'invoice'               => $invoice,
        'date'                  => $date,
        'detail'                => $data,
        'status'                => 'Donasi Baru',
    ));

    // Reset Keranjang    
    $Cart = new Vsstemmart\Keranjang;
    $Cart->reset();

    // session_destroy();
    unset($_SESSION['token']);
    unset($_SESSION['kupon']);
    
    $dataproducts = isset($_POST['produk']['products'])?$_POST['produk']['products']:[];  
    foreach($dataproducts as $product){
        $jumlahstock    = get_post_meta($product['id'], 'stok', true);
        $jumlahdibeli   = isset($product['jumlah'])?$product['jumlah']:'';
        if($jumlahstock != '' && $jumlahstock != '0'){
            $stokbaru   = $jumlahstock - $jumlahdibeli;
            update_post_meta( $product['id'], 'stok', $stokbaru );
        }
    }
    
    if($pembayaran=='bank'){
        require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/payment-bank.php';
    } else if ($pembayaran=='paypal') {
        require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/payment-paypal.php';
    }
    
    if($smspembeli == 'on' && $hp){
        $body = 'Terimakasih '.$nama.' telah melakukan berdonasi di '.$namatoko.', untuk melihat detail donasi anda silahkan klik '.get_permalink( get_page_by_path( 'myaccount' ) ).'?invoice='.$invoice;
        kirimSMS($hp, $body);
        kirimwhatsapp($hp, $body);
    }
    if($smspenjual == 'on' && $nosms){
        $body = 'Ada Donasi Masuk di '.$namatoko.' dengan kode invoice: '.$invoice;
        kirimSMS($nosms, $body);
        kirimwhatsapp($nosms, $body);
    }
    
    require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/email-admin.php';
    if(!empty($email)){
        require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/email-pembeli.php';
    }
    
} else {
    echo '<div class="text-center">';
	    echo '<i style="font-size: 60px" class="fa fa-shopping-cart" aria-hidden="true"></i>';
	    echo '<h3 class="mt-4 mb-3 display-1">Gagal Mengajukan Donasi! :(</h3>';
	    echo 'Klik <strong><a href="?action=checkout">disini</a></strong> untuk mengirim ulang.';
    echo '</div>';
}
