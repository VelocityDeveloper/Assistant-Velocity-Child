<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
        $detailproduk  = '<strong>Detail Donasi</strong>';
            $detailproduk .= '<div style="width:100%;overflow-x:auto;">';
            $detailproduk .= '<table class="table table-striped" style="width: 100%;"><tbody>';
            $detailproduk .= '<thead><tr><td >Nama Donasi</td><td >Biaya</td><td >Kuantitas</td><td style="padding: 5px 10px;text-align: right;">Sub Total</td></tr></thead>';
                
                // for old structure
                $dataprodukOld = [];
                if(!isset($produk['produk']['products'])) {
                    $dataprodukOld = $produk['produk'];
                    unset($dataprodukOld['berattotal']);
                    unset($dataprodukOld['kupon']);
                    unset($dataprodukOld['subhargatotal']);
                    unset($dataprodukOld['hargatotal']);
                    unset($dataprodukOld['potongan-ongkir']);
                }

                $dataproducts = isset($produk['produk']['products'])?$produk['produk']['products']:$dataprodukOld;        
                foreach($dataproducts as $product){

                    $detailproduk .= '<tr>';
                        $detailproduk .= '<td>';
                            $detailproduk .= $product['nama'];
                            $detailproduk .= isset($product['isiopsi'])?'<br>'.$product['isiopsi']:'';
                        $detailproduk .= '</td>';
                        $detailproduk .= '<td>';
                            $detailproduk .= vsstemmart_number_money($product['harga']);
                            if(isset($product['hargaasli']) && $product['hargaasli'] > 0) {
                                $detailproduk .= '<br><small><s>'.vsstemmart_number_money($product['hargaasli']).'</s></small>';
                            }
                        $detailproduk .= '</td>';
                        $detailproduk .= '<td >';
                            $detailproduk .= $product['jumlah'];
                        $detailproduk .= '</td>';
                        $detailproduk .= '<td class="text-end" style="text-align: right">';
                            $detailproduk .= '<span class="subtotal" >'.vsstemmart_number_money($product['harga']*$product['jumlah']).'</span><br>';
                            $detailproduk .= '<small>'.$product['jumlah'].' x '.vsstemmart_number_money($product['harga']);
                        $detailproduk .= '</td>';
                    $detailproduk .= '</tr>';

                }

                $detailproduk .= '<tr >';
                    $detailproduk .= '<td colspan="3">Pembayaran</td>';
                    $detailproduk .= '<td style="border-top:1px solid #ddd;text-align: right;padding:5px 10px;">';
                        $detailproduk .= strtoupper($pembayaran);
                    $detailproduk .= '</td>';
                $detailproduk .= '</tr>';
                $detailproduk .= '<tr >';
                    $detailproduk .= '<td colspan="2" style="border-top:1px solid #ddd;padding:5px 10px;"><strong>Total Transfer</strong></td>';
                    $detailproduk .= '<td colspan="2" style="border-top:1px solid #ddd;text-align: right;padding:5px 10px;">';
                            $detailproduk .= '<strong>'.vsstemmart_number_money($hargatotal).'</strong>';
                        if($jeniskupon == 'percent'){
                            $total  = $hargatotal-($hargatotal*$potongankupon/100);
                            $detailproduk .= '<div><small>Menggunakan Kode Promo= <b>'.$kodekupon.'</b><br>* Mendapat Potongan '.vsstemmart_number_money($total).' </small> ( '.$potongankupon.'% )</div>';
                        } else if($jeniskupon == 'ongkir'){
                            $detailproduk .= '<div><small>Menggunakan Kode Promo= <b>'.$kodekupon.'</b><br>* Ongkir Sudah Dipotong '.vsstemmart_number_money($potongankupon).' </small></div>';
                        } else if($jeniskupon == 'rupiah'){
                            $detailproduk .= '<div><small>Menggunakan Kode Promo= <b>'.$kodekupon.'</b><br>* Mendapat Potongan '.vsstemmart_number_money($potongankupon).' </small></div>';
                        }
                    $detailproduk .= '</td>';
                $detailproduk .= '</tr>';
                    
            $detailproduk .= '</tbody></table>';
        $detailproduk .= '</div>';