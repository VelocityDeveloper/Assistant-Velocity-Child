<?php
$user_id    = get_current_user_id();
$chars      = 'abcdefghijklmnopqrstuvwxyz';
$uniqsess   = uniqid().substr(str_shuffle($chars), 0, 5);

//session
if(!isset($_SESSION['uniqsess'])) {
    $_SESSION['uniqsess'] = $uniqsess;
}

//input form
if(isset($_POST['uniqsess']) && ($_POST['uniqsess'] == $_SESSION['uniqsess'])) {
    
    //update meta user
    update_user_meta( $user_id, 'nama', $_POST['nama'] );
    update_user_meta( $user_id, 'hp', $_POST['hp'] );
    update_user_meta( $user_id, 'alamat', $_POST['alamat'] );
    
    ///alert success
    echo '<div class="alert alert-success my-2">Data anda berhasil diupdate</div>';
    
    $_SESSION['uniqsess'] = $uniqsess;
}


$nama       = get_user_meta( $user_id, 'nama',true )?get_user_meta( $user_id, 'nama',true ):'';
$hp         = get_user_meta( $user_id, 'hp',true )?get_user_meta( $user_id, 'hp',true ):'';
$alamate    = get_user_meta( $user_id, 'alamat',true )?get_user_meta( $user_id, 'alamat',true ):'';
// print_r($alamat);
?>

<div class="container mb-3 pt-3">
    
    <form action="" method="POST">
        <div class="card">
            <div class="card-header d-flex mx-0 align-items-center bg-secondary text-white">
                <i class="fa fa-user-circle me-1"></i> Profile
            </div>
            <div class="card-body">
                <div class="form-group mb-3">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" name="nama" placeholder="Nama anda" value="<?php echo $nama; ?>">
                </div>
                <div class="form-group mb-3">
                    <label for="hp">No HP</label>
                    <input type="text" class="form-control" name="hp" placeholder="Nomor telepon" value="<?php echo $hp; ?>">
                </div>
                <div class="form-group mb-3">
                    <label for="alamat">Alamat</label>
                    <textarea class="form-control" name="alamat" placeholder="Detail alamat anda"><?php echo $alamate; ?></textarea>
                </div>
                <div class="text-end">
                    <button type="submit" class="btn btn-dark">Simpan</button>
                </div>
                <input type="hidden" name="uniqsess" value="<?php echo $_SESSION['uniqsess']; ?>">
            </div>
        </div>
    </form>
    
</div>