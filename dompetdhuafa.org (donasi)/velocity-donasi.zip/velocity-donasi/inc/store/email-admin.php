<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/email-part-produk.php';
require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/email-part-pemesan.php';

$adminemail = velocitytoko_option('adminemail');

$head = '<h3 style="font-size: 18px;color: #fff;text-transform: uppercase;background-color: #c4527c;padding: 5px;">'.$namatoko.' Invoice #'.$invoice.'</h3>';
$body = '<div style="margin:0 auto;max-width:600px;border: 1px solid #ddd;padding:15px;">'.$head.''.$adminemail.'</div>';
$body = str_replace('[nama-donatur]',$nama,$body);
$body = str_replace('[nama-web]',$namatoko,$body);
$body = str_replace('[kode-donasi]',$invoice,$body);
$body = str_replace('[detail-donasi]',$detailproduk,$body);
$body = str_replace('[data-donatur]',$pemesan,$body);
$body = str_replace('[tanggal-donasi]',$date,$body);
if(!empty($email)){
    $body = str_replace('[email-donatur]',$email,$body);
}

$urlweb     = parse_url(get_site_url());
$emailweb   = 'admin@'.$urlweb['host'];

///set header Email
$headers   = [];
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=utf-8';
// Additional headers
//$headers[] = 'To: '.$namatoko.' <'.$emailtoko.'>';
$headers[] = 'From: '.$namatoko.' <'.$emailweb.'>';
// $headers[] = 'Cc: '.$emailweb.'';
// $headers[] = 'Bcc: '.$emailweb.''; 
//subject Email
$subject = 'Hallo! Ada Donasi Baru! Invoice #'.$invoice;

//kirim ke admin 
$sendhtml = wp_mail( $emailtoko, $subject, $body, implode("\r\n", $headers) );

//jika gagal kirim karena HTML, hapus HTML tag
if(!$sendhtml) {
    $headers = 'From: '.$namatoko.' <'.$emailweb.'>';
    wp_mail( $emailtoko, $subject, $body, $headers );
}