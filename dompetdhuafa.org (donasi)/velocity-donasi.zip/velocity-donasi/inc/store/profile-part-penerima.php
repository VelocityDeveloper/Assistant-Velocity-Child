<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */

$detailpenerima  = '<strong>Detail Donatur</strong>';
$detailpenerima .= '<p><table class="table-sm table table-borderless">';
$detailpenerima .= '<tr><td>Nama</td><td>: '.$nama.'</td></tr>';
if(!empty($alamat)){
    $detailpenerima .= '<tr><td>Alamat</td><td>: '.$alamat.'</td></tr>';
}
$detailpenerima .= '</table></p>';