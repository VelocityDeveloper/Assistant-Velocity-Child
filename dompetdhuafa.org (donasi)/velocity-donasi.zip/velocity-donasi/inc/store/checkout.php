<?php
/**
 * checkout part function.
 *
 * @package Velocity Toko
 */

global $wpdb;
$user_id           = get_current_user_id();
$user_info         = get_userdata($user_id);
$namatoko          = get_bloginfo('name');
$paypalopt         = velocitytoko_option('paypalopt');
$sitekey           = velocitytoko_option('sitekey_recaptcha_velocitytoko');
$secret            = velocitytoko_option('secret_recaptcha_velocitytoko');
$token             = isset($_SESSION['token'])? $_SESSION['token'] :'';
$detailkupon       = isset($_SESSION['kupon']['detail'])? json_decode($_SESSION['kupon']['detail'],true) :'';
$jeniskupon        = isset($detailkupon['jenis'])? $detailkupon['jenis'] : '';
$kodekupon         = isset($detailkupon['kode'])? $detailkupon['kode'] : '';
$potongankupon     = isset($detailkupon['potongan'])? $detailkupon['potongan'] : '';
$getnama           = get_user_meta( $user_id, 'namatoko', true );
$getalamat         = get_user_meta( $user_id, 'alamattoko', true );
$j=0;
?>

<form name="chckout" method="post" id="chckout" action="?action=finish">
 <div class="row">
    <?php require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/checkout-form.php'; ?>
    <div class="col-md-5">
        <h3 class="fs-5 fw-bold text-colortheme">Info Donasi</h3>
        <?php
        echo '<table class="table tabel-keranjang"><tbody>';

        //get data Keranjang        
        $Cart   = new Vsstemmart\Keranjang;
        $carts  = $Cart->alldata();

        $subtotal = 0;
        echo '<tr class="bg-light">';
            echo '<td >';
                echo 'Nama Donasi';
            echo '</td>';
            echo '<td class="text-end">';
                echo 'Biaya';
            echo '</td>';
        echo '</tr>';
        
        ///START Loop CARTS
        foreach($carts as $cart){

            $detail = json_decode($cart['detail'],true);
            $idproduk = $detail[0];
            $i= $j++;
            $getharga = vsstemmart_get_harga($idproduk);
            $harga      = $getharga['harga'];
            $hargaasli  = $getharga['harga_promo']?$getharga['harga_asli']:'';

            $harga = !empty($detail[2][2])? $detail[2][2] : $harga;
            $jumlah = $cart['jumlah'];
            echo '<input type="hidden" name="produk[products]['.$i.'][id]" value="'.$idproduk.'" class="form-control"/>';
            echo '<input type="hidden" name="produk[products]['.$i.'][nama]" value="'.get_the_title($idproduk).'" class="form-control"/>';
            echo '<input type="hidden" name="produk[products]['.$i.'][img]" value="'.get_the_post_thumbnail_url( $idproduk ,'full' ).'" class="form-control"/>';
            echo '<input type="hidden" name="produk[products]['.$i.'][harga]" value="'.$harga.'" class="form-control"/>';
            echo '<input type="hidden" name="produk[products]['.$i.'][hargaasli]" value="'.$hargaasli.'" class="form-control"/>';
            echo '<input type="hidden" name="produk[products]['.$i.'][jumlah]" value="'.$jumlah.'" class="form-control"/>';
            
            echo '<tr class="noborder">';
                echo '<td>';
                    echo get_the_title($idproduk);
                echo '</td>';
                echo '<td class="text-end">';
                    echo '<span class="subtotal" >'.vsstemmart_number_money($harga*$jumlah).'</span><br>';
                    echo '<small>'.$jumlah.' x '.vsstemmart_number_money($harga);
                    echo '</small>';
                    $subtotal +=$harga*$jumlah;
                echo '</td>';
            echo '</tr>';
        }
        //END loop Carts

        echo '<input type="hidden" name="invoice" value="'.mt_rand(100000000, 999999999).'" class="form-control invoice"/>';
        echo "<input type='hidden' name='token' value='".$token."' class='form-control'/>";

        echo '<tr class="bg-light">';
            echo '<td >';
                echo 'Subtotal:';
            echo '</td>';
            echo '<td class="text-end">';
                if($jeniskupon=='percent'){
                    $subtotalold    = $subtotal;
                    $subtotal       = $subtotal-($subtotal*$potongankupon/100);
                    echo '<div class="totalharga">'.vsstemmart_number_money($subtotal).' <s><small>'.vsstemmart_number_money($subtotalold).'</small></s></div>';
                    echo '<span class="text-muted"><small>*Mendapat Potongan '.$potongankupon.'% dari Kode Promo.</small></span>';
                } else if($jeniskupon=='rupiah'){
                    $subtotalold    = $subtotal;
                    $subtotal       = $subtotal-$potongankupon;
                    echo '<div class="totalharga">'.vsstemmart_number_money($subtotal).' <s><small>'.vsstemmart_number_money($subtotalold).'</small></s></div>';
                    echo '<span class="text-muted"><small>*Mendapat Potongan '.vsstemmart_number_money($potongankupon).' dari Kode Promo.</small></span>';
                } else {
                    echo '<div class="totalharga">'.vsstemmart_number_money($subtotal).'</div>';
                }
                echo '<input type="hidden" class="subhargatotal" name="produk[subhargatotal]" value="'.$subtotal.'" class="form-control"/>';
                echo '<input type="hidden" class="hargatotal" name="produk[hargatotal]" value="'.$subtotal.'" class="form-control"/>';
            echo '</td>';
        echo '</tr>';
        echo '<tr class="bg-secondary text-white">';
                echo '<td >';
                    echo 'Total:';
                echo '</td>';
                echo '<td class="text-end">';
                    echo vsstemmart_currency_text().' <span class="total">'.number_format($subtotal,0,',','.').'</span>';
                echo '</td>';
        echo '</tr>';
        echo '<tr>';
            echo '<td >';
                echo '<b>Catatan:</b>';
            echo '</td>';
            echo '<td class="text-end">';
                echo '<textarea maxlength="114" name="catatan" class="form-control form-control-sm" placeholder="Tulis doa anda untuk donasi ini."></textarea>';
            echo '</td>';
        echo '</tr>';
        echo '<tr class="bg-light text-dark">';
            echo '<td >';
                echo 'Pembayaran:';
            echo '</td>';
            echo '<td >';
        		echo '<section id="accordion">';
        			echo '<div class="tf-bayar">';
        				echo '<input type="radio" name="pembayaran" id="bank" value="bank" required/>';
        				echo '<label for="bank"> Transfer Bank</label>';
        				echo '<article class="text-center">';
        				    echo do_shortcode('[bank atasnama="false" norek="false"]');
        				echo '</article>';
        			echo '</div>';
        			
        			if($paypalopt=='on'){
            			echo '<div>';
            				echo '<input type="radio" name="pembayaran" id="paypal" value="paypal" />';
            				echo '<label for="paypal"> Paypal</label>';
            				echo '<article>';
            				    echo do_shortcode('[paypal]');
            				echo '</article>';
            			echo '</div>';
        			}
        		echo '</section>';
            echo '</td>';
        echo '</tr>';
        if($sitekey && $secret){
            echo '<tr>';
                echo '<td colspan="2" class="text-start">';
                    echo '<div id="recaptcha" class="g-recaptcha" data-callback="checkCaptcha" data-expired-callback="expiredCaptcha" data-sitekey="'.$sitekey.'"></div>';
                    echo '<div id="msgCaptcha"> </div>';
                echo '</td>';
            echo '</tr>';
            echo '<tr class="bg-light text-dark">';
                echo '<td colspan="2">';
                    echo '<button id="btn-validate" type="submit" class="btn btn-danger pointer d-block btn-sm ms-auto me-0 border-0" >Konfirmasi Pesanan</button>';
                echo '</td>';
            echo '</tr>';
        } else {
            echo '<tr class="bg-light text-dark">';
                echo '<td colspan="2">';
                    echo '<button type="submit" class="btn btn-danger pointer d-block btn-sm ms-auto me-0 border-0" >Konfirmasi Pesanan</button>';
                echo '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        ?>
    </div>
</div>
</form>