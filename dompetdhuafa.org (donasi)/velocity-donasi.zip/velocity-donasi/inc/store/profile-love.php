<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
$rel = json_decode(get_user_meta( $user_id, 'love', true),true );
if(!empty($rel)){
    $args = array(
        'post_type'     => array( 'donasi' ),
        'orderby'       => 'ASC',
        'post__in'      => $rel
    );
    $loop = new WP_Query( $args );
    echo '<div class="container">';
    echo '<h5 class="mt-4 mb-3 text-colortheme">';
        echo '<span class="me-1">        
        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-bookmark-heart" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M8 4.41c1.387-1.425 4.854 1.07 0 4.277C3.146 5.48 6.613 2.986 8 4.412z"/> <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.777.416L8 13.101l-5.223 2.815A.5.5 0 0 1 2 15.5V2zm2-1a1 1 0 0 0-1 1v12.566l4.723-2.482a.5.5 0 0 1 .554 0L13 14.566V2a1 1 0 0 0-1-1H4z"/> </svg>
        </span>';
        echo 'Daftar Donasi Favorit';
    echo '</h5>';
    echo '<div class="row">';
    if ( $loop->have_posts() ) {
    	while ( $loop->have_posts() ) {
    		$loop->the_post(); 
    		echo apply_filters( 'velocitytoko_content_loop_archive', $post );
    	}
    }
    echo '</div></div>';
}
