<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
 global $wpdb;

 $detailkupon       = isset($_SESSION['kupon']['detail'])? json_decode($_SESSION['kupon']['detail'],true) :'';
 $jeniskupon        = isset($detailkupon['jenis'])? $detailkupon['jenis'] : '';
 echo '<div class="text-end mt-3 mb-2">';
    echo '<div class="btn-group" role="group" aria-label="Basic example">';
        echo '<a class="btn btn-sm lanjut pointer me-1 bg-colortheme ms-auto text-white" onclick="hapusSemua()">';
            echo '<span id="hapussemua"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16"> <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/> <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/> </svg></span>';
            echo 'Kosongkan';
        echo '</a>';
        echo '<a class="perbarui btn btn-sm lanjut bg-colortheme ms-auto text-white" href="?"><span class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-clockwise" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z"/> <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z"/> </svg></span> Perbarui</a>';
    echo '</div>';
 echo '</div>'; 
    // get data Keranjang    
    $Cart   = new Vsstemmart\Keranjang;
    $carts  = $Cart->alldata();

    $subtotal = 0;

    echo '<table id="data-keranjang" class="table tabel-keranjang"><thead>';
    echo '<tr class="text-colortheme"><th>Image</th><th>Item</th><th>Harga</th><th>Kuantitas</th><th class="text-end">Sub Total</th></tr></thead><tbody>';
      
    foreach($carts as $cart){

        if(!empty($cart['id_produk'])){
            $idthm      = $cart['id_produk'];
            $idthmpetik = "'".$cart['id_produk']."'";
        } else {
            $idthm      = $cart['id'];
            $idthmpetik = "'".$cart['id']."'";
        }
        $detail         = json_decode($cart['detail'],true);
        $idproduk       = $detail[0];

        if ( get_post_status ( $idproduk ) ) {
      
            $min            = get_post_meta($idthm, 'minorder', true);
            $min            = isset($min) ? $min : '0' ;
            $namaopsi       = '';
            if(!empty($detail[1][1])){
                $namaopsi   .= '<br>'.$detail[1][0].': '.$detail[1][1];
            }
            if(!empty($detail[2][1]) && !empty($detail[2][2])){
                $namaopsi   .= '<br>'.$detail[2][0].': '.$detail[2][1];
            }
            $getharga   = vsstemmart_get_harga($idproduk);        
            $harga      = $getharga['harga'];
            $hargaasli  = $getharga['harga_promo']?$getharga['harga_asli']:'';
	        $stok       = get_post_meta($idproduk, 'stok', true);
            
            $harga      = !empty($detail[2][2])? $detail[2][2] : $harga;
            $jumlah     = $cart['jumlah'];
            echo '<tr id="row-'.$idthm.'">';
                echo '<td class="align-middle">';
                    echo '<img src="'.get_the_post_thumbnail_url( $idproduk,'thumbnail' ).'"/ width="50" alt=""/>';
                echo '</td>';
                echo '<td class="align-middle">';
                    echo '<a href="'.get_the_permalink($idproduk).'">'.get_the_title($idproduk).' '.$namaopsi.'</a><br>';
                echo '</td>';
                echo '<td class="align-middle">';
                    echo vsstemmart_number_money($harga);
                    if($hargaasli){
                        echo '<br><small><s>'.vsstemmart_number_money($hargaasli).'</s></small>';
                    }
                echo '</td>';
                echo '<td class="align-middle">';
                    echo '<div class="d-flex">';
                        echo '<input name="jumlah-'.$idproduk.'" data-id="'.$idproduk.'" min="1" type="number" class="align-self-center jumlah form-control-sm form-control" id="'.$idthm.'" value="'.$jumlah.'" />';
                        echo '<a id="delete-'.$idthm.'" class="align-self-center d-block pointer p-2" data-toggle="tooltip" title="Hapus '.get_the_title($idproduk).' Dari keranjang" onclick="deleteOrder('.$idthmpetik.')">';
                            echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16"> <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/> <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/> </svg>';
                        echo '</a>';
                    echo '</div>';
                    
                echo '</td>';
                echo '<td class="text-md-end">';
                    echo '<span class="subtotal" >'.vsstemmart_number_money($harga*$jumlah).'</span><br>';
                    echo '<small>'.$jumlah.' x '.vsstemmart_number_money($harga).'</small>';
                    $subtotal += $harga*$jumlah;
                echo '</td>';
            echo '</tr>';
        } else {
            echo '<tr><td colspan="5">Produk <strong>"'.$idproduk.'"</strong> tidak tersedia, akan dihapus dari keranjang</td></tr>';
                        
            ///delete item in Keranjang
            $Cart = new Vsstemmart\Keranjang;
            $Cart->deleteItem($idproduk);

        }
    }
    echo '</tbody></table>';
    
    echo '<div class="row m-0">';
        echo '<div class="col-md-6">';
        echo '</div>';
        echo '<div class="col-md-6 row pt-3 pt-md-1 text-dark">';
			echo '<div class="col-6 col-md-8 px-0 text-md-end">';
				echo '<b>Jumlah donasi akhir:</b>';
			echo '</div>';
			echo '<div class="col-6 col-md-4 px-0 text-end">';
				$dibayar = $subtotal;
				if($jeniskupon=='percent' && $subtotal>=$detailkupon['minorder']){
					$total      = $subtotal-($subtotal*$detailkupon['potongan']/100);
					$dibayar    = $total;
					echo '<div class="totalharga"><b>'.vsstemmart_number_money($total).' </b><s><small>'.vsstemmart_number_money($subtotal).'</small></s></div>';
					echo '<span class="text-muted"><small>*Mendapat Potongan '.$detailkupon['potongan'].'% dari Kode Promo.</small></span>';
				} else if($jeniskupon=='rupiah' && $subtotal>=$detailkupon['minorder']){
					$total      = $subtotal-$detailkupon['potongan'];
					$dibayar    = $total;
					echo '<div class="totalharga"><b>'.vsstemmart_number_money($total).' </b><s><small>'.vsstemmart_number_money($subtotal).'</small></s></div>';
					echo '<span class="text-muted"><small>*Mendapat Potongan '.vsstemmart_number_money($detailkupon['potongan']).' dari Kode Promo.</small></span>';
				} else if($jeniskupon=='ongkir' && $subtotal>=$detailkupon['minorder']){
					echo '<div class="totalharga"><b>'.vsstemmart_number_money($subtotal).'</b></div>';
					echo '<span class="text-muted"><small>*Mendapat Potongan Ongkir '.vsstemmart_number_money($detailkupon['potongan']).' dari Kode Promo.</small></span>';
				} else {
					echo '<div class="totalharga"><b>'.vsstemmart_number_money($subtotal).'</b></div>';
				}
				echo '<input type="hidden" value="'.$dibayar.'" id="dibayar"/>';
			echo '</div>';
        echo '</div>';
    echo '</div>';
        

echo '<div class="text-center mt-2">';
    echo '<a class="lanjut bg-colortheme mx-1 btn-sm btn ms-auto text-white" href="?action=checkout"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16"> <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/> </svg> Lanjut ke Pembayaran</a>';
echo '</div>';
?>
