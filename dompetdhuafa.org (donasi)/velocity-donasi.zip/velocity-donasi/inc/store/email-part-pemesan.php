<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
$pemesan = '<table style="width:100%"><tbody>';
    $pemesan .= '<tr>';
        $pemesan .= '<td>Nama </td>';
        $pemesan .= '<td>';
            $pemesan .= $nama;
        $pemesan .= '</td>';
    $pemesan .= '</tr>';
    if(!empty($alamat)){
        $pemesan .= '<tr>';
            $pemesan .= '<td>Alamat </td>';
            $pemesan .= '<td>';
                $pemesan .= $alamat;
            $pemesan .= '</td>';
        $pemesan .= '</tr>';
    }
$pemesan .= '</tbody></table>';