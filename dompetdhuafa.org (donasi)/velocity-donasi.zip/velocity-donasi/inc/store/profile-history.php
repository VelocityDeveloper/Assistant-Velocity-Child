<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
if($details){
    echo '<div class="container">';
	echo '<h5 class="title mt-4 mb-3 text-colortheme"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-bag-check" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M10.854 8.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 0 1 .708-.708L7.5 10.793l2.646-2.647a.5.5 0 0 1 .708 0z"/> <path d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1zm3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4h-3.5zM2 5h12v9a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5z"/> </svg> Riwayat Donasi</h5>';
	echo '<table id="data-keranjang" class="table tabel-keranjang"><tbody>';
    echo '<tr><th>Invoice</th><th>Date</th><th>Total</th><th>Status</th><th></th></tr>';
    foreach($details as $detail){
        $kurir          = $detail->kurir;
        $resi           = $detail->resi;
        $produk         = json_decode($detail->detail,true);
        if($detail->status =='Donasi Baru'){
            $status = 'Menunggu Pembayaran';
        } else {
            $status = $detail->status;
        }
        // print_r($produk);
        echo '<tr>';
            echo '<td>#'.$detail->invoice.'</td>';
            echo '<td>'.$detail->date.'</td>';
            echo '<td>'.vsstemmart_number_money($produk['produk']['hargatotal']).'</td>';
            echo '<td>'.$status.'</td>';
            echo '<td class="text-end">';
                    echo '<a class="btn-sm mx-1 detail btn btn-outline-dark" href="?invoice='.$detail->invoice.'">Lihat Detail</a>';
            echo '</td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}