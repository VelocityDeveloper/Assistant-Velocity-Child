<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
 ?>
<div style="max-width:500px" class="mx-auto w-100 my-4 p-3 card">
<div class="text-center">
<?php
    $sukses = 'false';
	if (isset($_POST['adduser']) && isset($_POST['add-nonce']) && wp_verify_nonce($_POST['add-nonce'], 'add-user')) {
	
		// die if the nonce fails
		if ($_POST['idunik'] != $_POST['kodecaptcha']) {
			$error = 'Kode captcha salah.';
    	} elseif ( !wp_verify_nonce($_POST['add-nonce'],'add-user') ) {
			wp_die('Sorry! That was secure, guess you\'re cheatin huh!');
		} else {
			// auto generate a password
			$user_pass = wp_generate_password();
			// setup new user
			$userdata = array(
				'user_pass' => $user_pass,
				'user_login' => esc_attr( $_POST['user_name'] ),
				'user_email' => esc_attr( $_POST['email'] ),
				'role' => get_option( 'default_role' ),
			);
			// setup some error checks
			if ( !$userdata['user_login'] )
				$error = 'A username is required for registration.';
			elseif ( username_exists($userdata['user_login']) )
				$error = 'Sorry, that username already exists!';
			elseif ( !isset($userdata['user_email']) )
				$error = 'You must enter a valid email address.';
			elseif ( email_exists($userdata['user_email']) )
				$error = 'Sorry, that email address is already used!';
			// setup new users and send notification
			else{
				$new_user   = wp_insert_user( $userdata );
                
                $user       = get_userdata($new_user); 
                $user_login = stripslashes($user->user_login); 
                $key        = get_password_reset_key($user);
                
                if ( !is_wp_error( $key )) {
                    $rp_link    =  wp_login_url() ."?action=rp&key=$key&login=" . rawurlencode($user_login);
                } else {
                    $rp_link    =  wp_lostpassword_url();
                }

                $emailblog  = 'admin@'.parse_url(get_home_url())['host'];

                ///set header Email
                $headers[]  = 'MIME-Version: 1.0';
                $headers[]  = 'Content-type: text/html; charset=iso-8859-1';
                // Additional headers
                $headers[]  = 'From: '.get_bloginfo( 'name' ).' <'.$emailblog.'>';

                $bodymail   = '<div style="border: 5px solid #ddd;padding: 2rem;text-align:center;margin:2rem 0;">';
                $bodymail   .= 'Terima kasih telah mendaftar di <strong>'.get_bloginfo( 'name' ).'</strong><br> Silahkan setting password anda terlebih dahulu<br>';
                $bodymail   .= '<a href="'.$rp_link.'" style="background-color:#333;color:#fff;padding:.5rem 1.5rem;display: inline-block;margin:1rem 0;">Klik disini</a>';
                $bodymail   .= '</div>';

                $subjectmail    = 'Pendaftaran di '.get_bloginfo( 'name' ).' berhasil';
                $sendmail       = wp_mail( $userdata['user_email'], $subjectmail, $bodymail, implode("\r\n", $headers) );

				$sukses = 'true';
			}
		}
	}
	if ( $sukses == 'true' ) : ?>

	<p class="alert"><!-- create and alert message to show successful registration -->
	<?php
		$user = get_user_by('id',$new_user);
		echo 'Terimakasih telah melakukan mendaftar, ' . $user->user_login;
		echo '<br/>Silahkan cek pesan masuk email '.$_POST['email'].', periksa juga kotak spam.';
	?>
	</p>
	
	<?php else : ?>
	
		<?php if ( $error ) : ?>
			<p class="error"><!-- echo errors if users fails -->
				<?php echo $error; ?>
			</p>
		<?php endif; ?>
	
	<?php endif;

?>
</div>
<?php $captcha = rand(1000,9999);
if(!isset($_POST['adduser'])){ ?>
    <div class="form-login">
        <h4 class="title">Daftar</h4><hr>
        <form method="POST" id="adduser" class="user-forms" action="">
        	<p class="form-username">
        		<label for="user_name">Username</label><br>
        		<input class="form-control" name="user_name" type="text" id="user_name" value="" />
        	</p>
        	
        	<p class="form-email">
        		<label for="email">E-mail</label><br>
        		<input class="form-control" name="email" type="email" id="email" value="" />
        	</p>
        	
			<div class="form-captcha mb-4">
					<input name="idunik" type="hidden" value="<?php echo $captcha;?>">
            		<label for="captcha">Isikan Captcha</label><br>
					<div class="row">
						<div class="col-3 col-md-2 pe-0"><div class="captcha rounded"><?php echo $captcha;?></div></div>
						<div class="col-9 col-md-10"><input class="form-control" name="kodecaptcha" type="text" required ></div>
					</div>
            </div>

        	<p class="form-submit">
        		<input name="adduser" type="submit" id="addusersub" class="btn btn-dark" value="Register" />
        		<?php wp_nonce_field( 'add-user', 'add-nonce' ) ?><!-- a little security to process on submission -->
        		<input name="action" type="hidden" id="action" value="adduser" />
				<a class="btn btn-dark mx-2" href="?" >Login</a>
        	</p>
        </form>
    </div>
<?php } ?>

</div>