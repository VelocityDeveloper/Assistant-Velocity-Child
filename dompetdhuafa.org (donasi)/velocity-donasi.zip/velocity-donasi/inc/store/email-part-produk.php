<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
    $detailproduk  = '<strong>Detail Donasi</strong>';
    $detailproduk .= '<table class="table" style="width:100%"><tbody>';
    $detailproduk .= '<thead><tr><td >Nama Donasi</td><td >Harga</td><td >Kuantitas</td><td style="padding: 5px 10px;text-align: right;">Sub Total</td></tr></thead>';
        
        $dataproducts = isset($_POST['produk']['products'])?$_POST['produk']['products']:[];
        foreach ($dataproducts as $key => $product) {           
            $detailproduk .= '<tr>';
                $detailproduk .= '<td>';
                    $detailproduk .= $product['nama'];
                    $detailproduk .= isset($product['isiopsi'])?'<br>'.$product['isiopsi']:'';
                $detailproduk .= '</td>';
                $detailproduk .= '<td>';
                    $detailproduk .= vsstemmart_number_money($product['harga']);
                    if($product['hargaasli']){
                        $detailproduk .= '<br><small><s>'.vsstemmart_number_money($product['hargaasli']).'</s></small>';
                    }
                $detailproduk .= '</td>';
                $detailproduk .= '<td >';
                    $detailproduk .= $product['jumlah'];
                $detailproduk .= '</td>';
                $detailproduk .= '<td class="text-end" style="text-align:right">';
                    $detailproduk .= '<span class="subtotal" >'.vsstemmart_number_money($product['harga']*$product['jumlah']).'</span><br>';
                    $detailproduk .= '<small>'.$product['jumlah'].' x '.vsstemmart_number_money($product['harga']);
                $detailproduk .= '</td>';
            $detailproduk .= '</tr>';
        }
        $detailproduk .= '<tr >';
            $detailproduk .= '<td colspan="2" style="border-top:1px solid #ddd;padding:5px 10px;"><strong>Total Transfer</strong></td>';
            $detailproduk .= '<td colspan="2" style="border-top:1px solid #ddd;text-align: right;padding:5px 10px;">';
                    $detailproduk .= '<strong>'.vsstemmart_number_money($_POST['produk']['hargatotal']).'</strong>';
                if($jeniskupon == 'percent'){
                    $total  = $_POST['produk']['hargatotal']-($_POST['produk']['hargatotal']*$potongankupon/100);
                    $detailproduk .= '<div><small>Menggunakan Kode Promo= <b>'.$kodekupon.'</b><br>* Mendapat Potongan '.vsstemmart_number_money($total).' </small> ( '.$potongankupon.'% )</div>';
                } else if($jeniskupon == 'rupiah'){
                    $detailproduk .= '<div><small>Menggunakan Kode Promo= <b>'.$kodekupon.'</b><br>* Mendapat Potongan '.vsstemmart_number_money($potongankupon).' </small></div>';
                }
            $detailproduk .= '</td>';
        $detailproduk .= '</tr>';
            
    $detailproduk .= '</tbody></table>';