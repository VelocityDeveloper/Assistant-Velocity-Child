<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
 
$user_id        = get_current_user_id();
$newnama        = isset($_POST['namatoko'])? $_POST['namatoko'] :'';
$newstatus      = isset($_POST['statusdropship'])? $_POST['statusdropship'] :'';
$newalamat      = isset($_POST['alamattoko'])? $_POST['alamattoko'] :'';
$newhp          = isset($_POST['nohp'])? $_POST['nohp'] :'';
$getnama        = get_user_meta( $user_id, 'namatoko', true );
$getalamat      = get_user_meta( $user_id, 'alamattoko', true );
$getstatus      = get_user_meta( $user_id, 'statusdropship', true );
$gethp          = get_user_meta( $user_id, 'nohp', true );
$statusdropship = velocitytoko_option( 'dropshipstatus');
if($statusdropship == 'on'){
    if(isset($_POST['namatoko']) || isset($_POST['alamattoko'])){
        update_user_meta( $user_id, 'namatoko', $newnama );
        update_user_meta( $user_id, 'alamattoko', $newalamat );
        update_user_meta( $user_id, 'statusdropship', $newstatus );
        update_user_meta( $user_id, 'nohp', $newhp );
        $namatampil     = $newnama;
        $alamattampil   = $newalamat;
        $statustampil   = $newstatus;
        $hptampil       = $newhp;
    } else {
        $namatampil     = $getnama;
        $alamattampil   = $getalamat;
        $statustampil   = $getstatus;
        $hptampil       = $gethp;
    }
    if( $statustampil == 'on'){
        $stts       = 'checked';
        $tooltip    = 'Nonaktifkan Dropship';
    } else {
        $stts       = '';
        $tooltip    = 'Aktifkan Dropship';
    }
    ?>
    <div class="container mb-4">
        <form class="form-row" method="post">
        <div class="card">
            <div class="card-header row mx-0 align-items-center bg-secondary text-white">
                <div class="col-7">
                    <?php 
                    if(isset($_POST['namatoko']) || isset($_POST['alamattoko'])){
                        echo 'Data Dropsip Berhasil Diperbarui';
                    } else {
                        echo 'Data Dropsip';
                    }
                    ?>
                </div>
                <div class="col-5 text-end">
                    <label class="switch mb-0 mt-2" data-toggle="tooltip" title="<?php echo $tooltip;?>">
                      <input type="checkbox" <?php echo $stts;?> name="statusdropship">
                      <span class="slider round"></span>
                    </label>
                </div>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    Toko ini memberikan opsi dropship. Jika anda mengaktifkan fitur ini semua produk yang anda beli akan dikirim dengan nama toko dan alamat sesuai data toko anda. 
                </div>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="namaToko">Nama Toko</span>
                    </div>
                    <input type="text" class="form-control" max="30" value="<?php echo $namatampil; ?>" name="namatoko" required>
                  </div>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="namaToko">No HP</span>
                    </div>
                    <input type="text" class="form-control" max="30" value="<?php echo $hptampil; ?>" name="nohp" required>
                  </div>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="namaToko">Alamat Toko</span>
                    </div>
                    <input type="text" class="form-control" max="50" value="<?php echo $alamattampil; ?>" name="alamattoko" required>
                  </div>
                  <div class="text-end">
                    <button type="submit" class="btn btn-dark">Simpan</button>
                  </div>
                
            </div>
        </div>
        </form>
    </div>
    <?php
}