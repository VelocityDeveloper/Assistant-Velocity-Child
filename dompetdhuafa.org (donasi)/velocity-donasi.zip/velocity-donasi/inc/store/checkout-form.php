<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
 ?>
<div class="col-md-7">
        <h3 class="fs-5 fw-bold text-colortheme">Detail Donatur</h3>

        <?php if ( is_user_logged_in() ) {
            $current_user = wp_get_current_user();
            $user_email = $current_user->user_email;
            $nama = get_user_meta( $user_id, 'nama',true );
            $hp = get_user_meta( $user_id, 'hp',true );
            $alamat = get_user_meta( $user_id, 'alamat',true );
        } else {            
            $user_email = '';
            $nama = '';
            $hp = '';
            $alamat = '';
        }
        ?>
        <table class="table ifno noborder">
            <tr>
                <td>
                    Nama Lengkap *
                </td>
                <td>
                    <input type="text"  id="nama" maxlength="50" name="nama" value="<?php echo $nama;?>" class="form-control datapengiriman" required></input>
                    <div class="form-check mt-1">
                        <input class="form-check-input" name="anonim" type="checkbox" value="1">
                        <label class="form-check-label text-muted" for="flexCheckDefault">
                            Sembunyikan nama saya
                        </label>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    Nomor Handphone *
                </td>
                <td>
                    <input type="number" maxlength="15" id="hp" name="hp" value="<?php echo $hp;?>" class="form-control datapengiriman" required></input>
                </td>
            </tr>
            <tr>
                <td>
                    Email (optional)
                </td>
                <td>
                    <input type="email"  id="email" name="email" value="<?php echo $user_email;?>" class="form-control datapengiriman"></input>
                </td>
            </tr>
            <tr>
                <td>
                    Alamat (optional)
                </td>
                <td>
                    <textarea type="text"  id="alamat" maxlength="100" name="alamat" value="" class="form-control datapengiriman"><?php echo $alamat;?></textarea>
                </td>
            </tr>            
            
        </table>
		
    </div>