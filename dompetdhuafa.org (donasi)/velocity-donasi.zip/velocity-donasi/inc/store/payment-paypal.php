<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
 ?>
 <div class="text-center">
    <h3 class="mb-3">Terima Kasih, Donasi Anda Berhasil di kirim!</h3>
    
    <?php
        $pesan              = velocitytoko_option('pesancheckout');
        $pesan              = str_replace('[nama-donatur]',$nama,$pesan);
        $pesan              = str_replace('[nama-web]',$namatoko,$pesan);
        $pesan              = str_replace('[email-donatur]',$email,$pesan);
        echo $pesan;
    ?>
    
    <div class="row pesan-transfer mt-3 mb-3">
        <div class="col-sm-4">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="50" fill="currentColor" class="bi bi-credit-card" viewBox="0 0 16 16"> <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4zm2-1a1 1 0 0 0-1 1v1h14V4a1 1 0 0 0-1-1H2zm13 4H1v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V7z"/> <path d="M2 10a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-1z"/> </svg> 
            <p>Bayar dengan Paypal, klik icon paypal checkout dibawah dan ikuti langkah pembayaran sampai selesai</p>
        </div>
        <div class="col-sm-4">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="50" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16">   <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z"/>   <path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z"/> </svg>
            <p>Konfirmasi pembayaran dengan cara mengisi <a href="<?php echo get_permalink( get_page_by_path( 'myaccount' ) ); ?>?invoice=<?php echo $invoice; ?>">formulir online</a> atau menghubungi customer service kami di <?php echo velocitytoko_option('notlp_velocitytoko'); ?></p>
        </div>
        <div class="col-sm-4">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="50" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16"> <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/> <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/> </svg> 
            <p>Donasi akan segera di proses setelah anda melakukan konfirmasi pembayaran</p>
        </div>
    </div>
    
    <div class="frame-invoice">
        <p class="text-dark">Kode Donasi Anda (Invoice):</p><br>
        <span>
            <?php echo $invoice; ?>
        </span>
    </div>
    
    <div class="mt-4" id="paypal-button"></div>
    
    <div>
        <p class="mt-3">Setelah Melakukan Pembayaran silahkan melakukan konfirmasi Pembayaran melalui <b><a href="<?php echo get_permalink( get_page_by_path( 'myaccount' ) ); ?>?invoice=<?php echo $invoice; ?>">Klik Disini</a></b></p>
    </div>
</div>
<script src="https://www.paypalobjects.com/api/checkout.js"></script>
<script>
paypal.Button.render({
    // Configure environment
    env: '<?php echo $paypalmode; ?>', // sandbox | production
    client: {
    sandbox: '<?php echo $paypalclientid; ?>',
    production: '<?php echo $paypalclientid; ?>'
    },
    // Customize button (optional)
    locale: 'id_ID',
    style: {
    size: 'large',
    color: 'gold',
    shape: 'pill',
    fundingicons: 'true',
    },
    funding: {
      allowed: [ paypal.FUNDING.CARD ],
      disallowed: [ paypal.FUNDING.CREDIT ]
    },
    // Set up a payment
    payment: function (data, actions) {
    return actions.payment.create({
      transactions: [{
        amount: {
          total: '<?php echo $hargatotaldolar; ?>',
          currency: 'USD'
        }
      }]
    });
    },
    // Execute the payment
    onAuthorize: function (data, actions) {
    return actions.payment.execute()
      .then(function () {
        // Show a confirmation message to the buyer
        window.alert('Terimakasih Telah melakukan pembayaran!');
      });
    }
}, '#paypal-button');
</script>