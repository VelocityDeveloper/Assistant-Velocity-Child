<?php $images = $settings->image_columns;
echo '<div id="image-carousel" class="images-'.$id.' pb-5">';
foreach($images as $image){
  	$url = wp_get_attachment_url($image->image);
  	$urlimg = aq_resize($url, 350, 230, true, true, true);
    echo '<div><a href="'.$image->link.'">';
    echo '<img src="'.$urlimg.'" />';
    echo '<div class="pt-2 text-center text-dark">'.$image->title.'</div>';
    echo '</a></div>';
}
echo '</div>';?>
