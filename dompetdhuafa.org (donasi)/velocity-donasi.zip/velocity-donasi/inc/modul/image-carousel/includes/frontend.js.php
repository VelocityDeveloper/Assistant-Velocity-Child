jQuery(function($) {
$('.images-<?php echo $id; ?>').owlCarousel({
smartSpeed:3000,
    autoplayTimeout: 7000,
    loop:true,
	items:5,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
        },
        500:{
            items:2,
        },
        700:{
            items:3,
        },
        900:{
            items:4,
        },
    },
    margin:20,
    autoplay:true,
    stagePadding:0,
	dots: true,
	nav: false,
	navText:['<i class="fa fa-angle-left"></i>','<i class="fa  fa-angle-right"></i>'],
})
});