<?php

/**
 * @class vFLimageCarousel
 */
class vFLimageCarousel extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct() {
		parent::__construct(array(
			'name'          	=> __( 'Image Carousel', 'fl-builder' ),
			'description'   	=> __( 'Display a image carousel by Velocity Developer.', 'fl-builder' ),
			'category'      	=> __( 'Media', 'fl-builder' ),
			'editor_export' 	=> false,
			'partial_refresh'	=> true,
			'icon'				=> 'format-gallery.svg',
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('vFLimageCarousel', array(
	'layout'        => array(
		'title'         => __( 'Images ', 'fl-builder' ),
		'sections'      => array(
			'content'       => array(
				'title'         => __( 'Images', 'fl-builder' ),
				'fields'        => array(
					'image_columns'     => array(
						'type'         => 'form',
						'label'        => __('Image Box', 'fl-builder'),
						'form'         => 'image_column_form',
						'preview_text' => 'title',
						'multiple'     => true
					),
				),
			),
		),
	),
));

FLBuilder::register_settings_form('image_column_form', array(
	'title' => __( 'Add Image', 'fl-builder' ),
	'tabs'  => array(
		'general'      => array(
			'title'         => __('General', 'fl-builder'),
			'sections'      => array(
				'title'       => array(
					'title'         => __( 'Title', 'fl-builder' ),
					'fields'        => array(
						'image'          => array(
							'type'          => 'photo',
							'label'         => __('Upload Image', 'fl-builder'),
						),
						'title'          => array(
							'type'          => 'text',
							'label'         => __('Title', 'fl-builder'),
						),
						'link'          => array(
							'type'          => 'link',
							'label'         => __('Link', 'fl-builder'),
						),
					),
				),
			)
		),
	)
));
