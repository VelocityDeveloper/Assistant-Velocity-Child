<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */

add_action('wp_head','vsstemmart_ajaxurl');
function vsstemmart_ajaxurl() {
    $html    = '<script type="text/javascript">';
    $html   .= 'var ajaxurl = "' . admin_url( 'admin-ajax.php' ) . '"';
    $html   .= '</script>';
    echo $html;
}


add_action( 'wp_ajax_ajaxlogin', 'ajax_login' );
add_action( 'wp_ajax_nopriv_ajaxlogin', 'ajax_login' );
function ajax_login(){

    // First check the nonce, if it fails the function will break
    check_ajax_referer( 'ajax-login-nonce', 'security' );

    // Nonce is checked, get the POST data and sign user on
    $info = array();
    $info['user_login']             = $_POST['username'];
    $info['user_password']          = $_POST['password'];
    $info['g-recaptcha-response']   = isset($_POST['g-recaptcha-response']) ? $_POST['g-recaptcha-response']:'';
    $info['remember']               = true;

    if($info['g-recaptcha-response']) {
        //get BWS recaptcha options
        $gglcptch_options   = get_option( 'gglcptch_options');  
        $response           = wp_remote_get( 'https://www.google.com/recaptcha/api/siteverify?secret='.$gglcptch_options['private_key'].'&response=' . $_POST['g-recaptcha-response'] );
        $response           = json_decode($response['body'], true);

        if (true != $response['success']) {
            echo json_encode(array('loggedin'=>false, 'message'=>__('<strong>ERROR</strong>: Please Validate reCAPTCHA')));
            return false;
        } 
    }
    
    if (is_ssl()) {
        $sll = true;
    } else {
        $sll = false;
    }
    $user_signon = wp_signon( $info, $sll );
    if ( is_wp_error($user_signon) ){
        echo json_encode(array('loggedin'=>false, 'message'=>$user_signon->get_error_message() ));
    } else {
        echo json_encode(array('loggedin'=>true, 'message'=>__('Login successful, redirecting...')));
    }


    die();
}


add_action('wp_ajax_adminpembeli', 'adminpembeli_ajax');
function adminpembeli_ajax() {
    global $wpdb;
    $table_name = $wpdb->prefix . "order";
    $table_donatur = $wpdb->prefix."donatur";
    $id         = isset($_POST['id']) ? $_POST['id'] : '';
    $status     = isset($_POST['status']) ? $_POST['status'] : '';
    $kirimemail = isset($_POST['kirim']) ? $_POST['kirim'] : '';
    $detail     = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $id ) );
    $produk     = json_decode($detail->detail,true);
    $nama       = isset($produk['nama'])? $produk['nama'] : '';
    $namadonatur = !empty($produk['anonim'])? 'Anonim' : $nama;
    $namatoko   = get_bloginfo('name');
    $emailtoko  = velocitytoko_option('emailadmin',get_bloginfo('admin_email'));
    $link       = '<a href="'.get_permalink( get_page_by_path( 'myaccount' ) ).'?invoice='.$detail->invoice.'" >Detail Pesanan</a>';

    $wpdb->update($table_name, array(
        'status'        => $status,
       ),
       array(
        'id'            => $id,
           )
    );

	if($status == 'Sukses' && ($detail->status) != 'Sukses'){
        $products = $produk['produk']['products'];
		foreach ($products as $product) {
			$post_id = $product['id'];
			$harga = $product['harga'];
			$jumlah = $product['jumlah'];
            //delete_post_meta($post_id, 'totaldonasi');
			$totaldonasi = get_post_meta($post_id,'totaldonasi',true);
            $totaldonasiawal = !empty($totaldonasi) ? $totaldonasi : '0';
			$tambahan = $harga * $jumlah;
			$totaldonasi = $totaldonasiawal + $tambahan;
			update_post_meta($post_id,'totaldonasi',$totaldonasi);
			$wpdb->insert($table_donatur, array(
				'id_pembeli' => $detail->id_pembeli,
				'invoice' => $detail->invoice,
				'nama' => $namadonatur,
				'id_produk' => $post_id,
			));
		}
	}

    $pesan              = velocitytoko_option('statusemail');
    $pesan              = str_replace('[nama-donatur]',$nama,$pesan);
    $pesan              = str_replace('[nama-web]',$namatoko,$pesan);
    $pesan              = str_replace('[status]',$status,$pesan);
    $pesan              = str_replace('[kode-donasi]',$detail->invoice,$pesan);
    $pesan              = str_replace('[link]',$link,$pesan);

    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'From: '.$namatoko.' <'.$emailtoko.'>';
    $subject = 'Hallo! Ada Perubahan Status Pada Invoice #'.$detail->invoice;

    if($kirimemail == 'yes' && !empty($produk['email'])){
        wp_mail( $emailtoko, $subject, $pesan, $headers );
    }
    
    wp_die();
}

add_action('wp_ajax_lanjuthapus', 'lanjuthapus_ajax');
function lanjuthapus_ajax() {
    global $wpdb;
	$table_name     = $wpdb->prefix . "order";
    $idproduk       = isset($_POST['myid']) ? $_POST['myid'] : '';
    $wpdb->delete($table_name, array(
        'id'     => $idproduk,
      )
	);
    wp_die();
}

add_action('wp_ajax_nopriv_hapuskupon', 'hapuskupon_ajax');
add_action('wp_ajax_hapuskupon', 'hapuskupon_ajax');
function hapuskupon_ajax() {
    $_SESSION['kupon']= '';
}


add_action('wp_ajax_nopriv_love', 'love_ajax');
add_action('wp_ajax_love', 'love_ajax');
function love_ajax() {
    $idproduk   = isset($_POST['idproduk']) ? $_POST['idproduk'] : '';
    $user_id    = get_current_user_id();

    if(!empty(get_user_meta( $user_id, 'love', true))){
        $ada    = json_decode(get_user_meta( $user_id, 'love', true),true );
    } else {
        $ada    = array();
    }
    if(in_array($idproduk,$ada)) {
        $ada    = array_diff($ada, array($idproduk));
        $baru   = json_encode($ada);
        update_user_meta( $user_id, 'love', $baru );
    } else {
        array_push($ada, $idproduk);
        $baru   = json_encode($ada);
        update_user_meta( $user_id, 'love', $baru );
    }

    wp_die();
}


add_action('wp_ajax_nopriv_kota', 'kota_ajax');
add_action('wp_ajax_kota', 'kota_ajax');
function kota_ajax() {
    $prov  = isset($_POST['prov_destination']) ? $_POST['prov_destination'] : '';
    echo "<option value=''>Kota</option>";
	  $data_City    = getCity();
      for ($x=0; $x < count($data_City); $x++) {
          if($prov==$data_City[$x]['province_id']) {
            $type = $data_City[$x]['type'];
            if( $type == 'Kabupaten'){
                $type = 'Kab';
            }
            echo "<option value='".$data_City[$x]['city_id']."' class='". $data_City[$x]['province_id']."' >".$type." ".$data_City[$x]['city_name']."</option>";
          }
      }
    wp_die();
}


add_action('wp_ajax_nopriv_tambahkeranjang', 'tambahkeranjang_ajax');
add_action('wp_ajax_tambahkeranjang', 'tambahkeranjang_ajax');
function tambahkeranjang_ajax() {
    $idproduk   = isset($_POST['idproduk']) ? $_POST['idproduk'] : '';
    $idasli     = isset($_POST['idasli']) ? $_POST['idasli'] : '';
    $jumlah     = isset($_POST['jumlah']) ? $_POST['jumlah'] : '';
    $opsia      = isset($_POST['onopsia']) ? $_POST['onopsia'] : '';
    $opsib      = isset($_POST['onopsib']) ? $_POST['onopsib'] : '';
    
    $Cart       = new Vsstemmart\Keranjang;
    $cartcount  = $Cart->addItem($idasli,$idproduk,$jumlah,$opsia,$opsib);
    
    //echo jumlah
    echo $cartcount;
    
    wp_die();
}

add_action('wp_ajax_nopriv_modifkeranjang', 'modifkeranjang_ajax');
add_action('wp_ajax_modifkeranjang', 'modifkeranjang_ajax');
function modifkeranjang_ajax() {
    $idproduk   = isset($_POST['id']) ? $_POST['id'] : '';
    $jumlah     = isset($_POST['jumlah']) ? $_POST['jumlah'] : '';
    $Cart       = new Vsstemmart\Keranjang;
    $cartcount  = $Cart->updateItem($idproduk,$jumlah);

    echo $cartcount;
    wp_die();
}

add_action('wp_ajax_nopriv_deleteorder', 'deleteorder_ajax');
add_action('wp_ajax_deleteorder', 'deleteorder_ajax');
function deleteorder_ajax() {
    
    // Reset Keranjang
    $idproduk   = isset($_POST['id']) ? $_POST['id'] : '';  
    $Cart       = new Vsstemmart\Keranjang;
    $Cart->deleteItem($idproduk);

    echo $Cart->count();

    wp_die();
}

add_action('wp_ajax_nopriv_kosongkankeranjang', 'kosongkankeranjang_ajax');
add_action('wp_ajax_kosongkankeranjang', 'kosongkankeranjang_ajax');
function kosongkankeranjang_ajax() {
    
    // Reset Keranjang    
    $Cart = new Vsstemmart\Keranjang;
    $Cart->reset();

    wp_die();
}

add_action('wp_ajax_nopriv_displaytablecart', 'displaytablecart_ajax');
add_action('wp_ajax_displaytablecart', 'displaytablecart_ajax');
function displaytablecart_ajax() {
    
    echo velocitytoko_display_tablecart();

    wp_die();
}
