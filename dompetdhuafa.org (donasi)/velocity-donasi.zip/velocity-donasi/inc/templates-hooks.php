<?php
/**
 * Store function.
 *
 * @package Velocity Toko
 */

function velocitytoko_content_loop_archive_filter($post){
    ob_start();
    ?>
    <article <?php post_class('col-md-4 col-6 pb-2'); ?> id="post-<?php the_ID(); ?>">
        <div class="card">
            <?php echo do_shortcode("[post-loop]"); ?>
        </div>
    </article><!-- #post-## -->
    <?php
    return ob_get_clean();
}
add_filter('velocitytoko_content_loop_archive','velocitytoko_content_loop_archive_filter');

function velocitytoko_content_loop_related_filter($post){
    ob_start();
    ?>
    <article <?php post_class('col-md-3 col-6'); ?> id="post-<?php the_ID(); ?>">
        <div class="card">
            <?php echo do_shortcode("[thumbnail width='300' height='380' crop='false' upscale='true']"); ?>
            <div class="p-3">
                <h3 class="my-2 upperhead text-center text-md-start"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
            </div>
        </div>  
    </article><!-- #post-## -->
    <?php
    return ob_get_clean();
}
add_filter('velocitytoko_content_loop_related','velocitytoko_content_loop_related_filter');

function velocitytoko_content_single_product_filter($post){
    ob_start();
    $date       = get_the_modified_date('d-m-Y', get_the_ID());
    ?>
    <article <?php post_class('single-donation'); ?> id="post-<?php the_ID(); ?>">

        <div class="block-primary mb-4">            
            <div class="row">
                <div class="col-md-12 mb-3"><?php echo do_shortcode('[thumbnailfull]'); ?></div>
                <div class="col-md-12">
                    <h1 class="fs-4 fw-bold"><?php echo get_the_title(); ?></h1>
                    <div class="mb-2">
                        <small>
                            Kategori: <?php echo velocitytoko_term_list('kategori-donasi',",",get_the_ID()); ?> 
                            | Dilihat: <?php echo do_shortcode('[view]'); ?> 
                            | Sejak: <?php echo $date; ?>
                        </small>
                    </div>
                    <div class="single-progress mb-3"><?php echo do_shortcode('[progress]'); ?></div>
                    <div class="mb-2"><?php echo do_shortcode('[beli text="true"]'); ?></div>
                    <div class="mb-3"><?php echo do_shortcode('[love text="true"]'); ?></div>
                    <div class="mb-3"><?php echo do_shortcode('[donasi-lain]'); ?></div><hr class="border-top">
                    <div class="mb-3"><?php echo do_shortcode('[share]'); ?></div>
                </div>
            </div>
        </div>


        <div class="card p-3 border">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="fs-6 nav-link fw-bold active" id="detail-tab" data-bs-toggle="tab" data-bs-target="#detail" type="button" role="tab" aria-controls="detail" aria-selected="true">Detail Donasi</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="fs-6 nav-link fw-bold" id="kabar-tab" data-bs-toggle="tab" data-bs-target="#kabar" type="button" role="tab" aria-controls="kabar" aria-selected="false">Kabar Terbaru</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="fs-6 nav-link fw-bold" id="donatur-tab" data-bs-toggle="tab" data-bs-target="#donatur" type="button" role="tab" aria-controls="donatur" aria-selected="false">Daftar Donatur</button>
                </li>
            </ul>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="detail" role="tabpanel" aria-labelledby="detail-tab">
                    <div class="pt-3"><?php echo get_the_content(); ?></div>
                </div>
                <div class="tab-pane fade" id="kabar" role="tabpanel" aria-labelledby="kabar-tab">
                    <div class="pt-3">
                      <?php $update_info  = get_post_meta(get_the_ID(), 'update_info', true);
  						//echo '<pre>'.print_r($update_info,1).'</pre>';
  					if(!empty($update_info)){
                      foreach($update_info as $data){
                        $date_icon = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar-check me-2" viewBox="0 0 16 16">
  <path d="M10.854 7.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 9.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
  <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z"/>
</svg>';
                        echo '<div class="list">';
                        	echo '<div class="text-success font-weight-bold h6">'.$data['judulupdate'].'</div>';
                        	echo '<div class="text-muted mb-2 float-right"><small>'.$date_icon.$data['tanggal'].'</small></div>';
                        	echo '<div class="text-dark">'.$data['deskripsiupdate'].'</div>';
                        	if(!empty($data['imageupdate'])){
                        		echo '<div class="mt-2"><img class="w-100" src="'.$data['imageupdate'].'" /></div>';
                            }
                        echo '</div>';
                        echo '<hr>';
                      }
                    } else {
                      echo '<div class="alert alert-warning mb-0" role="alert">
                        Belum ada kabar terbaru.
                      </div>';
                    }
                      ?>                  
                    </div>
                </div>
                <div class="tab-pane fade" id="donatur" role="tabpanel" aria-labelledby="donatur-tab">
                    <div class="pt-3"><?php echo do_shortcode('[daftar-donatur]'); ?></div>
                </div>
            </div>
        </div>
    </article><!-- #post-## -->
    <?php
    return ob_get_clean();
}
add_filter('velocitytoko_content_single_product','velocitytoko_content_single_product_filter');

function velocitytoko_content_loop_none_filter($post){
    ob_start();
    ?>
    <section class="no-results not-found">

        <header class="page-header">

            <h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'vsstemmart' ); ?></h1>

        </header><!-- .page-header -->

        <div class="page-content">

            <?php
            if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>

                <p><?php printf( wp_kses( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'vsstemmart' ), array(
        'a' => array(
            'href' => array(),
        ),
        ) ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>

            <?php elseif ( is_search() ) : ?>

                <p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'vsstemmart' ); ?></p>
                <?php
                    get_search_form();
            else : ?>

                <p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'vsstemmart' ); ?></p>
                <?php
                    get_search_form();
            endif; ?>
        </div><!-- .page-content -->

    </section><!-- .no-results -->
    <?php
    return ob_get_clean();
}
add_filter('velocitytoko_content_loop_none','velocitytoko_content_loop_none_filter');