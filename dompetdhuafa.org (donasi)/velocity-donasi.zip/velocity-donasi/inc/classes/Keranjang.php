<?php
/**
 * class Cart
 *
 * @package velocity-toko
 */

namespace Vsstemmart;

class Keranjang {
    
    public $wpdb;
    public $tablecart;
    public $userid;

    function __construct(){
        global $wpdb;
        $this->wpdb             = $wpdb; 
        $this->tablecart        = $wpdb->prefix. "keranjang";
        $this->userid           = is_user_logged_in()?get_current_user_id():''; 
    }

    //total keranjang
    function count(){
        $result = 0;
        if($this->userid){            
            $datacart   = $this->wpdb->get_results('SELECT sum(jumlah) as result_value FROM ' . $this->tablecart . ' WHERE id_pembeli = ' . $this->userid . '');
            $result     = $datacart?$datacart[0]->result_value:0;
        } else {
            if (isset($_SESSION['keranjang'])) {
                foreach ($_SESSION['keranjang'] as $item) {
                    $result += $item['jumlah'];
                }
            }
        }

        return $result;
    }
    
    function alldata(){
        $result = [];
        if($this->userid){
            $carts  = $this->wpdb->get_results("SELECT * FROM $this->tablecart WHERE id_pembeli = '".$this->userid."'");
            $result = $carts?json_decode( json_encode($carts), true):[];
        } else {
            $result = $_SESSION['keranjang'];
        }
        return $result;
    }

    //tambah item keranjang
    function addItem($idpost=null,$idproduk=null,$jumlah=null,$opsia=null,$opsib=null){

        ///dataItem        
        $opsia  = $opsia?array(get_post_meta($idpost, 'namaopsi', true), $opsia):$opsia;
        $opsib  = $opsib?get_post_meta($idpost, 'namaopsi2', true).'='.$opsib:$opsib;

        if (strpos($opsib, '=') !== false) {
            $opsib = explode('=',$opsib);
        }
        $opsi   = json_encode(array($idpost,$opsia,$opsib));
        $jumlah = $jumlah?$jumlah:1;

        if($this->userid){
            $idpembeli  = $this->userid;
            $sudahada   = $this->wpdb->get_results("SELECT * FROM $this->tablecart WHERE id_pembeli = '".$this->userid."' AND id_produk = '".$idproduk."'");
            if($sudahada){
                $jmltotal = $sudahada[0]->jumlah+$jumlah;
                    $this->wpdb->update($this->tablecart, array(
                            'jumlah'        => $jmltotal,
                        ),
                        array(
                            'id_pembeli'    => $idpembeli,
                            'id_produk'     => $idproduk,
                        )
                    );
            } else {
                $this->wpdb->insert($this->tablecart, array(
                        'id_pembeli'        => $idpembeli,
                        'id_produk'         => $idproduk,
                        'jumlah'            => $jumlah,
                        'detail'            => $opsi,
                    )
                );
            }

        } else {
            if(isset($_SESSION['keranjang'][$idproduk])){
                $jmltotal = $_SESSION['keranjang'][$idproduk]['jumlah']+$jumlah;
                if($stock >= $jmltotal){
                    $_SESSION['keranjang'][$idproduk]= array(
                        'jumlah'    => $jmltotal,
                        'id'        => $idproduk,
                        'detail'    => $opsi,
                    );
                }
            } else {
                $_SESSION['keranjang'][$idproduk]= array(
                    'id'            => $idproduk,
                    'jumlah'        => $jumlah,
                    'detail'        => $opsi,
                );
            }
        }
        
        $result = $this->count();
        return $result;
    }

    //update item keranjang
    function updateItem($idproduk=null,$jumlah=null){ 

        if($jumlah=='0' || $jumlah==''){
            $this->deleteItem($idproduk);
        } else {
            if($this->userid){
                $this->wpdb->update($this->tablecart, array(
                        'jumlah'        => $jumlah,
                    ),
                    array(
                        'id_pembeli'    => $this->userid,
                        'id_produk'     => $idproduk,
                    )
                );
            } else {
                $_SESSION['keranjang'][$idproduk]= array(
                    'id'        => $idproduk,
                    'jumlah'    => $jumlah,
                    'detail'    => $_SESSION['keranjang'][$idproduk]['detail']
                );
            }
        }
        
        $result = $this->count();
        return $result;
    }

    //hapus item keranjang
    function deleteItem($idproduk=null){
        if($this->userid && $idproduk) {
            $this->wpdb->delete( $this->tablecart, array( 'id_pembeli' => $this->userid, 'id_produk'  => $idproduk ) );
        } else {
            unset($_SESSION['keranjang'][$idproduk]);
        }
    }

    //kosongkan keranjang
    function reset(){
        if($this->userid){
            $this->wpdb->delete( $this->tablecart, array( 'id_pembeli' => $this->userid ) );
        } else {
            unset($_SESSION['keranjang']);
        }
    }

}