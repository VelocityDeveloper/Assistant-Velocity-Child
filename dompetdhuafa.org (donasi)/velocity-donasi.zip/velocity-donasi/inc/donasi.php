<?php

add_filter( 'human_time_diff', function($since, $diff, $from, $to) {
    $replace = array(
        'second'  => 'detik',
        'seconds'  => 'detik',
        'min'  => 'menit',
        'mins'  => 'menit',
        'hour'  => 'jam',
        'hours' => 'jam',
        'day'   => 'hari',
        'days'  => 'hari',
        'week'   => 'minggu',
        'weeks'  => 'minggu',
        'month'   => 'bulan',
        'months'  => 'bulan',
        'year'   => 'tahun',
        'years'  => 'tahun',
    );
    return strtr($since, $replace);
}, 10, 4 );