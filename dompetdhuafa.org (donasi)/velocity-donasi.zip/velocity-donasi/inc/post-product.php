<?php
/**
 * Velocity Toko
 */
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Post type Product.
 */
function donasi_setup_post_type() {
    $args = array(
        'labels' => array(
            'name' => 'Donasi',
            'singular_name' => 'donasi',
            'add_new' => 'Tambah Donasi',
            'add_new_item' => 'Tambah Donasi',
            'edit_item' => 'Edit Donasi',
            'view_item' => 'Lihat Donasi',
            'search_items' => 'Cari Donasi',
            'not_found' => 'Tidak ditemukan',
            'not_found_in_trash' => 'Tidak ada Donasi di kotak sampah'
        ),
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
        ),
        'menu_icon'     => VELOCITY_TOKO_PLUGIN_URL.'admin/img/product.png',
        'has_archive'   => 'products',
        'show_in_rest'  => false,
        'public'        => true,
        'taxonomies' => array('products'),
    );
    register_post_type( 'donasi', $args );
}
add_action( 'init', 'donasi_setup_post_type' );

/**
 * Register taxonomy category-product.
 */
add_action( 'init', 'velocitytoko_addon_category_product' );
function velocitytoko_addon_category_product() {
	register_taxonomy(
		'kategori-donasi',
		'donasi',
		array(
			'label' => __( 'Kategori Donasi' ),
			'rewrite' => array( 'slug' => 'kategori-donasi' ),
			'hierarchical' => true,
            'public' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_nav_menus' => true,
		)
	);
}


//Displaying category-product Columns
add_filter( 'manage_taxonomies_for_donasi_columns', 'kategori_donasi_columns' );
function kategori_donasi_columns( $taxonomies ) {
    $taxonomies[] = 'kategori-donasi';
    return $taxonomies;
}

// manage column donasi list
function donasi_custom_columns($defaults,$post_id='') {
    $screen = get_current_screen();
	if($screen->post_type == 'donasi'){
        $columns = array(
            'cb'                            => '<input type="checkbox" />',
            'featured_image'                => 'Image',
            'title'                         => 'Title',
            'taxonomy-kategori-donasi'      => 'Kategori',
            'date'                          => 'Tanggal',
            'biaya'                         => 'Biaya',
            'target'                        => 'Target',
            'terkumpul'                     => 'Terkumpul',
         );
        if( !function_exists( 'WP_Statistics' ) ) {
            $columns['hit'] = 'Hits';
        }
        $columns['biaya'] = __( 'Biaya', 'vsstemmart' );
        $columns['target'] = __( 'Target', 'vsstemmart' );
        $columns['terkumpul'] = __( 'Terkumpul', 'vsstemmart' );
        return $columns;
	} else {
		return $defaults;
	}
}
add_filter('manage_donasi_posts_columns' , 'donasi_custom_columns');

function custom_columns_data( $column, $post_id ) {
    switch ( $column ) {
    case 'featured_image':
        echo '<img style="width: 75px;height: auto;" src="'.get_the_post_thumbnail_url($post_id ,'thumbnail').'" alt="" />';
        break;
    case 'biaya' :
        if(get_post_meta( $post_id , 'harga' , true )){
            echo vsstemmart_number_money(get_post_meta( $post_id , 'harga' , true ));
        } else {
            echo '-';
        }
        break;
        break;
    case 'target' :
        if(get_post_meta( $post_id , 'target' , true )){
            echo vsstemmart_number_money(get_post_meta( $post_id , 'target' , true ));
        } else {
            echo '-';
        }
        break;
        break;
    case 'terkumpul' :
        if(get_post_meta( $post_id , 'totaldonasi' , true )){
            echo vsstemmart_number_money(get_post_meta( $post_id , 'totaldonasi' , true ));
        } else {
            echo '-';
        }
        break;
    case 'hit' :
        if(!function_exists( 'WP_Statistics' ) ) {
            echo get_post_meta($post_id,'hit',true);
        }
        break; 
    }
}
add_action( 'manage_posts_custom_column' , 'custom_columns_data', 10, 2 ); 