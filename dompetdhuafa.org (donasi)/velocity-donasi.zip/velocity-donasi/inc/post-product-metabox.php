<?php
/**
 * Register meta boxes for post product.
 *
 * @package Velocity Toko
 */
 

add_action( 'cmb2_admin_init', 'cmb2_velocity_metaboxes' );
function cmb2_velocity_metaboxes() {
    $text_domain = 'velocity-donasi';
	$cmb = new_cmb2_box( array(
		'id'            => 'velocity_metabox',
		'title'         => __( 'Detail', '' ),
		'object_types'  => array('donasi'), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
	) );

	$cmb->add_field( array(
		'name'       => __( 'Biaya per Donasi', $text_domain ),
		'desc'       => __( 'Isi dengan angka saja tanpa karakter khusus, contoh: 50000', $text_domain ),
		'id'         => 'harga',
		'type' => 'text',
		'before_field' => 'Rp',
		'attributes' => array(
			'type' => 'number',
			'required' => 'required',
		),
	) );

	$cmb->add_field( array(
		'name'       => __( 'Target', $text_domain ),
		'desc'       => __( 'Isi dengan angka saja tanpa karakter khusus, contoh: 2000000', $text_domain ),
		'id'         => 'target',
		'type' => 'text',
		'before_field' => 'Rp',
		'attributes' => array(
			'type' => 'number',
			'required' => 'required',
		),
	) );

	$cmb->add_field( array(
        'name' => 'Tanggal Berakhir',
        'id'   => 'tanggal_berakhir',
        'type' => 'text_date',
        'date_format' => 'Y-m-d',
        'description' => 'Isikan tanggal berakhirnya donasi, contoh: 2022-01-23',
		'attributes' => array(
			'required' => 'required',
		),
	) );

$group_field_id = $cmb->add_field( array(
	'id'          => 'update_info',
	'type'        => 'group',
	'description' => __( 'Isikan update tentang donasi ini', $text_domain ),
	// 'repeatable'  => false, // use false if you want non-repeatable group
	'options'     => array(
		'group_title'       => __( 'Update {#}', $text_domain ), // since version 1.1.4, {#} gets replaced by row number
		'add_button'        => __( 'Tambah', $text_domain ),
		'remove_button'     => __( 'Hapus', $text_domain ),
		'sortable'          => true,
		'closed'         => true, // true to have the groups closed by default
		// 'remove_confirm' => esc_html__( 'Are you sure you want to remove?', $text_domain ), // Performs confirmation before removing group.
	),
) );

// Id's for group's fields only need to be unique for the group. Prefix is not needed.
$cmb->add_group_field( $group_field_id, array(
	'name' => 'Tanggal',
	'id'   => 'tanggal',
	'type' => 'text_date',
    'date_format' => 'Y-m-d',
	'description' => 'Isikan tanggal update, contoh: 2022-01-23',
) );

$cmb->add_group_field( $group_field_id, array(
	'name' => 'Judul Update',
	'id'   => 'judulupdate',
	'type' => 'text',
	// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
) );

$cmb->add_group_field( $group_field_id, array(
	'name' => 'Informasi',
	'description' => 'Isikan perincian update',
	'id'   => 'deskripsiupdate',
	'type' => 'textarea_small',
) );

$cmb->add_group_field( $group_field_id, array(
	'name' => 'Gambar',
	'id'   => 'imageupdate',
	'type' => 'file',
    'query_args' => array(
        'type' => array(
            'image/gif',
            'image/jpeg',
            'image/png',
        ),
    ),
) );

}