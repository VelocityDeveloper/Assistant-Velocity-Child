<?php

/**
 * Regsiter shortcode for Velocity Toko.
 *
 * @package Velocity Toko
 */

// [thumbnail width='250' height='300' crop='false' upscale='true' post_id='']
function vsstemmart_thumbnail($atts)
{
    global $post;
    $html = '';
    $atribut = shortcode_atts(array(
        'width'     => '150',
        'height'    => '300',
        'crop'      => 'false',
        'upscale'   => 'true',
        'flip'      => 'false',
        'post_id'   => $post->ID,
    ), $atts);
    $width          = $atribut['width'];
    $height         = $atribut['height'];
    $crop           = $atribut['crop'];
    $upscale        = $atribut['upscale'];
    $flip           = $atribut['flip'];
    $post_id        = $atribut['post_id'];
    $minorder       = get_post_meta($post_id, 'minorder', true);
    $minorder       = get_post_meta($post_id, 'minorder', true);
    $minorder       = get_post_meta($post_id, 'minorder', true);
    $label          = get_post_meta($post_id, 'label', true);
    if ($minorder) {
        $label      = 'label-grosir ' . $label;
    }
    $url            = get_the_post_thumbnail_url($post_id, 'full');
    $urlkecil       = aq_resize($url, $width / 10, $height / 10, $crop, true, $upscale);
    $urlbesar       = aq_resize($url, $width, $height, $crop, true, $upscale);

    $getharga       = vsstemmart_get_harga($post_id);
    $harga          = $getharga['harga_asli'];
    $hargadiskon    = $getharga['harga_promo'];
    $html          .= '<a class="position-relative" href="' . get_permalink() . '">';

    if ($harga && $hargadiskon) {
        $harga          = preg_replace('/[^0-9]/', '', $harga);
        $hargadiskon    = preg_replace('/[^0-9]/', '', $hargadiskon);
        $hemat          = $harga - $hargadiskon;
        $jadihemat      = number_format($hemat, 0, ',', '.');
        $save           = $hemat / $harga;
        $persen         = $save * 100;
        $jadipersen     = number_format($persen, 0);

        $html .= '<span class="persen-diskon">';
        $html .= '<span>' . $jadipersen . '<small>%</small></span>';
        $html .= '</span>';
    }

    if (has_post_thumbnail()) {
        $urlkecil   = $urlkecil ? $urlkecil : get_the_post_thumbnail_url($post_id, 'thumbnail');
        $urlbesar   = $urlbesar ? $urlbesar : $url;    
        $gallery    = get_post_meta($post_id, 'gallery');
        $label      = $flip=='true'&&$gallery?$label.' thumbnail-flip-hover':$label;    

        $html       .= '<div class="' . $label . '">';
            $html       .= '<img class="lazy img-float" src="' . $urlkecil . '" alt="" data-src="' . $urlbesar . '">';

            //flip
            if ($flip=='true'&&$gallery) {
                $gallery    = $gallery?wp_get_attachment_image_url($gallery[0], 'full'):$gallery;
                $imggall    = aq_resize($gallery, $width, $height, $crop, true, $upscale);
                $html       .= '<img class="lazy img-float second-flip" src="' . $urlkecil . '" alt="" data-src="' . $imggall . '">';
            }

        $html       .= '</div>';
    } else {
        $html .= '<div class="' . $label . '"><svg  style="background-color: #ececec;width: 100%;height: auto;" width="' . $width . '" height="' . $height . '"></svg></div>';
    }
    $html .= '</a>';
    return $html;
}
add_shortcode('thumbnail', 'vsstemmart_thumbnail');


// [thumbnailfull]
function vsstemmart_thumbnailfull()
{
    ob_start();
    global $post;
    $urlkecil       = get_the_post_thumbnail_url($post->ID, 'thumb');
    $urlbesar       = get_the_post_thumbnail_url($post->ID, 'full');
    $minorder       = get_post_meta($post->ID, 'minorder', true);
    $label          = get_post_meta($post->ID, 'label', true);
    if ($minorder) {
        $label      = 'label-grosir ' . $label;
    }

    echo '<a href="' . get_permalink() . '">';
    if (has_post_thumbnail()) {
        echo '<div class="' . $label . '"><img class=" lazy img-float" src="' . $urlkecil . '" alt="" data-src="' . $urlbesar . '"></div>';
    } else {
        echo '<div class="' . $label . '"><svg  style="background-color: #ececec;width: 100%;height: auto;" width="' . $width . '" height="' . $height . '"></svg></div>';
    }
    echo '</a>';

    return ob_get_clean();
}
add_shortcode('thumbnailfull', 'vsstemmart_thumbnailfull');

// [vtoko-excerpt length="150" post_id=""]
function vsstemmart_excerpt($atts)
{
    ob_start();
    global $post;
    $atribut = shortcode_atts(array(
        'length'    => '150',
        'post_id'   => $post->ID,
    ), $atts);
    $post_id  = $atribut['post_id'];
    $length  = $atribut['length'];

    $getpost = get_post($post_id);
    $excerpt = $getpost->post_content;
    $excerpt = strip_tags($excerpt);
    $excerpt = substr($excerpt, 0, (int)$length);
    $excerpt = substr($excerpt, 0, strripos($excerpt, " "));
    $excerpt = $excerpt . '...';
    echo $excerpt;

    return ob_get_clean();
}
add_shortcode('vtoko-excerpt', 'vsstemmart_excerpt');

// [print targetid="print"]
function vsstemmart_print($atts)
{
    $atribut = shortcode_atts(array(
        'targetid'         => 'print',
    ), $atts);
    $targetid = "'" . $atribut['targetid'] . "'";
    $html = '<a onclick="printArea(' . $targetid . ')" class="btn btn-info text-white"><i class="fa fa-print" aria-hidden="true"></i> Print</a>';
    return $html;
}
add_shortcode('print', 'vsstemmart_print');

// [slider-produk]
function vsstemmart_sliderproduk($atts)
{
    ob_start();
    global $post;
    $atribut = shortcode_atts(array(
        'width'         => '300',
        'height'        => '450',
        'crop'          => 'true',
        'upscale'       => 'true',
        'nav-vertical'  => 'false',
        'post_id'  		=> $post->ID,
    ), $atts);
    $nodeid     = uniqid();
    $post_id    = $atribut['post_id'];
    $width      = $atribut['width'];
    $height     = $atribut['height'];
    $crop       = $atribut['crop'];
    $crop       = $crop == 'true' ? true : false;
    $upscale    = $atribut['upscale'];
    $upscale    = $upscale == 'true' ? true : false;
    $navertical = $atribut['nav-vertical'];
    $gallery    = get_post_meta($post_id, 'gallery');
    $minorder   = get_post_meta($post_id, 'minorder', true);
    $label      = get_post_meta($post_id, 'label', true);

    echo    '<div class="velocitytoko-slider-produk velocitytoko-'.$nodeid.'" nodeid="'.$nodeid .'">';
    $html   = '';

    $dataimg    = [];
    if (has_post_thumbnail($post_id)) {
        $imgfull    = get_the_post_thumbnail_url($post_id, 'full');
        $dataimg[]  = [
            'id'        => get_post_thumbnail_id($post_id),
            'full'      => $imgfull,
            'urlkecil'  => aq_resize($imgfull, $width / 10, $height / 10, $crop, true, $upscale),
            'urlbesar'  => aq_resize($imgfull, $width, $height, $crop, true, $upscale),
        ];
    }
    if ($gallery) {
        foreach ($gallery as $img) {
            $imgfull    = wp_get_attachment_image_url($img, 'full');
            $dataimg[]  = [
                'id'        => $img,
                'full'      => $imgfull,
                'urlkecil'  => aq_resize($imgfull, $width / 10, $height / 10, $crop, true, $upscale),
                'urlbesar'  => aq_resize($imgfull, $width, $height, $crop, true, $upscale),
            ];
        }
    }

    if ($minorder) {
        $label      = 'label-grosir ' . $label;
    }
    if ($dataimg) {
        $html .= '<div class="row">';
        if ($dataimg) {

            $lp = $navertical=='true'?'col-md-8 col-xl-9':'col-12';
            $html .= '<div class="col-parent '.$lp.'">';
                $html .= '<div class="' . $label . ' slider-produk">';
                    $html .= '<div class="id-' . $post_id . '" id="parent-container">';
                    foreach ($dataimg as $image) {
                        $urlkecil = $image['urlkecil'] ? $image['urlkecil'] : $image['full'];
                        $urlbesar = $image['urlbesar'] ? $image['urlbesar'] : $image['full'];
                        $html .= '<div class="p-1">';
                            $html .= '<a href="' . $image['full'] . '">';
                            $html .= '<img class="lazy img-float img-fluid w-100" src="' . $urlkecil . '" alt="" data-src="' . $urlbesar . '">';
                            $html .= '</a>';
                        $html .= '</div>';
                    }
                    $html .= '</div>';
                $html .= '</div>';
            $html .= '</div>';

            if (!empty($gallery)) {
                $ln = $navertical=='true'?'col-md-3 col-xl-2':'col-12';
                $html .= '<div class="col-navigasi '.$ln.'">';
                    $html .= '<div class="navigasi navid-' . $post_id . '">';
                    foreach ($dataimg as $image) {
                        $urlkecil = $image['urlkecil'] ? $image['urlkecil'] : $image['full'];
                        $urlbesar = $image['urlbesar'] ? $image['urlbesar'] : $image['full'];
                        $html .= '<div class="px-1 pb-1">';
                        $html .= '<img class="lazy img-float img-fluid w-100" src="' . $urlkecil . '" alt="" data-src="' . $urlbesar . '">';
                        $html .= '</div>';
                    }
                    $html .= '</div>';
                $html .= '</div>';
            }
        }
        $html .= '</div>';
    } else {
        $html = '<div class="' . $label . ' slider-produk">';
        $url = '<div class="p-1"><svg  style="background-color: #ececec;width: 100%;height: auto;" width="' . $width . '" height="' . $height . '"></svg></div>';
            $html .= '<div class="id-' . $post_id . '">';
            $html .= $url;
            $html .= '</div>';
        $html .= '</div>';
    }
?>
    <script>
        jQuery(function($) {
            $('.id-<?php echo $post_id; ?>').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                asNavFor: '.navid-<?php echo $post_id; ?>',
                autoplay: false,
            });
            $('.navid-<?php echo $post_id; ?>').slick({
                slidesToShow: 4,
                slidesToScroll: 1,
                asNavFor: '.id-<?php echo $post_id; ?>',
                focusOnSelect: true,
                arrows: true,
                autoplay: false,
                vertical: <?php echo $navertical; ?>,
                responsive : [
                    { 
                        breakpoint: 768, 
                        settings: {                            
                            vertical: false,
                        }
                    }
                ],
            });
            $('#parent-container').magnificPopup({
                delegate: 'a', // child items selector, by clicking on it popup will open
                type: 'image',
                gallery: {
                    enabled: true
                }
                // other options
            });
        });
    </script>
    <?php
    echo $html;
    echo '</div>';
    return ob_get_clean();
}
add_shortcode('slider-produk', 'vsstemmart_sliderproduk');

// [harga diskon='true' countdown='true' post_id='']
function vsstemmart_harga($atts)
{
    global $post;
    $atribut = shortcode_atts(array(
        'diskon'        => 'true',
        'countdown'     => 'true',
        'post_id'     	=> $post->ID,
    ), $atts);
    $post_id        = $atribut['post_id'];
    $diskon         = $atribut['diskon'];
    $countdown      = $atribut['countdown'];
    $getharga       = vsstemmart_get_harga($post_id);
    $harga          = $getharga['harga'];
    $hargadiskon    = $getharga['harga_promo'];
    $hargaasli      = $getharga['harga_asli'];
    $metaflashsale  = get_post_meta($post_id, 'flashsale', true);
    $flashsale      = date("U", strtotime($metaflashsale));

    $html = '<span class="frame-harga">';
    if ($hargadiskon && $flashsale) {
        if ($flashsale < date('U')) {
            update_post_meta($post_id, 'harga_promo', '');
            update_post_meta($post_id, 'flashsale', '');
        }
        if ($countdown == 'true') {
            $html .= '<small><i class="fa fa-clock-o text-colortheme" aria-hidden="true"></i> <span data-countdown="' . $metaflashsale . '"></span></small><br>';
        }
    }

    if ($harga) {
        if ($hargadiskon && $flashsale) {
            $html .= '<span class="harga-diskon">' . vsstemmart_number_money($hargadiskon) . '</span> ';
            if ($diskon == 'true') {
                $html .= '<small class="text-danger"><s>' . vsstemmart_number_money($hargaasli) . '</s></small>';
            }
        } else if ($hargadiskon) {
            $html .= '<span class="harga-diskon">' . vsstemmart_number_money($hargadiskon) . '</span> ';
            if ($diskon == 'true') {
                $html .= '<small class="text-danger"><s>' . vsstemmart_number_money($hargaasli) . '</s></small>';
            }
        } else {
            $html .= vsstemmart_number_money($harga);
        }
        $html .= '</span>';
    } else {
        $html = '<span class="frame-harga">-';
        $html .= '</span>';
    }

    return $html;
}
add_shortcode('harga', 'vsstemmart_harga');

// [love text='true']
function vsstemmart_love($atts)
{
    global $post;
    $atribut        = shortcode_atts(array(
        'text'          => 'false',
        'class'         => '',
        'text-add'      => '',
        'text-remove'   => '',
        'post_id'   	=> $post->ID,
    ), $atts);
    $post_id        = $atribut['post_id'];
    $text           = $atribut['text'];
    $classe         = $atribut['class'];
    $textadd        = $atribut['text-add'];
    $textremove     = $atribut['text-remove'];

    $user_id        = get_current_user_id();
    if (!empty(get_user_meta($user_id, 'love', true))) {
        $ada        = json_decode(get_user_meta($user_id, 'love', true), true);
    } else {
        $ada = array();
    }
    if ($text == 'true') {
        $class      = 'btn btn-outline-danger text w-100';
        $add        = $textadd?$textadd:'Tambah Favorit';
        $remove     = $textremove?$textremove:'Hapus Favorit';
    } else {
        $class      = '';
        $add        = '';
        $remove     = '';
    }
    $class          = $classe?$classe:$class;

    if (in_array($post_id, $ada) && is_user_logged_in()) {
        $html = '<span onclick="love(' . $post_id . ')" class="' . $class . ' love love-' . $post_id . '"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart-fill" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z"/> </svg> ' . $remove . '</span>';
    } else if (is_user_logged_in()) {
        $html = '<span onclick="love(' . $post_id . ')" class="' . $class . ' love unlove love-' . $post_id . '"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart-fill" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z"/> </svg> ' . $add . '</span>';
    } else {
        $html = '<span data-toggle="tooltip" title="Silahkan Login Untuk menambah wishlist." class="' . $class . ' love unlove love-' . $post_id . '"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart-fill" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z"/> </svg> ' . $add . '</span>';
    }
    return $html;
}
add_shortcode('love', 'vsstemmart_love');

// [cart]
function vsstemmart_cart($atts)
{
    ob_start();
    $atribut        = shortcode_atts(array(
        'table-cart'    => 'false',
    ), $atts);
    $tablecart  = $atribut['table-cart'];

    $html       = '';    
    $Cart       = new Vsstemmart\Keranjang;
    $count      = $Cart->count();

    echo '<span id="cart" class="position-relative cart">';

        if($tablecart == 'false'){ 
            echo '<a href="' . get_permalink(get_page_by_path('Keranjang')) . '" class="position-relative d-inline-block">';
        } else {
            echo '<span class="position-relative toggle-tablecart">';
        }
            echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-fill" viewBox="0 0 16 16"> <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/> </svg> ';
            echo '<small class="totalpembeli">' . $count . '</small>';

        if($tablecart == 'false'){ 
            echo '</a>';
        } else {
            echo '</span>';
        }

        if($tablecart == 'true'){
            echo '<span class="table-cart" style="display:none;">'; 
                echo velocitytoko_display_tablecart();
            echo '</span>';
        }
    echo '</span>';

    return ob_get_clean();
}
add_shortcode('cart', 'vsstemmart_cart');

// [profile]
function vsstemmart_profile() {
    if ( is_user_logged_in() ) {
        $text = 'Profil Saya';
    } else {
        $text = 'Login Donatur';
    }
    $icon = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16"> <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/> </svg>';
    $html = '<span class="linkprofile"><a href="'.get_permalink(get_page_by_path('myaccount')).'">'.$icon.' '.$text.'</a></span>';
    return $html;
}
add_shortcode('profile', 'vsstemmart_profile');

// [paypal]
function vsstemmart_paypal()
{
    $html  = '<div class="d-inline-block">';
    $html .= '<img src="https://www.paypalobjects.com/webstatic/en_US/i/buttons/checkout-logo-large.png" alt="Check out with PayPal" />';
    $html .= '</div>';
    return $html;
}
add_shortcode('paypal', 'vsstemmart_paypal');

//[bank logo="true" atasnama="true" norek="true"]
function vsstemmart_bank($atts)
{
    ob_start();
    $atribut = shortcode_atts(array(
        'logo'      => 'true',
        'atasnama'  => 'true',
        'norek'     => 'true',
    ), $atts);
    $logo           = $atribut['logo'];
    $atasnama       = $atribut['atasnama'];
    $norek          = $atribut['norek'];

    $databank       = velocitytoko_option('databank_velocitytoko', []);
    $databanklain   = velocitytoko_option('databanklain_velocitytoko');

    if ($databanklain) {
        foreach ($databanklain as $key => $value) {
            if ($value['namabank']) {
                array_push($databank, $databanklain[$key]);
            }
        }
    }

    echo '<div class="frame-bank" style="text-align:center">';
    if ($databank) {
        foreach ($databank as $key => $bank) {
            if ($bank['namabank']) {
                echo '<span class="d-inline-block" data-bank="' . $bank['namabank'] . '">';
                if ($logo == 'true') {
                    if (isset($bank['logo'])) {
                        $urllogo = $bank['logo'];
                    } else {
                        $urllogo = VELOCITY_TOKO_PLUGIN_URL . 'public/img/b-' . $bank['namabank'] . '.gif';
                    }
                    echo '<img style="display:block" alt="Bank ' . strtoupper($bank['namabank']) . '" src="' . $urllogo . '">';
                }
                if ($norek == 'true') {
                    echo '<span>' . $bank['nobank'] . '<br>';
                }
                if ($atasnama == 'true') {
                    echo '<small>a/n ' . $bank['atasnama'] . '</small></span>';
                }
                echo '</span>';
            }
        }
    }
    echo '</div>';

    return ob_get_clean();
}
add_shortcode('bank', 'vsstemmart_bank');


// [view]
function vsstemmart_getPostViews($atts)
{
    global $post;
    $atribut = shortcode_atts(array(
        'post_id'   => $post->ID,
    ), $atts);
    $post_id	= $atribut['post_id'];
    $count_key      = 'hit';
    $count          = get_post_meta($post_id, $count_key, true);
    if ($count == '') {
        delete_post_meta($post_id, $count_key);
        add_post_meta($post_id, $count_key, '0');
        return "0 Kali";
    }
    return $count . ' Kali';
}
add_shortcode('view', 'vsstemmart_getPostViews');

// [share]
function vsstemmart_share($atts)
{
    global $post;
    $atribut = shortcode_atts(array(
        'post_id'   => $post->ID,
    ), $atts);
    $post_id	= $atribut['post_id'];
	// Get current post URL 
    $post_url = urlencode(get_permalink($post_id));
    // Get current post title
    $post_title = str_replace( ' ', '%20', get_the_title($post_id));
    // Construct sharing URL without using any script
    $twitterURL = 'https://twitter.com/intent/tweet?text='.$post_title.'&amp;url='.$post_url;
    $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$post_url;
    $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$post_url.'&amp;title='.$post_title;
    $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$post_url.'&amp;description='.$post_title;
    $whatsappURL ='https://api.whatsapp.com/send?text='.$post_url.'';
    $telegramURL ='https://telegram.me/share/url?url='.$post_url.'';
    $emailURL ='mailto:?subject='.$post_title.'&amp;body='.$post_title.' '.$post_url.' ';
 
    // Add sharing button
	$class = 'me-2 d-inline-block btn-sosmed';
    $html	= '<div class="frame-share">';
		$html   .= '<span class="me-2 text-dark" >Bagikan: </span>';
		$html	.= '<a class="'.$class.' color-twit" href="'.$twitterURL.'" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16"><path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/></svg></a>';
		$html	.= '<a class="'.$class.' color-fb" href="'.$facebookURL.'" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16"><path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/></svg></a>';
		$html	.= '<a class="'.$class.' color-wa" href="'.$whatsappURL.'" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 16 16"><path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/></svg></a>';
		$html	.= '<a class="'.$class.' color-pinterest" href="'.$pinterestURL.'" data-pin-custom="true" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pinterest" viewBox="0 0 16 16"><path d="M8 0a8 8 0 0 0-2.915 15.452c-.07-.633-.134-1.606.027-2.297.146-.625.938-3.977.938-3.977s-.239-.479-.239-1.187c0-1.113.645-1.943 1.448-1.943.682 0 1.012.512 1.012 1.127 0 .686-.437 1.712-.663 2.663-.188.796.4 1.446 1.185 1.446 1.422 0 2.515-1.5 2.515-3.664 0-1.915-1.377-3.254-3.342-3.254-2.276 0-3.612 1.707-3.612 3.471 0 .688.265 1.425.595 1.826a.24.24 0 0 1 .056.23c-.061.252-.196.796-.222.907-.035.146-.116.177-.268.107-1-.465-1.624-1.926-1.624-3.1 0-2.523 1.834-4.84 5.286-4.84 2.775 0 4.932 1.977 4.932 4.62 0 2.757-1.739 4.976-4.151 4.976-.811 0-1.573-.421-1.834-.919l-.498 1.902c-.181.695-.669 1.566-.995 2.097A8 8 0 1 0 8 0z"/></svg></a>';
		$html	.= '<a class="'.$class.' color-linkedin" href="'.$linkedInURL.'" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-linkedin" viewBox="0 0 16 16"><path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854V1.146zm4.943 12.248V6.169H2.542v7.225h2.401zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248-.822 0-1.359.54-1.359 1.248 0 .694.521 1.248 1.327 1.248h.016zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016a5.54 5.54 0 0 1 .016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225h2.4z"/></svg></a>';
		$html	.= '<a class="'.$class.' color-telegram" href="'.$telegramURL.'" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telegram" viewBox="0 0 16 16"><path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.287 5.906c-.778.324-2.334.994-4.666 2.01-.378.15-.577.298-.595.442-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294.26.006.549-.1.868-.32 2.179-1.471 3.304-2.214 3.374-2.23.05-.012.12-.026.166.016.047.041.042.12.037.141-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8.154 8.154 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629.093.06.183.125.27.187.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.426 1.426 0 0 0-.013-.315.337.337 0 0 0-.114-.217.526.526 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09z"/></svg></a>';
		$html	.= '<a class="'.$class.' color-email" href="'.$emailURL.'" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16"><path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2Zm13 2.383-4.708 2.825L15 11.105V5.383Zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741ZM1 11.105l4.708-2.897L1 5.383v5.722Z"/></svg></a>';
    $html	.= '</div>';        
    return $html;
}
add_shortcode('share','vsstemmart_share');

// [donasi-lain]
function vsstemmart_donasilain($atts)
{
    global $post;
    $atribut = shortcode_atts(array(
        'post_id'   => $post->ID,
    ), $atts);
    $post_id	= $atribut['post_id'];
    $nosms  = velocitytoko_option('nosms_velocitytoko');
    if ($nosms && substr($nosms, 0, 1) === '0') {
        $nosms = '+62' . substr($nosms, 1);
    }
    $notlp  = velocitytoko_option('notlp_velocitytoko');
    if ($notlp && substr($notlp, 0, 1) === '0') {
        $notlp   = '+62' . substr($notlp, 1);
    }
    $nowa   = velocitytoko_option('nowa_velocitytoko');
    if ($nowa && substr($nowa, 0, 1) === '0') {
        $nowa    = '62' . substr($nowa, 1);
    } else if ($nowa && substr($nowa, 0, 1) === '+') {
        $nowa    = '' . substr($nowa, 1);
    }
    $notelegram     = velocitytoko_option('notelegram_velocitytoko');
    $emailktoko     = velocitytoko_option('emailtoko_velocitytoko');
    $isipesan       = 'Saya mau donasi ' . get_the_title($post_id);
    $html           = '<h4 class="belilain">Donasi juga dapat menghubungi:</h4>';
    if ($nowa) {
        $html       .= '<a target="_blank" class="me-2 btn-sm btn btn-outline-dark" href="https://wa.me/' . $nowa . '?text=' . $isipesan . '"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 16 16"> <path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/> </svg> Whatsapp</a>';
    }
    if ($nosms) {
        $html       .= '<a class="me-2 btn-sm btn btn-outline-dark" href="sms:' . $nosms . '?body=' . $isipesan . '"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chat-right-text" viewBox="0 0 16 16"> <path d="M2 1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h9.586a2 2 0 0 1 1.414.586l2 2V2a1 1 0 0 0-1-1H2zm12-1a2 2 0 0 1 2 2v12.793a.5.5 0 0 1-.854.353l-2.853-2.853a1 1 0 0 0-.707-.293H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12z"/> <path d="M3 3.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM3 6a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 3 6zm0 2.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/> </svg> SMS</a>';
    }
    if ($notlp) {
        $html       .= '<a class="me-2 btn-sm btn btn-outline-dark" href="tel:' . $notlp . '"><i class="fa fa-phone" aria-hidden="true"></i> Telp</a>';
    }
    if ($notelegram) {
        $html       .= '<a target="_blank" class="me-2 btn-sm btn btn-outline-dark" href="https://telegram.me/' . $notelegram . '"><i class="fa fa-telegram" aria-hidden="true"></i> Telegram</a>';
    }
    return $html;
}
add_shortcode('donasi-lain', 'vsstemmart_donasilain');

// [kontak]
function vsstemmart_kontak()
{
    $nosms  = velocitytoko_option('nosms_velocitytoko');
    if (substr($nosms, 0, 1) === '0') {
        $nosms        = '+62' . substr($nosms, 1);
    }
    $notlp  = velocitytoko_option('notlp_velocitytoko');
    if (substr($notlp, 0, 1) === '0') {
        $notlp        = '+62' . substr($notlp, 1);
    }
    $nowa   = velocitytoko_option('nowa_velocitytoko');
    if (substr($nowa, 0, 1) === '0') {
        $nowa         = '62' . substr($nowa, 1);
    }
    $notelegram     = velocitytoko_option('notelegram_velocitytoko');
    $emailktoko     = velocitytoko_option('emailtoko_velocitytoko');
    $html            = '';
    $isipesan        = 'Hallo ' . get_bloginfo('name');
    if ($nosms) {
        $html       .= '<a class="btn-sm d-block mb-1 btn btn-outline-dark" href="sms:' . $nosms . '?body=' . $isipesan . '">';
        $html       .= '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chat-right-text" viewBox="0 0 16 16"> <path d="M2 1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h9.586a2 2 0 0 1 1.414.586l2 2V2a1 1 0 0 0-1-1H2zm12-1a2 2 0 0 1 2 2v12.793a.5.5 0 0 1-.854.353l-2.853-2.853a1 1 0 0 0-.707-.293H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12z"/> <path d="M3 3.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM3 6a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 3 6zm0 2.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/> </svg>';
        $html       .= '<span class="kontak-caption"> SMS: ' . $nosms . '</span>';
        $html       .= '</a>';
    }
    if ($notlp) {
        $html       .= '<a class="btn-sm d-block mb-1 btn btn-outline-dark" href="tel:' . $notlp . '">';
        $html       .= '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone" viewBox="0 0 16 16"> <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122l-2.19.547a1.745 1.745 0 0 1-1.657-.459L5.482 8.062a1.745 1.745 0 0 1-.46-1.657l.548-2.19a.678.678 0 0 0-.122-.58L3.654 1.328zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/> </svg>';
        $html       .= '<span class="kontak-caption"> Telp: ' . $notlp . '</span>';
        $html       .= '</a>';
    }
    if ($nowa) {
        $html       .= '<a target="_blank" class="btn-sm d-block mb-1 btn btn-outline-dark" href="https://wa.me/' . $nowa . '?text=' . $isipesan . '">';
        $html       .= '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 16 16"> <path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/> </svg>';
        $html       .= '<span class="kontak-caption"> Whatsapp: ' . $nowa . '</span>';
        $html       .= '</a>';
    }
    if ($notelegram) {
        $html       .= '<a target="_blank" class="btn-sm d-block mb-1 btn btn-outline-dark" href="https://telegram.me/' . $notelegram . '">';
        $html       .= '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telegram" viewBox="0 0 16 16"> <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.287 5.906c-.778.324-2.334.994-4.666 2.01-.378.15-.577.298-.595.442-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294.26.006.549-.1.868-.32 2.179-1.471 3.304-2.214 3.374-2.23.05-.012.12-.026.166.016.047.041.042.12.037.141-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8.154 8.154 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629.093.06.183.125.27.187.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.426 1.426 0 0 0-.013-.315.337.337 0 0 0-.114-.217.526.526 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09z"/></svg>';
        $html       .= '<span class="kontak-caption"> Telegram: ' . $notelegram . '</span>';
        $html       .= '</a>';
    }
    if ($emailktoko) {
        $html       .= '<a target="_blank" class="btn-sm d-block mb-1 btn btn-outline-dark" href="mailto:' . $emailktoko . '">';
        $html       .= '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16"> <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2Zm13 2.383-4.708 2.825L15 11.105V5.383Zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741ZM1 11.105l4.708-2.897L1 5.383v5.722Z"/> </svg>';
        $html       .= '<span class="kontak-caption"> Email: ' . $emailktoko . '</span>';
        $html       .= '</a>';
    }
    return $html;
}
add_shortcode('kontak', 'vsstemmart_kontak');

// [beli text='true']
function vsstemmart_beli($atts) {
    global $post;
    $atribut        = shortcode_atts( array(
        'text'      => 'false',
    ), $atts );
    $text           = $atribut['text'];
    if($text == 'true'){
        $class      = 'btn text-white text bg-colortheme w-100';
        $add        = 'Donasi';
    } else {
        $class      = 'text-colortheme';
        $add        = '';
    }
    $harga          = get_post_meta($post->ID, 'harga', true);
    $target          = get_post_meta($post->ID, 'target', true);
    $tanggal_berakhir = get_post_meta($post->ID, 'tanggal_berakhir', true);
    $html           = '';
    $html .= '<input type="hidden" id="redirect-'.$post->ID.'" value="'.get_home_url().'/keranjang">';
    if(!empty($target) && !empty($harga)){
		if(is_single()){			
			$html .= '<div class="mb-2 mt-3 fs-6 fw-bold">Paket Donasi @ Rp '.number_format($harga,0,',','.').'</div>';
			$html .= '<div class="mb-2 text-secondary">Jumlah (Qty)</div>';
			$html .= '<input type="number" class="form-control mb-2" id="jumlah-'.$post->ID.'" value="1" min="1">';
		} else {
			$html .= '<input type="hidden" id="jumlah-'.$post->ID.'" value="1">';
		}
        $sekarang = date('Y-m-d');
        $waktusekarang = date('Y-m-d', strtotime($sekarang));
        $ditutup = date('Y-m-d', strtotime($tanggal_berakhir));
        if (!empty($tanggal_berakhir) && $waktusekarang <= $ditutup) {
            $html .= '<a onclick="beli('.$post->ID.')" class="'.$class.' pointer beli beli-'.$post->ID.'"  data-text="' . $add . '">'.$add.'</a>';
        } else {
            $html .= '<a data-toggle="tooltip" title="Donasi Ditutup" class="btn text-white text btn-secondary w-100" >Donasi Ditutup</a>';
        }
    } else {
        $html .= '<a onclick="belix('.$post->ID.')" data-toggle="tooltip" title="Hubungi CS" class="'.$class.' pointer beli-x beli-x-'.$post->ID.'" ><i class="fa fa-shopping-cart"></i> '.$add.'</a>';
    }
    return $html;
}
add_shortcode( 'beli', 'vsstemmart_beli' );



//[list-group-taxonomy taxonomy="kategori-donasi"]
add_shortcode('list-group-taxonomy', 'vd_list_group_taxonomy');
function vd_list_group_taxonomy($atts)
{
    ob_start();
    $atribut = shortcode_atts(array(
        'taxonomy'  => 'kategori-donasi',
    ), $atts);
    $taxonomy       = $atribut['taxonomy'];
    $nodeid         = uniqid();
    $gettaxonomy    = get_categories(array('taxonomy' => $taxonomy, 'parent'  => 0, 'hide_empty' => 0));
    if ($gettaxonomy) :
    ?>
        <div class="list-group-taxonomy">
            <div class="list-group">
                <?php foreach ($gettaxonomy as $tax) : ?>

                    <?php
                    ///get child by parent id taxonomy
                    $getchild       = get_categories(array('taxonomy' => $taxonomy, 'parent'  => $tax->term_id, 'hide_empty' => 0));
                    $idnodechild    = $nodeid . '-' . $tax->term_id;
                    ?>

                    <div class="list-group-item list-group-item-action px-3">
                        <a href="<?php echo get_term_link($tax->slug, $taxonomy); ?>">
                            <?php echo $tax->name; ?>
                        </a>

                        <?php if ($getchild) : ?>
                            <span class="float-end" data-toggle="collapse" data-target="#child-list-<?php echo $idnodechild; ?>" aria-expanded="false" aria-controls="child-list-<?php echo $idnodechild; ?>">
                                <i class="fa fa-plus"></i>
                            </span>
                        <?php endif; ?>
                    </div>

                    <?php if ($getchild) : ?>
                        <div id="child-list-<?php echo $idnodechild; ?>" class="collapse">
                            <?php foreach ($getchild as $taxchild) : ?>
                                <div class="list-group-item list-group-item-action ps-4 pe-3">
                                    <a href="<?php echo get_term_link($taxchild->slug, $taxonomy); ?>">
                                        <?php echo $taxchild->name; ?>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>


                <?php endforeach; ?>
            </div>
        </div>
    <?php
    endif;
    return ob_get_clean();
}

//[carousel-product limit="3"]
add_shortcode('carousel-product', 'vd_carouselproduct');
function vd_carouselproduct($atts)
{
    ob_start();
    $atribut = shortcode_atts(array(
        'category' => '',
        'limit'    => '',
        'label'    => '',
        'layout'   => '1',
    ), $atts);
    $category       = $atribut['category'];
    $limit          = $atribut['limit'];
    $label          = $atribut['label'];
    $layout         = $atribut['layout'];
    $nodeid         = uniqid();

    // The Query
    $args = array(
        'post_type' => 'donasi',
        'post_status' => 'publish',
        'posts_per_page' => $limit,
    );

    //if set category id
    if ($category) :
        $args['tax_query'] = [[
            'taxonomy' => 'kategori-donasi',
            'field' => 'term_id',
            'terms' => $category,
        ]];
    endif;

    //if set label meta
    if ($label) :
        $args['meta_key'] = 'label';
        $args['meta_value'] = 'label-' . $label;
    endif;

    $the_query = new WP_Query($args);

    ?>
    <div class="carousel-product carousel-product-<?php echo $nodeid; ?>" data-layout="<?php echo $layout; ?>" data-node="<?php echo $nodeid; ?>">
        <?php if ($the_query->have_posts()) : ?>
            <div class="carousel-product-loop product-<?php echo $nodeid; ?>">
                <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
                    <div class="carousel-product-item">

                        <?php if ($layout == '2') : ?>

                            <div class="row">
                                <div class="col-4 col-md-3 pe-0 col-thumbnail">
                                    <?php echo get_the_post_thumbnail(get_the_id(), 'thumbnail', array('class' => 'carousel-product-img w-100')); ?>
                                </div>
                                <div class="col col-content">
                                    <a href="<?php echo get_the_permalink(); ?>" class="carousel-product-title">
                                        <?php echo get_the_title(); ?>
                                    </a>
                                    <div class="carousel-product-excerpt font-italic">
                                        <small>
                                            <?php echo do_shortcode('[vtoko-excerpt length="70"]'); ?>
                                        </small>
                                    </div>
                                    <div class="carousel-product-harga text-primary">
                                        <?php echo do_shortcode('[harga]'); ?>
                                    </div>
                                </div>
                            </div>

                        <?php else : ?>

                            <div class="col-productpost text-center">
                                <div class="col-thumbnail px-2 pb-2">
                                    <?php echo do_shortcode("[thumbnail width='150' height='150' crop='false' upscale='true']"); ?>
                                </div>
                                <div class="col-content">
                                    <a href="<?php echo get_the_permalink(); ?>" class="carousel-product-title">
                                        <?php echo get_the_title(); ?>
                                    </a>
                                </div>
                            </div>

                        <?php endif; ?>

                    </div>
                <?php endwhile; ?>
            </div>
            <script>
                jQuery(document).ready(function($) {
                    $('.product-<?php echo $nodeid; ?>').slick({
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        autoplay: true,
                        autoplaySpeed: 2000,
                        arrows: false,
                    });
                });
            </script>
        <?php endif; ?>
    </div>
<?php
    /* Restore original Post Data */
    wp_reset_postdata();

    return ob_get_clean();
}

//[vtoko-search-product]
add_shortcode('vtoko-search-product', 'vtoko_searchproduct');
function vtoko_searchproduct($atts)
{
    ob_start();
    $atribut = shortcode_atts(array(
        'layout'        => 'stacked', //stacked, inline
        'placeholder'   => 'Cari produk...',
        'category'      => 'true', //true or false
        'buttontext'    => 'Cari',
    ), $atts);
    $layout         = $atribut['layout'];
    $placeholder    = $atribut['placeholder'];
    $category       = $atribut['category'];
    $buttontext		= $atribut['buttontext'];

    $formrow        = $layout == 'inline' ? 'form-row d-flex' : 'form-stacked';
    ?>
    <div class="vtoko-search-product" data-layout="<?php echo $layout; ?>">
        <form action="<?php echo home_url('/products'); ?>" method="get">
            <div class="<?php echo $formrow; ?>">
                <div class="<?php echo $layout == 'inline'?'form-group':'form-group mb-2'; ?>">
                    <input type="text" name="s" class="form-control" placeholder="<?php echo $placeholder; ?>">
                </div>

                <?php if ($category == 'true') : ?>
                    <?php
                    $getcategory = get_terms(array(
                        'taxonomy' => 'kategori-donasi',
                        'hide_empty' => false,
                    ));
                    ?>
                    <?php if ($getcategory) : ?>
                        <div class="<?php echo $layout == 'inline'?'form-group':'form-group mb-2'; ?>">
                            <select name="setkategori[]" class="form-control">
                                <?php foreach ($getcategory as $cat) : ?>
                                    <option value="<?php echo $cat->term_id; ?>"><?php echo $cat->name; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <div class="<?php echo $layout == 'inline'?'form-group':'form-group mb-2'; ?> text-center">
                    <button type="submit" class="btn btn-primary"> 
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16"> <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/> </svg>  
                        <?php echo $buttontext; ?>
                    </button>
                </div>
            </div>
        </form>
    </div>
<?php
    return ob_get_clean();
}



//[vtoko-sosmed]
add_shortcode('vtoko-sosmed', 'vtoko_getsosmed');
function vtoko_getsosmed($atts)
{
    ob_start();
    $sosmedava = ['facebook', 'instagram', 'twitter', 'youtube'];

    if ($atts) :
        echo '<div class="vtoko-sosmed">';
        foreach ($atts as $key => $value) {

            if (in_array($key, $sosmedava)) {
                $captionkey = 'caption-'.$key;
                $caption    = isset($atts[$captionkey])?$atts[$captionkey]:'Follow us';

                echo '<a href="' . $value . '" target="_blank" class="vtoko-sosmed-item text-white d-block bg-secondary mb-2 p-3 ' . $key . '">';
                echo '<div class="row align-items-center">';
                echo '<div class="col-3 text-center">';
                echo '<i class="fa fa-2x fa-' . $key . '"></i>';
                echo '</div>';
                echo '<div class="col">';
                echo '<div>'.$caption.'</div>';
                echo '<div class="h4 m-0 text-white">' . ucfirst($key) . '</div>';
                echo '</div>';
                echo '</div>';
                echo '</a>';
            }
        }
        echo '</div>';
    endif;

    return ob_get_clean();
}

// [cari]
function cariform() {
    $html = '<div class="vel-cari">
       <span class="tombols"></span>
       <form action="'.get_home_url().'" method="get" id="formsearchvel" style="display: none;">
        <input class="search-input" name="s" placeholder="Search.." type="text" required>
        <button class="search-button" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
       </form>
    </div>';
    return $html;
}
add_shortcode ('cari', 'cariform');
    


/* ================== SHORTCODE DONASI ================== */

// [progress]
function vsstemmart_progress($atts) {
    global $post,$wpdb;
    $atribut = shortcode_atts(array(
        'post_id' => $post->ID,
    ), $atts);
    $post_id = $atribut['post_id'];
    $target = get_post_meta( $post_id, 'target', true );
    $total_donasi = get_post_meta( $post_id, 'totaldonasi', true );
    $tanggal_berakhir = get_post_meta( $post_id, 'tanggal_berakhir', true );
    $harga = preg_replace('/[^0-9]/', '', $target);
    $hargatarget = vsstemmart_number_money($harga);
    if($total_donasi){
        $totaldonasi = $total_donasi;
    } else {
        $totaldonasi = '0';
    }
	$sisadonasi = $target - $totaldonasi;
	$save =  $totaldonasi / $target;
	$persen = $save * 100;
	$jadipersen = number_format($persen,1);
    /*	if($sisadonasi > 0){
		$persen = $jadipersen;
	} else {
		$persen = 100;
	} */
    $semuadonasi = !empty($totaldonasi) ? vsstemmart_number_money($totaldonasi) : 'Rp 0';
    $html  = '';
	$html .= '<div class="mt-2 text-primary">'.$semuadonasi.'</div>';
    if(!empty($target)){
        $html .= '<div class="mb-2"><small class="text-muted">terkumpul dari <b>'.vsstemmart_number_money($target).'</b></small></div>';
    }	
    $html .= '<div class="progress vel-progress">';
        $html .= '<div class="progress-bar bg-success" role="progressbar" style="width: '.$persen.'%" aria-valuenow="'.$persen.'" aria-valuemin="0" aria-valuemax="100">';
            //$html .= '<div class="progress-persen">'.$persen.'%</div>';
        $html .= '</div>';
    $html .= '</div>';
    $totaldonatur = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}donatur WHERE id_produk = '{$post_id}'");
    $html .= '<div class="row mt-2 text-muted">';
        $html .= '<div class="col-6">';
            $html .= '<small>'.$totaldonatur.' Donatur</small>';
        $html .= '</div>';
        $html .= '<div class="col-6 text-end">';
            $sekarang = date('Y-m-d');
            $waktusekarang = date('Y-m-d', strtotime($sekarang));
            $ditutup = date('Y-m-d', strtotime($tanggal_berakhir));
            if (!empty($tanggal_berakhir) && $waktusekarang <= $ditutup) {
                $html .= '<small> '.human_time_diff(strtotime($tanggal_berakhir),current_time('timestamp')).' lagi</small>';
            } elseif(!empty($tanggal_berakhir)) {
                $html .= '<small class="text-danger">Donasi ditutup</small>';
            }
        $html .= '</div>';
    $html .= '</div>';
    return $html;
}
add_shortcode( 'progress', 'vsstemmart_progress' );


// [post-loop post_id='']
function vsstemmart_post_loop($atts) {
    global $post;
    $atribut = shortcode_atts(array(
        'post_id'     	=> $post->ID,
    ), $atts);
    $post_id = $atribut['post_id'];
    $html = '<div class="velocity-post-list">';
    if (has_post_thumbnail($post_id)) {
        $urlbesar   = get_the_post_thumbnail_url($post_id, 'full');  
        $imgresize  = aq_resize($urlbesar, 400, 250, true, true, true);
        $html       .= '<a href="'.get_the_permalink($post_id).'">';
            $html       .= '<img class="w-100" src="' . $imgresize . '">';
        $html       .= '</a>';
    }
    $html .= '<div class="p-3">';
        $html .= '<a class="h6 fw-bold text-dark" href="'.get_the_permalink($post_id).'">'.get_the_title($post_id).'</a>';
        $html .= do_shortcode('[progress]');
    $html .= '</div>';
    $html .= '</div>';
    return $html;
}
add_shortcode('post-loop', 'vsstemmart_post_loop');




// [daftar-donatur]
function velocity_daftar_donatur($atts) {
    global $post,$wpdb;
    $table_donatur = $wpdb->prefix.'donatur';
    $table_order = $wpdb->prefix.'order';
    $atribut = shortcode_atts(array(
        'post_id' => $post->ID,
    ), $atts);
    $post_id = $atribut['post_id'];
    $daftardonatur = $wpdb->get_results( "SELECT * FROM {$table_donatur} WHERE id_produk = '{$post_id}' ORDER BY id DESC");
    $html  = '';
    $html .= '<div class="mt-2 text-muted">';
    foreach($daftardonatur as $donatur){
        $data = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table_order} WHERE invoice = %d", $donatur->invoice ) );
        $detail = json_decode($data->detail,true);
        $produk = $detail['produk']['products'];
        $arraynomor = array_search($post_id, array_column($produk, 'id'));
        $donasi = $produk[$arraynomor]['harga'] * $produk[$arraynomor]['jumlah'];
        $html .= '<div class="card p-3 mb-2">';
            $html .= '<div class="mb-2">';
                $html .= '<div class="float-start text-dark fw-bold">'.$donatur->nama.'</div>';
                $html .= '<small class="float-end">'.date('d-m-Y', strtotime($data->date)).'</small>';
            $html .= '</div>';
            $html .= !empty($detail['catatan'])? '<p>'.$detail['catatan'].'</p>' : '';
            $html .= '<div class="text-success fw-bold">'.vsstemmart_number_money($donasi).'</div>';
        $html .= '</div>';
    }
    $html .= '</div>';
    return $html;
}
add_shortcode( 'daftar-donatur', 'velocity_daftar_donatur' );


// [donasi-terbaru]
function velocity_donasi_terbaru($atts) {
    $atribut = shortcode_atts(array(
        'posts_per_page' => 5,
    ), $atts);
    $posts_per_page = $atribut['posts_per_page'];
	$args = array(
		'posts_per_page' => $posts_per_page,
		'post_type' => 'donasi',
	);
	$wp_query = new WP_Query($args); 
    $html  = '';
	if($wp_query->have_posts ()):
        while($wp_query->have_posts()): $wp_query->the_post();
            $url = get_the_post_thumbnail_url();
            $urlgambar = aq_resize($url,200,150,true,true,true);
            $html .= '<div class="mb-3 row">';
                $html .= '<div class="col-4 pe-0">';
                if (has_post_thumbnail()) {
                    $html .= '<img class="w-100" src="'.$urlgambar.'" />';
                }
                $html .= '</div>';
                $html .= '<div class="col-8">';
                    $html .= '<a href="'.get_the_permalink().'">'.get_the_title().'</a>';
                    $html .= do_shortcode('[progress]');
                $html .= '</div>';
            $html .= '</div><hr class="border-top">';
        endwhile;
	endif;
	wp_reset_query();
    return $html;
}
add_shortcode( 'donasi-terbaru', 'velocity_donasi_terbaru' );