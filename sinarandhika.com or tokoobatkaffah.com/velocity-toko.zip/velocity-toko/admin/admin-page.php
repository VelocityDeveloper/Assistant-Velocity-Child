<?php
/**
 * Velocity Toko
 */
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Register admin menu.
 */
function velocitytoko_addon_toko(){
    add_menu_page(
        __( 'Dashboard Toko', 'vsstemmart' ),
        'Dashboard Toko',
        'manage_options',
        'laporan',
        'velocitytoko_addon_data_toko',
        VELOCITY_TOKO_PLUGIN_URL.'admin/img/laporan.png',
        1
    );
    add_submenu_page(
        'laporan',
        'Order',
        'Data Pembelian',
        'manage_options',
        'dataorder',
        'velocitytoko_addon_history_order'
    );
    add_submenu_page(
        'laporan',
        'Kupon',
        'Kupon Management',
        'manage_options',
        'kuponmanage',
        'velocitytoko_addon_kupon_page'
    );
    add_submenu_page(
        'laporan',
        'Ongkir',
        'Custom Ongkir',
        'manage_options',
        'ongkir',
        'velocitytoko_addon_ongkir_page'
    );
}
add_action( 'admin_menu', 'velocitytoko_addon_toko' );

function velocitytoko_addon_ongkir_page(){
    echo '<div class="velocitytoko-admin-page">';
    require_once( VELOCITY_TOKO_PLUGIN_DIR . 'admin/vd-toko-ongkir.php' );
    echo '</div>';
}

function velocitytoko_addon_data_toko(){
    echo '<div class="velocitytoko-admin-page">';
    require_once( VELOCITY_TOKO_PLUGIN_DIR . 'admin/vd-toko-data.php' );
    echo '</div>';
}

function velocitytoko_addon_history_order(){
    echo '<div class="velocitytoko-admin-page">';
    require_once( VELOCITY_TOKO_PLUGIN_DIR . 'admin/vd-toko-order.php' );
    echo '</div>';
}

function velocitytoko_addon_kupon_page(){
    echo '<div class="velocitytoko-admin-page">';
    require_once( VELOCITY_TOKO_PLUGIN_DIR . 'admin/vd-toko-kupon.php' );
    echo '</div>';
}

/**
 * Reorder admin menu.
 */
function velocitytoko_addon_custom_menu_order( $menu_ord ) {
    if ( !$menu_ord ) return true;
    return array(
        'index.php',
        'laporan',
        'edit.php?post_type=product',
        'edit.php',
        'edit.php?post_type=page',
    );
}
add_filter( 'custom_menu_order', 'velocitytoko_addon_custom_menu_order', 10, 1 );
add_filter( 'menu_order', 'velocitytoko_addon_custom_menu_order', 10, 1 );