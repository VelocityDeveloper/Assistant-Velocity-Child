<?php
/**
 * Store function.
 *
 * @package Velocity Toko
 */

function velocitytoko_content_loop_archive_filter($post){
    ob_start();
    ?>
    <article <?php post_class('col-md-3 col-6 pb-2 mb-3'); ?> id="post-<?php the_ID(); ?>">
        <div class="card h-100 card-product">
            <?php echo do_shortcode("[thumbnail width='300' height='380' crop='false' upscale='true']"); ?>
            <div class="p-3">
                <div class="my-2 text-center text-md-start">
                    <a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
                </div>
                <div class="row">
                    <div class="col-md-8 text-center text-md-start"><?php echo do_shortcode("[harga]"); ?></div>
                    <div class="col-md-4 text-center text-md-end"><?php echo do_shortcode("[beli]"); ?></div>
                </div>
            </div>
        </div>
    </article><!-- #post-## -->
    <?php
    return ob_get_clean();
}
add_filter('velocitytoko_content_loop_archive','velocitytoko_content_loop_archive_filter');

function velocitytoko_content_loop_related_filter($post){
    ob_start();
    ?>
    <article <?php post_class('col-md-3 col-6'); ?> id="post-<?php the_ID(); ?>">
        <div class="card">
            <?php echo do_shortcode("[thumbnail width='300' height='380' crop='false' upscale='true']"); ?>
            <div class="p-3">
                <h3 class="my-2 upperhead text-center text-md-start"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
            </div>
        </div>  
    </article><!-- #post-## -->
    <?php
    return ob_get_clean();
}
add_filter('velocitytoko_content_loop_related','velocitytoko_content_loop_related_filter');

function velocitytoko_content_single_product_filter($post){
    ob_start();
    ?>
    <article <?php post_class(); ?> id="post-<?php the_ID(); ?>">

        <div class="block-primary">            
            <div class="row">
                <div class="col-md-6 col-xl-5"><?php echo do_shortcode('[slider-produk height="350"]'); ?></div>
                <div class="col-md">
                    <h2>
                        <?php echo do_shortcode("[vtoko-title link='true' node-cart='cartsingle']"); ?>
                    </h2>
                    <div class="mb-2">
                        <small>
                            Kategori: <?php echo velocitytoko_term_list('category-product',",",get_the_ID()); ?> 
                            | Dilihat: <?php echo do_shortcode('[view]'); ?>
                        </small>
                    </div>
                    <div class="single-harga mb-3">Harga: <?php echo do_shortcode('[harga node-cart="cartsingle"]'); ?></div>
                    <div class="mb-3"><?php echo do_shortcode('[beli modal="false" node-cart="cartsingle" text="true"]'); ?></div>
                    <div class="mb-3"><?php echo do_shortcode('[love text="true"]'); ?></div>
                    <div class="mb-3"><?php echo do_shortcode('[beli-lain]'); ?></div>
                    <div class="mb-3"><?php echo do_shortcode('[detail-produk]'); ?></div>
                    <div class="mb-3"><?php echo do_shortcode('[share]'); ?></div>
                </div>
            </div>
        </div>

        <div class="block-primary">
            <h3 class="title-single-part">Detail Produk</h3>
            <div><?php echo get_the_content(); ?></div>
        </div>

    </article><!-- #post-## -->
    <?php
    return ob_get_clean();
}
add_filter('velocitytoko_content_single_product','velocitytoko_content_single_product_filter');

function velocitytoko_content_loop_none_filter($post){
    ob_start();
    ?>
    <section class="no-results not-found">

        <header class="page-header">

            <h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'vsstemmart' ); ?></h1>

        </header><!-- .page-header -->

        <div class="page-content">

            <?php
            if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>

                <p><?php printf( wp_kses( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'vsstemmart' ), array(
        'a' => array(
            'href' => array(),
        ),
        ) ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>

            <?php elseif ( is_search() ) : ?>

                <p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'vsstemmart' ); ?></p>
                <?php
                    get_search_form();
            else : ?>

                <p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'vsstemmart' ); ?></p>
                <?php
                    get_search_form();
            endif; ?>
        </div><!-- .page-content -->

    </section><!-- .no-results -->
    <?php
    return ob_get_clean();
}
add_filter('velocitytoko_content_loop_none','velocitytoko_content_loop_none_filter');
