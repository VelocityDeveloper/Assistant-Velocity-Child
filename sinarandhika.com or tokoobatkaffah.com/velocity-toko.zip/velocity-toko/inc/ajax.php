<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */

add_action('wp_head','vsstemmart_ajaxurl');
function vsstemmart_ajaxurl() {
    $html    = '<script type="text/javascript">';
    $html   .= 'var ajaxurl = "' . admin_url( 'admin-ajax.php' ) . '"';
    $html   .= '</script>';
    echo $html;
}


add_action( 'wp_ajax_ajaxlogin', 'ajax_login' );
add_action( 'wp_ajax_nopriv_ajaxlogin', 'ajax_login' );
function ajax_login(){

    // First check the nonce, if it fails the function will break
    check_ajax_referer( 'ajax-login-nonce', 'security' );

    // Nonce is checked, get the POST data and sign user on
    $info = array();
    $info['user_login']             = $_POST['username'];
    $info['user_password']          = $_POST['password'];
    $info['g-recaptcha-response']   = isset($_POST['g-recaptcha-response']) ? $_POST['g-recaptcha-response']:'';
    $info['remember']               = true;

    if($info['g-recaptcha-response']) {
        //get BWS recaptcha options
        $gglcptch_options   = get_option( 'gglcptch_options');  
        $response           = wp_remote_get( 'https://www.google.com/recaptcha/api/siteverify?secret='.$gglcptch_options['private_key'].'&response=' . $_POST['g-recaptcha-response'] );
        $response           = json_decode($response['body'], true);

        if (true != $response['success']) {
            echo json_encode(array('loggedin'=>false, 'message'=>__('<strong>ERROR</strong>: Please Validate reCAPTCHA')));
            return false;
        } 
    }
    
    if (is_ssl()) {
        $sll = true;
    } else {
        $sll = false;
    }
    $user_signon = wp_signon( $info, $sll );
    if ( is_wp_error($user_signon) ){
        echo json_encode(array('loggedin'=>false, 'message'=>$user_signon->get_error_message() ));
    } else {
        echo json_encode(array('loggedin'=>true, 'message'=>__('Login successful, redirecting...')));
    }


    die();
}

add_action('wp_ajax_ongkirhapus', 'ongkirhapus_ajax');
function ongkirhapus_ajax() {
    global $wpdb;
    $table_ongkir    = $wpdb->prefix . "ongkir";
    $id             = isset($_POST['id']) ? $_POST['id'] : '';
    $wpdb->delete($table_ongkir, array(
        'id'          => $id,
      )
	);
    wp_die();
}

add_action('wp_ajax_adminpembeli', 'adminpembeli_ajax');
function adminpembeli_ajax() {
    global $wpdb;
    $table_name = $wpdb->prefix . "order";
    $id         = isset($_POST['id']) ? $_POST['id'] : '';
    $status     = isset($_POST['status']) ? $_POST['status'] : '';
    $resi       = isset($_POST['resi']) ? $_POST['resi'] : '';
    $kurir      = isset($_POST['kurir']) ? $_POST['kurir'] : '';
    $kirimemail = isset($_POST['kirim']) ? $_POST['kirim'] : '';
    $detail     = $wpdb->get_results("SELECT * FROM $table_name WHERE id = ".$id);
    $produk     = json_decode($detail[0]->detail,true);
    $nama       = isset($produk['nama'])? $produk['nama'] : '';
    $emailbeli	= isset($produk['email'])? $produk['email'] : '';
    $namatoko   = get_bloginfo('name');
    $emailtoko  = velocitytoko_option('emailadmin',get_bloginfo('admin_email'));
    $link       = '<a href="'.get_permalink( get_page_by_path( 'myaccount' ) ).'?invoice='.$detail[0]->invoice.'" >Detail Pesanan</a>';
    $alamattoko = velocitytoko_option('city_origin');
    $alamattoko = getSingleCity($alamattoko)[0]['city_name'];
    $wpdb->update($table_name, array(
        'status'        => $status,
        'kurir'         => $kurir,
        'resi'          => $resi,
       ),
       array(
        'id'            => $id,
           )
    );
    $pesan              = velocitytoko_option('statusemail');
    $pesan              = str_replace('[nama-pemesan]',$nama,$pesan);
    $pesan              = str_replace('[nama-toko]',$namatoko,$pesan);
    $pesan              = str_replace('[status]',$status,$pesan);
    $pesan              = str_replace('[alamat-toko]',$alamattoko,$pesan);
    $pesan              = str_replace('[kode-pesanan]',$detail[0]->invoice,$pesan);
    $pesan              = str_replace('[link]',$link,$pesan);

    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'From: '.$namatoko.' <'.$emailtoko.'>';
    $subject = 'Hallo! Ada Perubahan Status Pada Invoice #'.$detail[0]->invoice;

    if($kirimemail == 'yes'){
        wp_mail( $emailbeli, $subject, $pesan, $headers );
    }
    wp_die();
}

add_action('wp_ajax_adminkupontambah', 'adminkupontambah_ajax');
function adminkupontambah_ajax() {
    global $wpdb;
    $table_kupon    = $wpdb->prefix . "kupon";
    $detail         = isset($_POST['detail']) ? $_POST['detail'] : '';
    $detailjson     =json_encode($detail,JSON_UNESCAPED_SLASHES);
    $wpdb->insert($table_kupon, array(
        'kode'          => $detail['kode'],
        'detail'        => $detailjson,
      )
	);
    wp_die();
}

add_action('wp_ajax_adminkuponhapus', 'adminkuponhapus_ajax');
function adminkuponhapus_ajax() {
    global $wpdb;
    $table_kupon    = $wpdb->prefix . "kupon";
    $id             = isset($_POST['id']) ? $_POST['id'] : '';
    $wpdb->delete($table_kupon, array(
        'id'          => $id,
      )
	);
    wp_die();
}

add_action('wp_ajax_adminkuponedit', 'adminkuponedit_ajax');
function adminkuponedit_ajax() {
    global $wpdb;
    $table_kupon    = $wpdb->prefix . "kupon";
    $detail         = isset($_POST['detail']) ? $_POST['detail'] : '';
    $id             = isset($_POST['id']) ? $_POST['id'] : '';
    $detailjson     =json_encode($detail);
    $wpdb->update($table_kupon, array(
        'kode'          => $detail['kode'],
        'detail'        => $detailjson,
      ),array(
          'id'          => $id,
          )
	);
	echo 'Pesan';
    wp_die();
}

add_action('wp_ajax_adminkuponupdate', 'adminkuponupdate_ajax');
function adminkuponupdate_ajax() {
    global $wpdb;
    $table_order    = $wpdb->prefix . "kupon";
    $kode           = isset($_POST['kode']) ? $_POST['kode'] : '';
    $detail           = isset($_POST['detail']) ? $_POST['detail'] : '';
    $wpdb->update($table_order, array(
        'kode'          => $kode,
        'detail'        => $detail,
       ),array(
           'id'          => $id,
            )
	);
    wp_die();
}

add_action('wp_ajax_lanjuthapus', 'lanjuthapus_ajax');
function lanjuthapus_ajax() {
    global $wpdb;
	$table_name     = $wpdb->prefix . "order";
    $idproduk       = isset($_POST['myid']) ? $_POST['myid'] : '';
    $wpdb->delete($table_name, array(
        'id'     => $idproduk,
      )
	);
    wp_die();
}

add_action('wp_ajax_nopriv_hapuskupon', 'hapuskupon_ajax');
add_action('wp_ajax_hapuskupon', 'hapuskupon_ajax');
function hapuskupon_ajax() {
    $_SESSION['kupon']= '';
}

add_action('wp_ajax_nopriv_pakaikupon', 'pakaikupon_ajax');
add_action('wp_ajax_pakaikupon', 'pakaikupon_ajax');
function pakaikupon_ajax() {
    global $wpdb;
	$table_name     = $wpdb->prefix . "kupon";
    $kode           = isset($_POST['kode']) ? $_POST['kode'] : '';
    $bayar          = isset($_POST['bayar']) ? $_POST['bayar'] : 0;
    $datakupon      = $wpdb->get_results("SELECT * FROM $table_name WHERE kode = '".$kode."'");
    $date_now       = date( 'Y-m-d', current_time( 'timestamp', 0 ) );

    if($datakupon){
        $detail     = json_decode($datakupon[0]->detail,true);
        $dateendq   = $detail['tanggalend'];
        $dateend    = date("Y-m-d", strtotime($dateendq));
        $status     = $detail['status'];
        $jumlah     = $detail['jumlah'];
        $minorder   = $detail['minorder'];

        if ($date_now > $dateend) {
            $_SESSION['kupon']= '';
            echo '<span class="alert alert-danger alert-dismissible fade show">Maaf, Kode Promo <b>"'.$kode.'"</b> Sudah Kadaluarsa.</span>';
        } else if($status == 'off') {
            $_SESSION['kupon']= '';
            echo '<span class="alert alert-danger alert-dismissible fade show">Maaf, Kode Promo <b>"'.$kode.'"</b> Tidak Bisa Digunakan.</span>';
        } else if($jumlah < 1) {
            $_SESSION['kupon']= '';
            echo '<span class="alert alert-danger alert-dismissible fade show">Maaf, Kode Promo <b>"'.$kode.'"</b> Sudah Habis.</span>';
        } else if($bayar < $minorder) {
            $_SESSION['kupon']= '';
            echo '<span class="alert alert-danger alert-dismissible fade show">Maaf, Kode Promo <b>"'.$kode.'"</b> memiliki minimal pembelian '.vsstemmart_currency_text().' '.number_format($minorder).'.</span>';
        } else {
            echo '<span class="alert alert-success alert-dismissible fade show">Selamat, Kode Promo <b>"'.$kode.'"</b> berhasil digunakan.</span>';
            $_SESSION['kupon']= array(
                'pakaikupon'    => 'yes',
                'detail'        => $datakupon[0]->detail,
            );
            $detail['jumlah']   = $detail['jumlah']-1;
            $updatedetail       = json_encode($detail);
            $wpdb->update($table_name, array(
    		        'detail'            => $updatedetail,
    		       ),
    		       array(
    		        'kode'        => $kode,
    		           )
    		);
        }
    } else {
        $_SESSION['kupon']= '';
        echo '<span class="alert alert-danger alert-dismissible fade show">Maaf, Kode Promo <b>"'.$kode.'"</b> Tidak Terdaftar.</span>';
    }
    wp_die();
}

add_action('wp_ajax_nopriv_kecamatan', 'kecamatan_ajax');
add_action('wp_ajax_kecamatan', 'kecamatan_ajax');
function kecamatan_ajax() {
    $a                  = isset($_POST['city_destination']) ? $_POST['city_destination'] : '';
    $data_Subdistrict   = getSubdistrict($a);
    // print_r($data_Subdistrict);
    echo "<option value=''>Kecamatan</option>";
    if($data_Subdistrict) {
        for ($x=0; $x < count($data_Subdistrict); $x++) {
            echo "<option value='".$data_Subdistrict[$x]['subdistrict_id']."' class='". $data_Subdistrict[$x]['city_id']."' >".$data_Subdistrict[$x]['subdistrict_name']."</option>";
        }
    }
    wp_die();
}

add_action('wp_ajax_nopriv_love', 'love_ajax');
add_action('wp_ajax_love', 'love_ajax');
function love_ajax() {
    $idproduk   = isset($_POST['idproduk']) ? $_POST['idproduk'] : '';
    $user_id    = get_current_user_id();

    if(!empty(get_user_meta( $user_id, 'love', true))){
        $ada    = json_decode(get_user_meta( $user_id, 'love', true),true );
    } else {
        $ada    = array();
    }
    if(in_array($idproduk,$ada)) {
        $ada    = array_diff($ada, array($idproduk));
        $baru   = json_encode($ada);
        update_user_meta( $user_id, 'love', $baru );
    } else {
        array_push($ada, $idproduk);
        $baru   = json_encode($ada);
        update_user_meta( $user_id, 'love', $baru );
    }

    wp_die();
}
add_action('wp_ajax_nopriv_kota', 'kota_ajax');
add_action('wp_ajax_kota', 'kota_ajax');
function kota_ajax() {
    $prov  = isset($_POST['prov_destination']) ? $_POST['prov_destination'] : '';
    echo "<option value=''>Kota</option>";
	  $data_City    = getCity();
      for ($x=0; $x < count($data_City); $x++) {
          if($prov==$data_City[$x]['province_id']) {
            $type = $data_City[$x]['type'];
            if( $type == 'Kabupaten'){
                $type = 'Kab';
            }
            echo "<option value='".$data_City[$x]['city_id']."' class='". $data_City[$x]['province_id']."' >".$type." ".$data_City[$x]['city_name']."</option>";
          }
      }
    wp_die();
}

add_action('wp_ajax_nopriv_ongkir', 'ongkir_ajax');
add_action('wp_ajax_ongkir', 'ongkir_ajax');
function ongkir_ajax() {
    $user_id        = get_current_user_id();
    $destination    = get_user_meta( $user_id, 'subdistrict_destination',true );
    $berattotal     = isset($_POST['berattotal']) ? $_POST['berattotal'] : '';
    $destination    = isset($_POST['destination']) ? $_POST['destination'] : $destination ;
    $potongongkir   = isset($_POST['potongongkir']) ? $_POST['potongongkir'] : '' ;
    $origin         = velocitytoko_option('city_origin');
    $cods           = velocitytoko_option('cod',[]);
    $courier        = velocitytoko_option('courier');
    $ongkiraktif    = velocitytoko_option('ongkir','0');
    $citydest       = getSingleSubdistrict($destination)[0]['city_id'] ;
    
    if ($ongkiraktif === '1'){
        
        echo "<select required name='ongkir' class='form-control pilihongkir'>";

            if(!empty($cods) && in_array($citydest, $cods)) {
                echo "<option value='COD -  - 0'>";
                    echo 'COD: '.vsstemmart_currency_text().' 0';
                echo "</option>";
            }

            $data   = json_decode(getOngkir($origin,$destination,$berattotal), true);

            if($data) {
                for ($i=0; $i < count($data['rajaongkir']['results']); $i++) {
                for ($j=0; $j < count($data['rajaongkir']['results'][$i]['costs']); $j++) {
                    $kode       = strtoupper($data['rajaongkir']['results'][$i]['code']);
                    $service    = $data['rajaongkir']['results'][$i]['costs'][$j]['service'];
                    $value      = $data['rajaongkir']['results'][$i]['costs'][$j]['cost'][0]['value'];
                    if($potongongkir != '0'){
                        if((($value - $potongongkir)>0)){
                            $ongkir = $value - $potongongkir;
                        } else {
                            $ongkir = 0;
                        }
                    } else {
                        $ongkir = $value;
                    }
                    echo "<option value='".$kode." - ".$service." - ".$ongkir."'>";
                    echo $kode.' - '.$service.': '.vsstemmart_currency_text().' '.number_format($ongkir);
                    echo "</option>";
                }
                }
            }
            
            global $wpdb;
            $table_name = $wpdb->prefix . "ongkir";
            $sudahada = $wpdb->get_results("SELECT * FROM $table_name WHERE kecamatan = $destination");
            // print_r($destination.$sudahada);
            foreach($sudahada as $id){
                echo '<option value="'.$id->kecamatan.' - '.get_bloginfo('name').' - '.$id->ongkir.'">';
                    echo $id->kecamatan.' - '.get_bloginfo('name').' : '.vsstemmart_currency_text().' '.number_format($id->ongkir);
                echo "</option>";
            }
            
            if(empty($sudahada) && empty($data) && !in_array($citydest, $cods)) {                	
                echo '<option value="0 - Ongkir tidak tersedia - 0">';
                echo 'Ongkir tidak tersedia : 0';
                echo "</option>";
            }
                
        echo '</select>';
	} else {
		echo vsstemmart_currency_text().' 0<input class="pilihongkir" type="hidden" name="ongkir" id="bank" value="No - 0 - 0" required/>';
	}
    wp_die();
}

add_action('wp_ajax_nopriv_tambahkeranjang', 'tambahkeranjang_ajax');
add_action('wp_ajax_tambahkeranjang', 'tambahkeranjang_ajax');
function tambahkeranjang_ajax() {
    $idproduk   = isset($_POST['idproduk']) ? $_POST['idproduk'] : '';
    $idasli     = isset($_POST['idasli']) ? $_POST['idasli'] : '';
    $jumlah     = isset($_POST['jumlah']) ? $_POST['jumlah'] : '';
    $opsia      = isset($_POST['onopsia']) ? $_POST['onopsia'] : '';
    $opsib      = isset($_POST['onopsib']) ? $_POST['onopsib'] : '';
    
    $Cart       = new Vsstemmart\Keranjang;
    $cartcount  = $Cart->addItem($idasli,$idproduk,$jumlah,$opsia,$opsib);
    
    //echo jumlah
    echo $cartcount;
    
    wp_die();
}

add_action('wp_ajax_nopriv_modifkeranjang', 'modifkeranjang_ajax');
add_action('wp_ajax_modifkeranjang', 'modifkeranjang_ajax');
function modifkeranjang_ajax() {
    $idproduk   = isset($_POST['id']) ? $_POST['id'] : '';
    $jumlah     = isset($_POST['jumlah']) ? $_POST['jumlah'] : '';
    $Cart       = new Vsstemmart\Keranjang;
    $cartcount  = $Cart->updateItem($idproduk,$jumlah);

    echo $cartcount;
    wp_die();
}

add_action('wp_ajax_nopriv_deleteorder', 'deleteorder_ajax');
add_action('wp_ajax_deleteorder', 'deleteorder_ajax');
function deleteorder_ajax() {
    
    // Reset Keranjang
    $idproduk   = isset($_POST['id']) ? $_POST['id'] : '';  
    $Cart       = new Vsstemmart\Keranjang;
    $Cart->deleteItem($idproduk);

    echo $Cart->count();

    wp_die();
}

add_action('wp_ajax_nopriv_kosongkankeranjang', 'kosongkankeranjang_ajax');
add_action('wp_ajax_kosongkankeranjang', 'kosongkankeranjang_ajax');
function kosongkankeranjang_ajax() {
    
    // Reset Keranjang    
    $Cart = new Vsstemmart\Keranjang;
    $Cart->reset();

    wp_die();
}

add_action('wp_ajax_nopriv_displaytablecart', 'displaytablecart_ajax');
add_action('wp_ajax_displaytablecart', 'displaytablecart_ajax');
function displaytablecart_ajax() {
    
    echo velocitytoko_display_tablecart();

    wp_die();
}

//cek ongkir
add_action('wp_ajax_nopriv_cekongkir', 'cekongkir_ajax');
add_action('wp_ajax_cekongkir', 'cekongkir_ajax');
function cekongkir_ajax() {
    $user_id        = get_current_user_id();
    $destination    = get_user_meta( $user_id, 'subdistrict_destination',true );
    $berat		    = isset($_POST['berattotal']) ? $_POST['berattotal'] : '';
    $berattotal     = $berat*1000;
    $destination    = isset($_POST['destination']) ? $_POST['destination'] : $destination ;
    $potongongkir   = isset($_POST['potongongkir']) ? $_POST['potongongkir'] : '' ;
    $origin         = velocitytoko_option('city_origin');
    $cods           = velocitytoko_option('cod',[]);
    $courier        = velocitytoko_option('courier');
    $getOngkir      = getOngkir($origin,$destination,$berattotal);
    $data           = $getOngkir?json_decode($getOngkir, true):'';
    
    if($data){
        echo "<div class='mt-3 mb-3'>";
        echo "<span><strong>Pengiriman Dari : </strong> <span>".$data['rajaongkir']['origin_details']['type']." ".$data['rajaongkir']['origin_details']['city_name'].", ".$data['rajaongkir']['origin_details']['province']."</span></span>";
        echo "</div>";
        echo "<div class='table-responsive'>";
                for ($i=0; $i < count($data['rajaongkir']['results']); $i++) {
                echo "<h3 class='text-success'>".strtoupper($data['rajaongkir']['results'][$i]['name'])."</h3>";
                echo "<table class='table table-sm table-hover'>";
                    echo "<tr class='thead-light'>";
                        echo "<th>Layanan</th>";
                        echo "<th>Jenis Kiriman</th>";
                        echo "<th>Tarif</th>";
                        echo "<th>Estimasi Pengiriman</th>";
                    echo "</tr>";
                    for ($j=0; $j < count($data['rajaongkir']['results'][$i]['costs']); $j++) {
                    $pieces = explode("HARI", $data['rajaongkir']['results'][$i]['costs'][$j]['cost'][0]['etd']);
                    echo "<tr>";
                        echo "<td>".$data['rajaongkir']['results'][$i]['costs'][$j]['description']."</td>";
                        echo "<td>".$data['rajaongkir']['results'][$i]['costs'][$j]['service']."</td>";
                        echo "<td>".vsstemmart_number_money($data['rajaongkir']['results'][$i]['costs'][$j]['cost'][0]['value'])."</td>";
                        echo "<td>".$pieces[0]." Hari</td>";
                    echo "</tr>";
                    }
                        if(count($data['rajaongkir']['results'][$i]['costs'])==0){echo "<tr><td colspan='4'><div class='ongkirred'>Data Tidak Tersedia</div></td></tr>";}
                echo '</table>';
                }
        echo '</div>';

    } else {
        echo '<div class="alert alert-info">Ongkos Kirim tidak tersedia</div>';
    }

    wp_die();
}
