<?php
/**
 * Register meta boxes for post product.
 *
 * @package Velocity Toko
 */
 
add_filter( 'rwmb_meta_boxes', 'vsstemmart_product_register_meta_boxes' );
function vsstemmart_product_register_meta_boxes( $meta_boxes ) {
    $meta_boxes[] = array(
        'id'                => 'detail',
        'title'             => 'Detail Produk',
        'post_types'        => 'product',
        'context'           => 'normal',
        'priority'          => 'high',

        'fields' => array(
            array(
				'type'      => 'heading',
				'name'      => esc_html__( 'General', 'vsstemmart' ),
				'desc'      => esc_html__( '', 'vsstemmart' ),
			),
			array(
                'name'            => 'Label Produk',
                'id'              => 'label',
                'type'            => 'select_advanced',
                'options'         => array(
                    'label-best'         => 'Best Seller',
                    'label-limited'       => 'Limited',
                    'label-new'           => 'New',
                ),
                'multiple'        => false,
                'placeholder'     => 'Select an Item',
                'select_all_none' => false,

            ),

            array(
                'name'      => 'Kode Produk (SKU)',
                'desc'      => '',
                'id'        => 'sku',
                'type'      => 'text',
            ),
            array(
                'name'      => 'Harga (Rp)',
                'desc'      => '',
                'id'        => 'harga',
                'type'      => 'number',
            ),
            array(
                'name'      => 'Harga Promo (Rp)',
                'desc'      => '',
                'id'        => 'harga_promo',
                'type'      => 'number',
            ),
            array(
                'name'      => 'Minimal Order',
                'desc'      => '',
                'id'        => 'minorder',
                'type'      => 'number',
            ),
            array(
                'name'       => 'Diskon Sampai',
                'id'         => 'flashsale',
                'type'       => 'datetime',
                'js_options' => array(
                    'stepMinute'      => 1,
                    'showTimepicker'  => true,
                    'controlType'     => 'select',
                    'showButtonPanel' => false,
                    'oneLine'         => true,
                ),
                'inline'    => false,
                'timestamp' => false,
            ),
			array(
				'type'      => 'heading',
				'name'      => esc_html__( 'Pengiriman', 'vsstemmart' ),
				'desc'      => esc_html__( '', 'vsstemmart' ),
			),
			array(
                'name'      => 'Berat Produk (Kg)',
                'desc'      => 'Contoh bilangan KG 1 2 3 4 dsb bilangan gram 0.1 0.5 1.5 dst',
                'id'        => 'berat',
                'type'      => 'number',
                'step'      => '0.01'
            ),
            array(
				'type'      => 'heading',
				'name'      => esc_html__( 'Stok', 'vsstemmart' ),
				'desc'      => esc_html__( '', 'vsstemmart' ),
			),
			array(
                'name'      => 'Jumlah Stok:',
                'desc'      => 'Jika stok di isi maka stok akan di kurangi dari setiap order dan akan otomatis disable tombol beli jika stok habis atau 0',
                'id'        => 'stok',
                'type'      => 'number',
            ),
            array(
				'type'      => 'heading',
				'name'      => esc_html__( 'Gallery', 'vsstemmart' ),
				'desc'      => esc_html__( '', 'vsstemmart' ),
			),
            array(
				'name'             => 'Gallery',
				'id'               => "gallery",
				'type'             => 'image_advanced',
				'force_delete'     => false,
			),
			array(
				'type'      => 'heading',
				'name'      => esc_html__( 'Opsi Basic', 'vsstemmart' ),
				'desc'      => esc_html__( 'Opsi Tanpa Merubah Harga', 'vsstemmart' ),
			),
			array(
                'name'      => 'Nama Opsi',
                'desc'      => 'contoh: "Pilih Warna"',
                'id'        => 'namaopsi',
                'type'      => 'text',
            ),
			array(
                'name'      => 'Opsi',
                'desc'      => '',
                'id'        => 'opsistandart',
                'type'      => 'text',
                'clone'     => 'true',
            ),
            array(
				'type'      => 'heading',
				'name'      => esc_html__( 'Opsi Advance', 'vsstemmart' ),
				'desc'      => esc_html__( 'Opsi juga merubah harga', 'vsstemmart' ),
			),
			array(
                'name'      => 'Nama Opsi',
                'desc'      => 'contoh: "Pilih Ukuran"',
                'id'        => 'namaopsi2',
                'type'      => 'text',
            ),
			array(
                'name'      => 'Opsi',
                'desc'      => 'Tuliskan Nama opsi = harga<br>Contoh: XL=250000',
                'id'        => 'opsiharga',
                'type'      => 'text',
                'clone'     => 'true',
            ),
        )
    );

    return $meta_boxes;
}
