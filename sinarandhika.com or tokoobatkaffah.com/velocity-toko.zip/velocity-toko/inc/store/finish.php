<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
global $wpdb;

$date                       = date("d-m-Y h:i:s");
$data                       = json_encode($_POST);
$table_order                = $wpdb->prefix . "order";  
$table_cart                 = $wpdb->prefix . "keranjang";  
$user_id                    = get_current_user_id();
$user_info                  = get_userdata($user_id);
$namatoko                   = get_bloginfo('name');

$emailtoko                  = velocitytoko_option('emailadmin',get_bloginfo('admin_email')); 
$paypalopt                  = velocitytoko_option('paypalopt');
$paypalmode                 = velocitytoko_option('paypaltype');
$paypalclientid             = velocitytoko_option('paypal');
$alamattoko                 = velocitytoko_option('city_origin');
$sitekey                    = velocitytoko_option('sitekey_recaptcha_velocitytoko');
$secret                     = velocitytoko_option('secret_recaptcha_velocitytoko');
$statusdropship             = velocitytoko_option('dropshipstatus');
$smspembeli                 = velocitytoko_option('smspembeli','off');
$smspenjual                 = velocitytoko_option('smspenjual','off');
$nosms                      = velocitytoko_option('nosms_velocitytoko');

$userdropship               = get_user_meta( $user_id, 'statusdropship', true );
$hp                         = isset($_POST['hp'])? $_POST['hp'] : '';
$nama                       = isset($_POST['nama'])? $_POST['nama'] : '';
$token                      = isset($_POST['token'])? $_POST['token'] : '';
$email                      = isset($_POST['email'])? $_POST['email'] : '';
$alamat                     = isset($_POST['alamat'])? $_POST['alamat'] : '';
$invoice                    = isset($_POST['invoice'])? $_POST['invoice'] : '';
$kodepos                    = isset($_POST['kodepos'])? $_POST['kodepos'] : '';
$pengiriman                 = isset($_POST['pengiriman'])? $_POST['pengiriman'] : '';
$pembayaran                 = isset($_POST['pembayaran'])? $_POST['pembayaran'] : '';
$jeniskupon                 = isset($_POST['produk']['kupon']['jenis'])? $_POST['produk']['kupon']['jenis'] : '';
$kodekupon                  = isset($_POST['produk']['kupon']['kode'])? $_POST['produk']['kupon']['kode'] : '';
$potongankupon              = isset($_POST['produk']['kupon']['potongan'])? $_POST['produk']['kupon']['potongan'] : '';
$subdistrict_destination    = isset($_POST['subdistrict_destination'])? $_POST['subdistrict_destination'] : '';
$hargatotal                 = isset($_POST['produk']['hargatotal'])? vsstemmart_number_money($_POST['produk']['hargatotal']) : '';
$hargatotaldolar            = isset($_POST['produk']['hargatotal'])? $_POST['produk']['hargatotal'] : '';
$ongkir                     = isset($_POST['ongkir'])? explode('-',$_POST['ongkir'])[0].' - '.explode('-',$_POST['ongkir'])[1].' - '.vsstemmart_number_money(explode('-',$_POST['ongkir'])[2]): '';
$alamattoko                 = getSingleCity($alamattoko)[0]['city_name'];
$norek                      = do_shortcode('[bank]');
$secretKey                  = $secret;
$captcha                    = isset($_POST['g-recaptcha-response'])? $_POST['g-recaptcha-response'] : '';
$ip                         = $_SERVER['REMOTE_ADDR'];
$response                   = wp_remote_get("https://www.google.com/recaptcha/api/siteverify?secret=".$secretKey."&response=".$captcha."&remoteip=".$ip);
if($response){
    $responseKeys           = json_decode($response['body'],true);
}
if($sitekey && $secret && $responseKeys){
    if(intval($responseKeys["success"]) === 1){
        $antispam = 'true';
    } else {
        $antispam = 'false';
    }
} else if($token == $_SESSION['token']){
    $antispam = 'true';
} else {
    $antispam = 'false';
}
    
if(is_user_logged_in() && $pengiriman == 'no'){
    update_user_meta( $user_id, 'nama', $nama );
    update_user_meta( $user_id, 'hp', $hp );
    update_user_meta( $user_id, 'alamat', $alamat );
    update_user_meta( $user_id, 'kodepos', $kodepos );
    update_user_meta( $user_id, 'subdistrict_destination', $subdistrict_destination );
} else if(is_user_logged_in() && $pengiriman == 'yes'){
    $nama                       = get_user_meta( $user_id, 'nama',true );
    $alamat                     = get_user_meta( $user_id, 'alamat',true );
    $kodepos                    = get_user_meta( $user_id, 'kodepos',true );
    $subdistrict_destination    = get_user_meta( $user_id, 'subdistrict_destination',true );
    $email                      = $user_info->user_email;
}
$kodekecamatan                  = getSingleSubdistrict($subdistrict_destination);


//Dropship
if($statusdropship == 'on' && $userdropship == 'on'){
    $alamattoko = get_user_meta( $user_id, 'alamattoko', true );
    $namatoko   = get_user_meta( $user_id, 'namatoko', true );
    $gethp      = get_user_meta( $user_id, 'nohp', true );
    $norek      = 'Untuk konfirmasi dan pembayaran silahkan hubungi '.$gethp;
    $email      = isset($_POST['email'])? $_POST['email'] : '';
}

if( $antispam == 'true' && isset($_POST['pembayaran']) ){
    
    $wpdb->insert($table_order, array(
        'id_pembeli'            => $user_id,
        'invoice'               => $invoice,
        'date'                  => $date,
        'detail'                => $data,
        'status'                => 'Transaksi Baru',
    ));

    // Reset Keranjang    
    $Cart = new Vsstemmart\Keranjang;
    $Cart->reset();

    // session_destroy();
    unset($_SESSION['token']);
    unset($_SESSION['kupon']);
    
    $dataproducts = isset($_POST['produk']['products'])?$_POST['produk']['products']:[];  
    foreach($dataproducts as $product){
        $jumlahstock    = get_post_meta($product['id'], 'stok', true);
        $jumlahdibeli   = isset($product['jumlah'])?$product['jumlah']:'';
        if($jumlahstock != '' && $jumlahstock != '0'){
            $stokbaru   = $jumlahstock - $jumlahdibeli;
            update_post_meta( $product['id'], 'stok', $stokbaru );
        }
    }
    
    if($pembayaran=='bank'){
        require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/payment-bank.php';
    } else if ($pembayaran=='paypal') {
        require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/payment-paypal.php';
    } else if ($pembayaran=='codpay') {
        require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/payment-cod.php';
    }
    
    if($smspembeli == 'on' && $hp){
        $body = 'Terimakasih '.$nama.' telah melakukan pembelian di '.$namatoko.', untuk melihat detail pesanan anda silahkan klik '.get_permalink( get_page_by_path( 'myaccount' ) ).'?invoice='.$invoice;
        kirimSMS($hp, $body);
        kirimwhatsapp($hp, $body);
    }
    if($smspenjual == 'on' && $nosms){
        $body = 'Ada Order Masuk di '.$namatoko.' dengan kode invoice: '.$invoice;
        kirimSMS($nosms, $body);
        kirimwhatsapp($nosms, $body);
    }
    
    require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/email-admin.php';
    require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/email-pembeli.php';
    
} else {
    echo '<div class="text-center">';
	    echo '<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-bag-x" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M6.146 8.146a.5.5 0 0 1 .708 0L8 9.293l1.146-1.147a.5.5 0 1 1 .708.708L8.707 10l1.147 1.146a.5.5 0 0 1-.708.708L8 10.707l-1.146 1.147a.5.5 0 0 1-.708-.708L7.293 10 6.146 8.854a.5.5 0 0 1 0-.708z"/> <path d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1zm3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4h-3.5zM2 5h12v9a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5z"/> </svg>';
	    echo '<h3 class="mt-4 mb-3 display-1">Gagal Mengajukan pesanan! :(</h3>';
	    echo 'Klik <strong><a href="?action=checkout">disini</a></strong> untuk mengirim ulang.';
    echo '</div>';
}
