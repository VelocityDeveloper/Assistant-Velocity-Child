<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
global $wpdb;
global $post;
$container      = get_theme_mod( 'vsstemmart_container_type' );
$table_order    = $wpdb->prefix . "order";
$details        = $wpdb->get_results("SELECT * FROM $table_order WHERE invoice = '".$getinvoice."' ORDER BY 'id' ASC");
$namatoko       = get_bloginfo('name');
$emailtoko      = velocitytoko_option( 'emailadmin',get_bloginfo('admin_email'));
$alamattoko     = velocitytoko_option( 'city_origin');
$alamattoko     = getSingleCity($alamattoko)[0]['city_name'];


if($details){
    echo '<div class="container px-0">';
    foreach($details as $detail){
        $user_id        = $detail->id_pembeli;
        $user_info      = get_userdata($user_id);
        $produk         = json_decode($detail->detail,true);
        $status         = $detail->status;
        $kurir          = $detail->kurir;
        $resi           = $detail->resi;
        $hp             = isset($produk['hp'])? $produk['hp'] : '';
        $nama           = isset($produk['nama'])? $produk['nama'] : '';
        $email          = isset($produk['email'])? $produk['email'] : '';
        $alamat         = isset($produk['alamat'])? $produk['alamat'] : '';
        $kodepos        = isset($produk['kodepos'])? $produk['kodepos'] : '';
        $catatan        = isset($produk['catatan'])? $produk['catatan'] : '';
        $invoice        = isset($produk['invoice'])? $produk['invoice'] : '';
        $ongkir         = isset($produk['ongkir'])? $produk['ongkir'] : '';
        $pembayaran     = isset($produk['pembayaran'])?$produk['pembayaran'] : '';
        $kodekupon      = isset($produk['produk']['kupon']['kode'])? $produk['produk']['kupon']['kode'] : '';
        $potongankupon  = isset($produk['produk']['kupon']['potongan'])? $produk['produk']['kupon']['potongan'] : '';
        $jeniskupon     = isset($produk['produk']['kupon']['jenis'])? $produk['produk']['kupon']['jenis'] : '';
        $pengiriman     = isset($produk['pengiriman'])?$produk['pengiriman'] : '';
        $hargatotal     = isset($produk['produk']['hargatotal'])? $produk['produk']['hargatotal'] : '';
        $subdistrict_destination =isset($produk['subdistrict_destination'])? $produk['subdistrict_destination'] : '';

        $paymetode  = isset($_POST['metode']) ? $_POST['metode'] : '';
        $paydetail  = isset($_POST['detail']) ? $_POST['detail'] : '';
        $token      = isset($_POST['token'])? $_POST['token'] : '';

        $body       = 'Metode Pembayaran: '.$paymetode.'<br>';
        if($paydetail){
            $body   .= 'Detail: '.$paydetail;
        }

        $headers = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= 'From: '.$namatoko.' <'.$emailtoko.'>';
        $subject = 'Konfirmasi pembayaran untuk Invoice #'.$invoice;

				//admin
        if(isset($_POST['metode']) && $token == $_SESSION['token']){
            $allowed_file_size = 5000000; // Allowed file size -> 5MB
            $upload_errors = '';
            if($_FILES["file"]['name']){
                if ( $_FILES['file']['size'] > $allowed_file_size ) {
    			    $upload_errors .= '<p><font color="red"> Gagal upload : File yang diupload terlalu besar. Maksimal ukuran file adalah 5MB.</font></p>';
    			}
                $uploadedfile = $_FILES['file'];
                $upload_overrides = array( 'test_form' => false );
                if ( empty( $upload_errors ) ) {
                    $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
                    if ( $movefile && ! isset( $movefile['error'] ) ) {
                        echo "File is valid, and was successfully uploaded.\n";
                        //var_dump( $movefile );
                    } else {
                        echo $movefile['error'];
                    }
                } else {
    							echo $upload_errors;
    						}
                $url[] = $movefile['file'];
                wp_mail( $emailtoko, $subject, $body, $headers,$url[0] );
                wp_delete_file( $url[0] );
            } else {
                wp_mail( $emailtoko, $subject, $body, $headers);
            }
            echo '<div class="text-center alert alert-success m-3">Terimakasih '.$nama.' telah melakukan konfirmasi pembayaran</div>';
        }

        if($pengiriman == 'yes' && $user_id){
            $hp             = get_user_meta( $user_id, 'hp',true );
            $nama           = get_user_meta( $user_id, 'nama',true );
            $alamat         = get_user_meta( $user_id, 'alamat',true );
            $kodepos        = get_user_meta( $user_id, 'kodepos',true );
            $subdistrict_destination = get_user_meta( $user_id, 'subdistrict_destination',true );
            $email          = $user_info->user_email;
        }
        $kodekec    = $subdistrict_destination?getSingleSubdistrict($subdistrict_destination):[];

        require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/profile-part-penerima.php';
        require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/profile-part-produk.php';
        require VELOCITY_TOKO_PLUGIN_DIR . '/inc/store/profile-part-tracking.php';

        echo '<div class="card bg-light">';
            echo '<div class="card-header">INVOICE #'.$getinvoice.'</div>';
            echo '<div class="card-body">';
                echo '<div class="row mt-3">';
                    echo '<div class="col-md-5">';
                        if($status == 'Transaksi Baru'){
                            echo '<div class="card text-dark p-3 mb-3">';
                                echo '<div ><h3 class="text-colortheme mb-2">Konfirmasi Pembayaran</h3></div>';
                                echo '<div>'.do_shortcode('[kontak]').'</div>';
                                ?>
                                <form class="mt-2" method="POST" enctype="multipart/form-data">
                                  <div class="form-group">
                                    <label for="exampleInputEmail1">Metode Pembayaran</label>
                                    <input type="text" class="form-control" name="metode" placeholder="Con. Transfer ke Bank BNI">
                                    <input type="hidden" class="form-control" name="token" value="<?php echo $_SESSION['token']; ?>">
                                  </div>
                                  <div class="form-group">
                                    <label for="detail">Detail</label>
                                    <textarea class="form-control" name="detail" placeholder="Con. Sudah sy transfer sesuai tagihan tadi malam mas."></textarea>
                                  </div>

                                   <div class="form-group">
                                    <label for="detail">Bukti Transfer</label>
                                    <input type="file" class="form-control" name="file">
                                    <small class="form-text text-muted">Ukuran Maksimal 5MB</small>
                                  </div>

                                  <button type="submit" class="btn btn-dark">Konfirmasi</button>
                                </form>
                                <?php
                            echo '</div>';
                        }
                        echo '<div class="card text-dark p-3 mb-3">';
                            if($status){
                                echo '<div ><h3 class="text-colortheme">Status: <span class="text-primary">'.$status.'</span></h3></div>';
                            }
                            if($kurir && $resi){
                                echo '<div class="h6">No Resi: <span class="text-primary">'.$resi.'('.$kurir.')</span></div>';
                            }
                        echo '</div>';
                        echo '<div class="card text-dark p-3 mb-3">';
                        echo $detailpenerima.'</div>';
                    echo '</div>';
                    echo '<div class="col-md-7"><div class="card text-dark p-3 mb-3">'.$detailproduk.'</div>';
                    if($resi && $kurir) {
                        echo '<div class="card text-dark p-3">'.$tracking.'</div>';
                    }
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';
    }
    echo '</div>';
} else {
    echo '<div class="alert alert-info">Kode Invoice tidak cocok</div>';
}
