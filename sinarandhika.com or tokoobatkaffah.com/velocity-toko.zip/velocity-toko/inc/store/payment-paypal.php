<?php
/**
 * Theme basic setup.
 *
 * @package velocity-toko
 */
 ?>
 <div class="text-center">
    <h3 class="mb-3">Terima Kasih, Pesanan Anda Berhasil di kirim!</h3>
    
    <?php
        $pesan              = velocitytoko_option('pesancheckout');
        $pesan              = str_replace('[nama-customer]',$nama,$pesan);
        $pesan              = str_replace('[nama-toko]',$namatoko,$pesan);
        $pesan              = str_replace('[email-cust]',$email,$pesan);
        echo $pesan;
    ?>
    
    <div class="row pesan-transfer mt-3 mb-3">
        <div class="col-sm-4">
            <i class="fa fa-credit-card"></i>
            <p>Bayar dengan Paypal, klik icon paypal checkout dibawah dan ikuti langkah pembayaran sampai selesai</p>
        </div>
        <div class="col-sm-4">
            <i class="fa fa-check-square-o"></i>
            <p>Konfirmasi pembayaran dengan cara mengisi <a href="<?php echo get_permalink( get_page_by_path( 'myaccount' ) ); ?>?invoice=<?php echo $invoice; ?>">formulir online</a> atau menghubungi customer service kami di <?php echo velocitytoko_option('notlp_velocitytoko'); ?></p>
        </div>
        <div class="col-sm-4">
            <i class="fa fa-truck"></i>
            <p>Pengiriman akan segera di proses setelah anda melakukan konfirmasi pembayaran</p>
        </div>
    </div>
    
    <div class="frame-invoice">
        <p class="text-dark">Kode Pemesanan Anda (Invoice) :</p><br>
        <span>
            <?php echo $invoice; ?>
        </span>
    </div>
    
    <div class="mt-4" id="paypal-button"></div>
    
    <div>
        <p class="mt-3">Setelah Melakukan Pembayaran silahkan melakukan konfirmasi Pembayaran melalui <b><a href="<?php echo get_permalink( get_page_by_path( 'myaccount' ) ); ?>?invoice=<?php echo $invoice; ?>">Klik Disini</a></b></p>
    </div>
</div>
<script src="https://www.paypalobjects.com/api/checkout.js"></script>
<script>
paypal.Button.render({
    // Configure environment
    env: '<?php echo $paypalmode; ?>', // sandbox | production
    client: {
    sandbox: '<?php echo $paypalclientid; ?>',
    production: '<?php echo $paypalclientid; ?>'
    },
    // Customize button (optional)
    locale: 'id_ID',
    style: {
    size: 'large',
    color: 'gold',
    shape: 'pill',
    fundingicons: 'true',
    },
    funding: {
      allowed: [ paypal.FUNDING.CARD ],
      disallowed: [ paypal.FUNDING.CREDIT ]
    },
    // Set up a payment
    payment: function (data, actions) {
    return actions.payment.create({
      transactions: [{
        amount: {
          total: '<?php echo $hargatotaldolar; ?>',
          currency: 'USD'
        }
      }]
    });
    },
    // Execute the payment
    onAuthorize: function (data, actions) {
    return actions.payment.execute()
      .then(function () {
        // Show a confirmation message to the buyer
        window.alert('Terimakasih Telah melakukan pembayaran!');
      });
    }
}, '#paypal-button');
</script>