<?php 

$query = FLBuilderLoop::query( $settings );
$posts = $query->posts;?>
<div class="pb-4 second-post slider-bottom-<?php echo $id; ?>">
<?php foreach($posts as $post) { ?>
<div class="post-list-module m-2">
<div class="p-2">
<a href="<?php echo get_the_permalink($post->ID);?>">
<div class="v-thumb-slider mb-2" style="background-image:url('<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post ) ); ?> ');"></div>
</a>
<div class="second-post-title mb-2"><a class="text-dark fw-bold" href="<?php echo get_the_permalink($post->ID);?>"><?php echo get_the_title($post);?></a></div>
<div class="text-secondary"><?php echo do_shortcode('[harga post_id="'.$post->ID.'"]');?></div>
</div>
</div>
<?php } ?>
</div>
