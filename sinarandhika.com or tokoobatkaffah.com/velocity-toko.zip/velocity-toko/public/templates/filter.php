<?php
/**
 * The template for displaying filter card product
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package velocity toko
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

global $post;
$harga              = array();
$label              = array();
$loop               = new WP_Query( array( 'post_type' => 'product', 'posts_per_page' => '-1' ) );
while ( $loop->have_posts() ) : $loop->the_post();
    $daftarharga = get_post_meta( $post->ID, 'harga', true );
    $daftarlabel = get_post_meta( $post->ID, 'label', true );
    if($daftarharga) {
        $harga[] = $daftarharga;                  
    }
    if($daftarlabel) {
        $label[] = $daftarlabel;              
    }
endwhile;

$maxharga           = $harga?max($harga)+10000:'';
$s                  = isset($_GET['s'])?$_GET['s']:'';
$listshort          = isset($_GET['short'])?$_GET['short']:'';
$listkategori       = isset($_GET['setkategori'])?$_GET['setkategori']:array('0');
$listmerk           = isset($_GET['setmerk'])?$_GET['setmerk']:'';
$listlabel          = isset($_GET['label'])?$_GET['label']:'';
$getrangeharga      = isset($_GET['rangeharga'])?$_GET['rangeharga']:'';
$rangeharga         = isset($_GET['rangeharga'])?explode('-',$_GET['rangeharga']):'';
$hargamin           = 0;
$hargamax           = 10000000;
if(!empty($_GET['rangeharga'])){
    $hargamin           = preg_replace('/[^0-9]/', '', $rangeharga[0]);
    $hargamax           = preg_replace('/[^0-9]/', '', $rangeharga[1]);
}

?>
<a class="btn btn-secondary btn-lg btn-block my-2 d-md-none" data-bs-toggle="collapse" href="#filtermart" role="button" aria-expanded="false" aria-controls="filtermart"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-filter" viewBox="0 0 16 16"> <path d="M6 10.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5zm-2-3a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-2-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"/> </svg> Filter </a>
<div id="filtermart" class="filtercard">
    <div class="card">
        <div class="card-header h5 py-3 text-dark">
            Filter Produk
            <a class="close d-md-none float-end" data-bs-toggle="collapse" href="#filtermart" role="button" aria-expanded="false" aria-controls="filtermart">&times;</a>
        </div>
        <div class="card-body">
            <form action="<?php echo get_site_url();?>/products/">
                <div class="form-group mb-3">
                    <span class="text-colortheme">Cari Kata</span>
                    <div class="px-1">
                        <input type="text" class="form-control form-control-sm" name="s" placeholder="Cari.." value="<?php echo $s; ?>"/>
                    </div>
                </div>
                <div class="form-group mb-3">
                    <span class="text-colortheme">Rentang Harga</span>
                    <div class="px-1">
                        <input id="price" name="rangeharga" type="text" value="" class="text-muted" value="<?php echo $getrangeharga;?>" style="width:100%;font-size:.7em;border:0; color:#333;"/>
                        <div id="hargarange" data-min="<?php echo $hargamin;?>" data-max="<?php echo $hargamax;?>" max=<?php echo $maxharga; ?>></div>
                    </div>
                </div>
                <div class="form-group mb-3">
                    <span class="text-colortheme">Shorting</span>
                    <?php
                    $shorting = array(
                        'Terbaru'   => 'baru',
                        'Terlama'   => 'lama',
                        'Termurah'  => 'murah',
                        'Termahal'  => 'mahal',
                        'Nama A-Z'  => 'namaa',
                        'Nama Z-A'  => 'namaz'
                    );
                    foreach($shorting as $key => $val){
                        ?>
                        <div class="px-0">
                            <input class="form-check-input" <?php if($listshort == $val ){echo 'checked="checked"';}; ?> type="radio" name="short" value="<?php echo $val; ?>" id="<?php echo $val; ?>">
                            <label class="form-check-label" for="<?php echo $val; ?>">
                                <?php echo $key; ?>
                            </label>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <div class="form-group mb-3">
                    <span class="text-colortheme">Berdasarkan Kategori</span>
                    <?php
                    $category   = get_queried_object();
                    $cat_id     = $category&&isset($category->term_id)?$category->term_id:'';                
                    foreach(get_categories('taxonomy=category-product&hide_empty=0&exclude=1') as $kat){
                        if (in_array($kat->term_id, $listkategori) || $kat->term_id == $cat_id){
                            $checked = 'checked="checked"';
                        } else {
                            $checked = '';
                        }
                        ?>
                        <div class="px-0">
                            <input class="form-check-input" <?php echo $checked; ?> type="checkbox" name="setkategori[]" value="<?php echo $kat->term_id; ?>" id="<?php echo $kat->slug; ?>">
                            <label class="form-check-label" for="<?php echo $kat->slug; ?>">
                                <?php echo $kat->name; ?>
                            </label>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <?php
                    $merks = array('taxonomy' => 'merk', 'hide_empty' => 0);
                    $getmerks = get_categories($merks);
                    $checked = false;
                    if($getmerks){
                ?>
                    <div class="form-group mb-3">
                        <span class="text-colortheme">Berdasarkan Merk</span>
                        <?php
                        foreach($getmerks as $kat){

                            ?>
                            <div class="px-0">
                                <input class="form-check-input" <?php if($listmerk && in_array($kat->term_id, $listmerk)){echo 'checked="checked"';}; ?> type="checkbox" name="setmerk[]" value="<?php echo $kat->term_id; ?>" id="<?php echo $kat->slug; ?>">
                                <label class="form-check-label" for="<?php echo $kat->slug; ?>">
                                    <?php echo $kat->name; ?>
                                </label>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                <?php } ?>

                <?php if(array_unique(array_filter($label))){ ?>
                    <div class="form-group mb-3">
                        <span class="text-colortheme">Label</span>
                        <?php
                        foreach(array_unique(array_filter($label)) as $label){
                            ?>
                            <div class="px-0">
                                <input class="form-check-input" <?php if($listlabel && in_array($label, $listlabel)){echo 'checked="checked"';}; ?> type="checkbox" name="label[]" value="<?php echo $label;?>" id="<?php echo $label;?>">
                                <label class="form-check-label" for="<?php echo $label; ?>">
                                    <?php echo ucwords(str_replace('label-', '', $label)); ?>
                                </label>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                <?php } ?>
                <button type="submit" class="btn btn-dark d-none d-md-block"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-filter" viewBox="0 0 16 16"> <path d="M6 10.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5zm-2-3a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-2-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"/> </svg> Filter</button>
                <div class="d-md-none">
                  <button type="submit" class="btn btn-secondary bg-colortheme btn-lg btn-block">Filter</button>
                  <button type="button" class="btn btn-secondary btn-lg btn-block" data-bs-toggle="collapse" href="#filtermart" role="button" aria-expanded="false" aria-controls="filtermart">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>
